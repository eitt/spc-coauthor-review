"""Audit and score a sealed final CrewAI run without model calls."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

from src.crewai_pilot import _save_json
from src.final_budget_ledger import ProjectLedger, audit_hash, inference_lock
from src.final_evaluator import CONTROL, SKIPPED, evaluate_final, load_b0_corpus
from src.final_holdout_seal import DESIGN, HOSTED, _file_hash, _json
from src.final_quota_policy import POLICY_ID, STOP_PERCENT
from src.mxc_hosted_crewai import LEDGER
from src.pilot_cases import canonical_bytes
from src.pilot_design import TURN_LIMITS, make_prompt, pilot_schema


RUN_ID = "final_test_001"
DIRECTORY = f"outputs/{RUN_ID}"
AUDIT = "outputs/pretest_final_seal_001/budget_audit.json"
SCHEMA = "schemas/agent_output.schema.json"
EXECUTION_MANIFEST = f"{DIRECTORY}/execution_manifest.json"
PREOPEN_VALIDATION = "outputs/pretest_final_validation_001/validation_manifest.json"


def _digest(raw):
    return sha256(raw).hexdigest()


def _read_records(directory, names):
    if directory.resolve() != directory:
        raise ValueError(f"Ruta de ejecución redirigida: {directory.name}")
    records, hashes = {}, {}
    for path in sorted(directory.glob("*.json")):
        if path.name not in names or path.resolve() != path:
            raise ValueError(f"Archivo fuera de la cola sellada: {directory.name}/{path.name}")
        raw = path.read_bytes()
        records[path.name] = json.loads(raw)
        hashes[f"{directory.name}/{path.name}"] = _digest(raw)
    return records, hashes


def _check_attempt(row, reservation, case, arm, first, schema_hash, backend):
    if row is None or row.get("status") == "RUNNING":
        if reservation is not None and reservation["status"] != "RESERVED":
            raise ValueError(f"Turno asentado sin checkpoint completo: {case['case_id']}/{arm}")
        if row is not None and reservation is None:
            raise ValueError(f"Checkpoint en curso sin reserva: {case['case_id']}/{arm}")
        return

    transport = row["transport"]
    attempts = transport["attempted_cli_turns"]
    tokens = transport.get("reported_input_plus_output_tokens")
    if not (type(attempts) is int and attempts in (0, 1) or attempts is None and row["status"] == "INTERRUPTED"):
        raise ValueError(f"Número de intentos inválido: {case['case_id']}/{arm}")
    expected = {"status": "NOT_LAUNCHED" if attempts == 0 else "SETTLED", "reported_tokens": tokens}
    if row["status"] == SKIPPED or reservation != expected:
        raise ValueError(f"Checkpoint y contador no coinciden: {case['case_id']}/{arm}")
    if attempts != 1:
        return

    allowance = transport.get("included_allowance_at_start", {})
    windows = allowance.get("windows", [])
    if (
        allowance.get("authentication") != "chatgpt" or allowance.get("ordinary_usage_allowed") is not True
        or allowance.get("auto_reload_off_operator_confirmed") is not True
        or allowance.get("paid_credit_balance_available") is not False
        or allowance.get("unlimited_credits_reported") is not False
        or allowance.get("rate_limit_reached") is not False or allowance.get("spend_control_reached") is not False
        or allowance.get("quota_policy") != POLICY_ID or allowance.get("stop_percent") != STOP_PERCENT or not windows
        or any(not 0 <= window["usedPercent"] < STOP_PERCENT for window in windows)
        or transport.get("paid_platform_api_key_used") is not False
    ):
        raise ValueError(f"Falta prueba de uso ordinario de ChatGPT: {case['case_id']}/{arm}")

    preliminary = None if arm == "A10" else (first or {}).get("raw_response")
    prompt_hash = _digest(make_prompt(case, arm, preliminary).encode("utf-8"))
    if (
        (arm != "A10" and preliminary is None)
        or transport.get("prompt_sha256") != prompt_hash or transport.get("schema_sha256") != schema_hash
        or transport.get("client") != backend["cli_version"]
        or transport.get("requested_model") != backend["requested_model"]
        or transport.get("requested_reasoning_effort") != backend["reasoning_effort"]
        or transport.get("inference") != "hosted" or transport.get("provider") != "openai"
    ):
        raise ValueError(f"Huella del lanzamiento distinta del diseño: {case['case_id']}/{arm}")


def _check_execution_manifest(root, backend, *, required):
    if not required and not (root / EXECUTION_MANIFEST).exists():
        return None
    manifest = _json(root, EXECUTION_MANIFEST)
    fingerprints = manifest["pinned_sha256"]
    quota = manifest["quota_policy"]
    required_paths = {f"{DIRECTORY}/queue_manifest.json", "src/final_live_run.py", "src/final_queue.py",
                      "src/final_quota_policy.py", HOSTED, SCHEMA, AUDIT}
    if (
        manifest["run_id"] != RUN_ID or manifest["scope"] != "SEALED_FINAL_TEST"
        or manifest["model"] != backend["requested_model"] or manifest["effort"] != backend["reasoning_effort"]
        or manifest["backend"] != backend or manifest["turn_limits"] != TURN_LIMITS
        or quota["stop_percent"] != STOP_PERCENT or quota["automatic_reload_off_required"] is not True
        or quota["paid_credits_allowed"] is not False or quota["refresh_requires_earned_credit_and_operator_authorization"] is not True
        or not required_paths <= fingerprints.keys()
        or any(_file_hash(root, path) != value for path, value in fingerprints.items())
    ):
        raise ValueError("El manifiesto de ejecución no corresponde a la cola o al runtime fijado")
    return _file_hash(root, EXECUTION_MANIFEST)


def score(root: Path, *, allow_incomplete=False, write=False):
    from src.final_queue import load_final_queue, load_final_references

    root = root.resolve()
    with inference_lock(root / "outputs/.hosted_inference.lock"):
        manifest, cases, orders = load_final_queue(root)
        if manifest.get("final_test_opened") is not True or manifest.get("final_test_run_authorized") is not True:
            raise ValueError("La apertura y ejecución del test deben constar en el sello")
        cases_by_id = {case["case_id"]: case for case in cases}
        controls = {case["pair_id"] for case in cases if CONTROL in orders[case["case_id"]]}
        allowed_attempts = {f"{case_id}.{arm}.json" for case_id in cases_by_id for arm in ("A10", *orders[case_id])}
        if len(cases_by_id) != 102 or len(controls) != 24 or len(allowed_attempts) != 276:
            raise ValueError("Se requieren los 34 pares, 102 escenarios y 24 controles sellados")
        attempt_rows, attempt_hashes = _read_records(root / DIRECTORY / "attempts", allowed_attempts)
        result_rows, result_hashes = _read_records(root / DIRECTORY / "results", {f"{case_id}.json" for case_id in cases_by_id})
        if not allow_incomplete and len(result_rows) != len(cases_by_id):
            raise ValueError("La ejecución aún está incompleta. Usa --allow-incomplete para auditar una pausa")

        config = _json(root, HOSTED)
        if _file_hash(root, "src/final_evaluator.py") != _json(root, PREOPEN_VALIDATION)["pinned_file_sha256"]["src/final_evaluator.py"]:
            raise ValueError("El evaluador científico difiere de la versión fijada")
        canonical = _json(root, SCHEMA)
        schema_hash = _digest(json.dumps(pilot_schema(canonical), allow_nan=False).encode("utf-8"))
        audit = _json(root, AUDIT)
        ledger_path = root / LEDGER
        if ledger_path.resolve() != ledger_path or not ledger_path.is_file():
            raise ValueError("Falta el contador acumulado del estudio")
        ledger = ProjectLedger(ledger_path, audit, audit_hash(audit), config["budget"])
        run_turns = {key.split("/", 1)[1]: row for key, row in ledger.turns.items() if key.startswith(f"{RUN_ID}/")}
        if run_turns.keys() - {name.removesuffix(".json") for name in allowed_attempts}:
            raise ValueError("Hay reservas para intentos fuera de la cola sellada")
        execution_hash = _check_execution_manifest(root, config["backend"], required=bool(attempt_rows or result_rows or run_turns))

        checkpoints = {}
        for case_id, case in cases_by_id.items():
            first = attempt_rows.get(f"{case_id}.A10.json")
            rows = {}
            for arm in ("A10", *orders[case_id]):
                stem = f"{case_id}.{arm}"
                row = attempt_rows.get(f"{stem}.json")
                _check_attempt(row, run_turns.get(stem), case, arm, first, schema_hash, config["backend"])
                if row is not None:
                    rows[arm] = row
            result = result_rows.get(f"{case_id}.json")
            if result is not None and (result.get("case_id") != case_id or any(
                arm not in rows and row.get("status") != SKIPPED for arm, row in result["arms"].items()
            )):
                raise ValueError(f"Resultado sin checkpoint correspondiente: {case_id}")
            if rows:
                checkpoints[case_id] = rows

        report = evaluate_final(
            cases, load_final_references(root), list(result_rows.values()), canonical, load_b0_corpus(root),
            second_pass_order_by_case=orders, precision=_json(root, DESIGN)["precision"],
            checkpoints=checkpoints, authorize_test=True,
        )
        del report["cases"]
        if len(result_rows) != len(cases_by_id):
            report["status"] = "OFFLINE_EVALUATION_INCOMPLETE"
            report["exploratory"] = True
        transports = [row.get("transport", {}) for row in attempt_rows.values()]
        report.update(
            run_id=RUN_ID, saved_cases=len(result_rows),
            observed_tool_event_types=sorted({kind for row in transports for kind in row.get("observed_tool_event_types", [])}),
            model_id_mismatch_attempts=sum(row.get("transport_status") == "MODEL_ID_MISMATCH" for row in transports),
            input_sha256={"queue_manifest": _file_hash(root, f"{DIRECTORY}/queue_manifest.json"),
                          "execution_manifest": execution_hash,
                          "execution_snapshot": _digest(canonical_bytes({**attempt_hashes, **result_hashes})),
                          "cumulative_ledger": _file_hash(root, LEDGER)},
            ledger=ledger.totals(),
        )
        if write:
            filename = "offline_evaluation.json" if report["status"] == "OFFLINE_EVALUATION_COMPLETE" else "offline_evaluation_partial.json"
            destination = root / DIRECTORY / filename
            if destination.resolve() != destination:
                raise ValueError("El destino del reporte está redirigido")
            _save_json(destination, report)
        return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--allow-incomplete", action="store_true", help="Audita una corrida detenida con casos pendientes")
    parser.add_argument("--write", action="store_true", help="Guarda el reporte agregado fuera de la referencia privada")
    args = parser.parse_args()
    report = score(Path(__file__).resolve().parents[1], allow_incomplete=args.allow_incomplete, write=args.write)
    print(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
