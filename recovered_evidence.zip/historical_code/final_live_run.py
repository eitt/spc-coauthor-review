"""Execute the sealed final queue once using the verified MXC worker."""

import argparse
from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
from hashlib import sha256
from importlib.metadata import version
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from time import monotonic

from src.crewai_hosted import ExecutionPaused, run_flow
from src.crewai_pilot import _save_json
from src.final_budget_ledger import BudgetPaused, ProjectLedger, audit_hash, inference_lock
from src.final_executor import _check_result
from src.hosted_quota import QuotaPaused
from src.mxc_auth_stage import staged_auth
from src.mxc_hosted_crewai import LEDGER, MxcHostedWorker, _verified_binary
from src.pilot_codex import PASS_TIMEOUT_SECONDS
from src.pilot_design import EFFORT, MODEL, TURN_LIMITS


RUN_ID = "final_test_001"
RUN_DIR = f"outputs/{RUN_ID}"
AUDIT = "outputs/pretest_final_seal_001/budget_audit.json"
CONFIG = "configs/pretest_hosted_001.json"
SCHEMA = "schemas/agent_output.schema.json"
RUNTIME_RECEIPT = "outputs/mxc_isolation_002/manifest.json"
MAX_INVOCATION_SECONDS = 6 * 60 * 60


def _read(path):
    return json.loads(path.read_bytes())


def _local(path):
    if path.resolve() != path:
        raise ValueError("La ruta de la ejecución no puede estar redirigida")
    return path


def _digest(path):
    return sha256(_local(path).read_bytes()).hexdigest()


def _accounting(root):
    path = _local(root / LEDGER)
    if not path.is_file():
        raise ValueError("Falta el contador que conserva los intentos reales de validación MXC")
    audit = _read(root / AUDIT)
    budget = _read(root / CONFIG)["budget"]
    ledger = ProjectLedger(path, audit, audit_hash(audit), budget)
    for run_id in ("mxc_hosted_synthetic_001", "mxc_hosted_synthetic_002"):
        records = [row for key, row in ledger.turns.items() if key.startswith(f"{run_id}/")]
        if len(records) != 1 or records[0]["status"] != "SETTLED":
            raise ValueError("El contador acumulado no concilia la validación MXC previa")
    return ledger


def _attempted(transport):
    count = transport["attempted_cli_turns"]
    if count is not None and (type(count) is not int or count not in (0, 1)):
        raise ValueError("Cantidad de turnos inválida en el intento guardado")
    return None if count is None else count == 1


def _reconcile(attempts, ledger, name, *, recover):
    path = _local(attempts / f"{name}.json")
    key = f"{RUN_ID}/{name}"
    row = _read(path) if path.is_file() else None
    if key not in ledger.turns:
        if row is not None:
            raise ValueError("Un intento carece de reserva en el contador")
        return None
    if row is None or row["status"] == "RUNNING":
        if ledger.turns[key]["status"] != "RESERVED":
            raise ValueError("Falta el checkpoint de un turno asentado")
        if not recover:
            return None
        row = {"status": "INTERRUPTED", "relation": None, "raw_response": "",
               "transport": {"transport_status": "INTERRUPTED", "attempted_cli_turns": None}}
        _save_json(path, row)
    transport = row["transport"]
    ledger.settle(key, transport.get("reported_input_plus_output_tokens"), attempted=_attempted(transport))
    return row


def _review_required(row):
    transport = row["transport"]
    item_types = set(transport.get("observed_tool_event_types") or [])
    # The frozen CLI parser also stores diagnostic items in this field. Keep
    # the failed attempt, but permit resumption when a timeout only emitted an error.
    timeout_diagnostic = (transport["transport_status"] == "CLI_TIMEOUT"
                          and transport["attempted_cli_turns"] == 1
                          and transport.get("completed_cli_turns") == 0
                          and transport.get("malformed_cli_event_lines") == 0 and item_types == {"error"})
    return (transport["attempted_cli_turns"] == 0
            or transport["transport_status"] in {"MODEL_ID_MISMATCH", "UNEXPECTED_TOOL_EVENTS", "UNEXPECTED_TURN_COUNT"}
            or bool(item_types and not timeout_diagnostic)
            or transport.get("completed_cli_turns", 0) > 1)


def _check_attempt_inventory(attempts, results, ledger, cases, orders):
    names = {f"{case['case_id']}.{arm}" for case in cases for arm in ("A10", *orders[case["case_id"]])}
    result_names = {case["case_id"] for case in cases}
    ledger_names = {key.removeprefix(f"{RUN_ID}/") for key in ledger.turns if key.startswith(f"{RUN_ID}/")}
    if (any(path.stem not in names for path in attempts.glob("*.json"))
            or any(path.stem not in result_names for path in results.glob("*.json"))
            or not ledger_names <= names):
        raise ValueError("Hay intentos o resultados fuera de la cola fijada")
    for name in names:
        row = _reconcile(attempts, ledger, name, recover=True)
        if row is not None and _review_required(row):
            raise ExecutionPaused("FINAL_RUNTIME_INVARIANT_REQUIRES_REVIEW")
    for case in cases:
        case_id = case["case_id"]
        result = _local(results / f"{case_id}.json")
        if result.is_file():
            _check_result(result, case, orders[case_id], attempts)


@contextmanager
def _fresh_worker(root, codex, original_home, auth, auth_stat):
    if _file_identity(auth) != auth_stat or auth.is_symlink() or auth.resolve() != auth:
        raise ExecutionPaused("CHATGPT_SESSION_FILE_CHANGED_DURING_INVOCATION")
    with TemporaryDirectory(prefix="spc-final-turn-") as directory:
        current = Path(directory).resolve()
        if current.is_relative_to(root) or current.is_relative_to(original_home):
            raise ValueError("La carpeta del turno debe quedar fuera del proyecto y del perfil de Codex")
        with staged_auth(auth, current) as auth_home:
            if _file_identity(auth) != auth_stat:
                raise ExecutionPaused("CHATGPT_SESSION_FILE_CHANGED_DURING_INVOCATION")
            yield MxcHostedWorker(root, codex, current, auth_home, original_home)


def _file_identity(path):
    stat = path.stat()
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns


def _progress(run_dir, ledger, planned, saved, *, status, detail=None, quota=None):
    turns = [row for key, row in ledger.turns.items() if key.startswith(f"{RUN_ID}/")
             and row["status"] != "NOT_LAUNCHED"]
    report = {
        "scope": "SEALED_FINAL_TEST", "final_test_opened": True, "final_test_run_authorized": True,
        "status": status, "detail": detail, "planned_cases": planned, "saved_cases": saved,
        "final_accounted_turns": len(turns), "final_reported_tokens": sum(row["reported_tokens"] or 0 for row in turns),
        "final_turns_without_telemetry": sum(row["reported_tokens"] is None for row in turns),
        "quota_at_pause": quota, "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "paid_platform_api_key_used": False, "ledger": ledger.totals(),
    }
    _save_json(_local(run_dir / "execution_status.json"), report)
    return report


def run(root: Path, *, confirmed: bool, allow_refresh: bool, limit: int | None = None, preflight: bool = False):
    from src.final_queue import load_final_queue
    from src.final_quota_policy import POLICY_ID, STOP_PERCENT, FinalQuota

    if not preflight and confirmed is not True:
        raise QuotaPaused("AUTO_RELOAD_OFF_UNCONFIRMED")
    if limit is not None and (type(limit) is not int or limit < 1):
        raise ValueError("El límite debe ser un número positivo de escenarios pendientes")
    root = root.resolve()
    run_dir = _local(root / RUN_DIR)
    attempts, results = _local(run_dir / "attempts"), _local(run_dir / "results")
    deadline = monotonic() + MAX_INVOCATION_SECONDS
    with inference_lock(_local(root / "outputs/.hosted_inference.lock")):
        manifest, cases, orders = load_final_queue(root)
        canonical = _read(root / SCHEMA)
        codex = _verified_binary(root)
        backend = _read(root / CONFIG)["backend"]
        if version("crewai") != backend["crewai_version"]:
            raise ValueError("La versión de CrewAI no coincide con la fijada")
        if (manifest.get("final_test_run_authorized") is not True or manifest["case_count"] != len(cases)
                or manifest["planned_turns"] != sum(1 + len(order) for order in orders.values())):
            raise ValueError("La cola final no tiene autorización y contabilidad verificables")
        ledger = _accounting(root)
        totals = ledger.totals()
        execution_manifest = {
            "run_id": RUN_ID, "scope": "SEALED_FINAL_TEST", "model": MODEL, "effort": EFFORT,
            "turn_limits": TURN_LIMITS, "backend": backend,
            "quota_policy": {"id": POLICY_ID, "stop_percent": STOP_PERCENT, "automatic_reload_off_required": True,
                             "paid_credits_allowed": False, "refresh_requires_earned_credit_and_operator_authorization": True,
                             "refresh_journal": f"{RUN_DIR}/quota_refresh.json"},
            "pinned_sha256": {path: _digest(root / path) for path in (
                f"{RUN_DIR}/queue_manifest.json", RUNTIME_RECEIPT, AUDIT, CONFIG, SCHEMA,
                "src/final_live_run.py", "src/final_queue.py", "src/final_quota_policy.py",
                "src/final_evaluator.py", "src/final_live_score.py",
            )},
        }
        manifest_path = _local(run_dir / "execution_manifest.json")
        if manifest_path.is_file():
            if _read(manifest_path) != execution_manifest:
                raise ValueError("Cambió una huella de la ejecución final")
        elif attempts.exists() or results.exists() or any(key.startswith(f"{RUN_ID}/") for key in ledger.turns):
            raise ValueError("La cola no puede adoptar intentos sin manifiesto de ejecución")
        elif (manifest["planned_turns"] > totals["future_remaining_turns"]
                or manifest["planned_turns"] * ledger.origin["reserved_tokens_per_turn"]
                > min(totals["future_remaining_tokens"], totals["project_remaining_tokens"])):
            raise BudgetPaused("SEALED_QUEUE_EXCEEDS_PROJECT_ACCOUNTING_BUDGET")
        if preflight:
            return {"status": "FINAL_TEST_PREFLIGHT_VERIFIED", "planned_cases": len(cases),
                    "planned_physical_turns": manifest["planned_turns"],
                    "queued_prompt_budget": manifest.get("prompt_budget"), "ledger": totals}
        original_home = Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))).resolve(strict=True)
        auth = original_home / "auth.json"
        if not auth.is_file() or auth.is_symlink() or auth.resolve() != auth or original_home.is_relative_to(root):
            raise ValueError("No se encontró un archivo regular de la sesión existente de Codex")
        auth_stat = _file_identity(auth)
        if not manifest_path.is_file():
            _save_json(manifest_path, execution_manifest)
        attempts.mkdir(exist_ok=True)
        results.mkdir(exist_ok=True)
        planned = len(cases)
        saved = len(list(results.glob("*.json")))
        try:
            _check_attempt_inventory(attempts, results, ledger, cases, orders)
        except ExecutionPaused as exc:
            return _progress(run_dir, ledger, planned, saved, status="FINAL_TEST_PAUSED_RUNTIME", detail=str(exc))
        if saved == planned:
            return _progress(run_dir, ledger, planned, saved, status="FINAL_TEST_COMPLETE")

        journal = _local(run_dir / "quota_refresh.json")
        written = 0
        with TemporaryDirectory(prefix="spc-final-crewai-") as directory:
            flow_workdir = Path(directory).resolve()
            if flow_workdir.is_relative_to(root) or flow_workdir.is_relative_to(original_home):
                raise ValueError("CrewAI requiere una carpeta temporal fuera del proyecto y el perfil")
            for case in cases:
                case_id = case["case_id"]
                result_path = _local(results / f"{case_id}.json")
                if result_path.is_file():
                    continue
                if limit is not None and written >= limit:
                    return _progress(run_dir, ledger, planned, saved, status="FINAL_TEST_BATCH_LIMIT")
                order = orders[case_id]
                names = [f"{case_id}.{arm}" for arm in ("A10", *order)]
                worker = None
                pause = None
                with ExitStack() as turn:
                    def before_attempt():
                        nonlocal worker
                        for name in names:
                            _reconcile(attempts, ledger, name, recover=False)
                        if deadline - monotonic() < PASS_TIMEOUT_SECONDS + 120:
                            raise ExecutionPaused("INVOCATION_TIME_LIMIT")
                        next_name = next(name for name in names if not (attempts / f"{name}.json").exists())
                        worker = turn.enter_context(_fresh_worker(root, codex, original_home, auth, auth_stat))
                        allowance = FinalQuota(worker, journal, confirmed, allow_refresh)()
                        if deadline - monotonic() < PASS_TIMEOUT_SECONDS:
                            raise ExecutionPaused("INVOCATION_TIME_LIMIT")
                        ledger.reserve(f"{RUN_ID}/{next_name}")
                        worker.allowance = allowance
                        return allowance

                    def transport(*args, **kwargs):
                        if worker is None:
                            raise ValueError("Falta un trabajador con cuota verificada para este turno")
                        try:
                            return worker(*args, **kwargs)
                        finally:
                            turn.close()

                    try:
                        result = run_flow(case, order, canonical, flow_workdir, attempts,
                                          before_attempt=before_attempt, transport=transport)
                    except QuotaPaused as exc:
                        pause = {"status": "FINAL_TEST_PAUSED_QUOTA", "detail": exc.reason, "quota": exc.snapshot}
                    except BudgetPaused as exc:
                        pause = {"status": "FINAL_TEST_PAUSED_BUDGET", "detail": str(exc)}
                    except ExecutionPaused as exc:
                        pause = {"status": "FINAL_TEST_PAUSED_RUNTIME", "detail": str(exc)}
                    finally:
                        for name in names:
                            _reconcile(attempts, ledger, name, recover=False)
                if pause is not None:
                    return _progress(run_dir, ledger, planned, saved, **pause)
                _save_json(result_path, result)
                _check_result(result_path, case, order, attempts)
                written += 1
                saved += 1
                _progress(run_dir, ledger, planned, saved, status="FINAL_TEST_RUNNING")
        return _progress(run_dir, ledger, planned, saved, status="FINAL_TEST_COMPLETE")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--confirm-auto-reload-off", action="store_true")
    parser.add_argument("--allow-earned-refresh", action="store_true")
    parser.add_argument("--limit", type=int, help="Máximo de escenarios pendientes para esta invocación")
    parser.add_argument("--preflight", action="store_true", help="Verifica la cola, el binario y el saldo sin lanzar turnos")
    args = parser.parse_args()
    if not args.preflight and not args.confirm_auto_reload_off:
        parser.error("Verifica que la recarga automática esté desactivada antes de lanzar la cola hospedada")
    report = run(Path(__file__).resolve().parents[1], confirmed=args.confirm_auto_reload_off,
                 allow_refresh=args.allow_earned_refresh, limit=args.limit, preflight=args.preflight)
    print(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
