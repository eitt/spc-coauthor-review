"""Deterministic calculations shared by the evaluator and the numeric tools."""

from collections.abc import Mapping
from fractions import Fraction
from math import fsum, isfinite

IMPACTS = ("climate_change", "water_use", "freshwater_eutrophication")


def _check_impacts(values: Mapping[str, float], name: str) -> None:
    if set(values) != set(IMPACTS):
        raise ValueError(f"{name} debe contener las tres categorías de impacto")
    for impact in IMPACTS:
        value = values[impact]
        if type(value) not in (int, float) or not isfinite(value):
            raise ValueError(f"{name}.{impact} debe ser un número finito")


def calculate_impacts(stages: Mapping[str, Mapping[str, float]]) -> dict[str, float]:
    """Sum absolute stage contributions in each impact's original unit."""
    if not stages:
        raise ValueError("Se requiere al menos una etapa")
    for stage, contributions in stages.items():
        _check_impacts(contributions, stage)
    return {
        impact: fsum(contributions[impact] for contributions in stages.values())
        for impact in IMPACTS
    }


def compare_impacts(
    a: Mapping[str, float],
    b: Mapping[str, float],
    tolerance: Mapping[str, float],
) -> str:
    """Compare compatible, lower-is-better impact profiles without weighting."""
    _check_impacts(a, "A")
    _check_impacts(b, "B")
    _check_impacts(tolerance, "tolerancia")
    if any(tolerance[impact] < 0 for impact in IMPACTS):
        raise ValueError("La tolerancia debe ser no negativa")

    # Preserve the inclusive boundary for decimal values such as 0.4 − 0.3 = 0.1.
    differences = [Fraction(str(a[impact])) - Fraction(str(b[impact])) for impact in IMPACTS]
    bounds = [Fraction(str(tolerance[impact])) for impact in IMPACTS]
    a_better = any(difference < -bound for difference, bound in zip(differences, bounds, strict=True))
    b_better = any(difference > bound for difference, bound in zip(differences, bounds, strict=True))
    if a_better and b_better:
        return "TRADEOFF"
    if a_better:
        return "A_DOMINATES"
    if b_better:
        return "B_DOMINATES"
    return "EQUIVALENT_WITHIN_TOLERANCE"
