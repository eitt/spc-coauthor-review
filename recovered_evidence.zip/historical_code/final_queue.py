"""Materialize the authorized holdout queue without making inference calls."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

from src.data_validation import _write_atomic
from src.final_holdout_seal import DESIGN, HOSTED, MANIFEST_NAME as PRETEST_NAME, SEAL_DIR, _serialized
from src.final_metadata_roster import MANIFEST as ROSTER_MANIFEST, ROSTER as PRIVATE_ROSTER
from src.final_preopen_validation import DIRECTORY as VALIDATION_DIR, MANIFEST as VALIDATION_NAME
from src.pilot_cases import CONTEXT_FIELDS, MASK_COUNTS, build_cases, canonical_bytes, validate_public_cases
from src.pilot_design import check_prompt_budget, schedule
from src.splits import _order


RUN_ID = "final_test_001"
PUBLIC = f"outputs/{RUN_ID}"
PRIVATE = f"data/private/{RUN_ID}"
QUEUE_MANIFEST = f"{PUBLIC}/queue_manifest.json"
QUEUE_SIDECAR = f"{PUBLIC}/queue_manifest.sha256"
CASES = f"{PUBLIC}/cases.jsonl"
REFERENCES = f"{PRIVATE}/reference.jsonl"
SCHEMA = "schemas/agent_output.schema.json"
PRETEST = f"{SEAL_DIR}/{PRETEST_NAME}"
VALIDATION = f"{VALIDATION_DIR}/{VALIDATION_NAME}"
MXC_MANIFEST = "outputs/mxc_isolation_002/manifest.json"
HOSTED_VALIDATION = "outputs/mxc_hosted_synthetic_002/verification.json"
PAIR_COUNT = 34
CONTROL_COUNT = 24


def _digest(raw: bytes) -> str:
    return sha256(raw).hexdigest()


def _fixed_path(root: Path, name: str) -> Path:
    path = root / name
    if not path.is_relative_to(root) or path.resolve() != path:
        raise ValueError(f"La ruta de la cola está fuera de su destino: {name}")
    return path


def _read(root: Path, name: str) -> bytes:
    return _fixed_path(root, name).read_bytes()


def _sidecar(raw: bytes) -> bytes:
    return f"{_digest(raw)}  queue_manifest.json\n".encode("ascii")


def _jsonl(rows: list[dict]) -> bytes:
    return b"".join(canonical_bytes(row) + b"\n" for row in rows)


def _schedule(cases: list[dict], neutral: set[str], seed: int):
    ordered, _ = schedule(cases, seed)
    _, control_orders = schedule([case for case in cases if case["pair_id"] in neutral], seed)
    orders = {case["case_id"]: control_orders.get(case["case_id"], ["A11"]) for case in ordered}
    return ordered, orders


def _public_checks(manifest: dict, cases: list[dict]):
    if any(case["partition"] != "test" for case in cases):
        raise ValueError("Todos los casos de la cola deben pertenecer al test")
    # The frozen validator is named for the tuning pilot. Test uses the same field contract.
    validate_public_cases([{**case, "partition": "tuning"} for case in cases], PAIR_COUNT)
    neutral = set(manifest["neutral_control_pair_ids"])
    if (
        len(neutral) != CONTROL_COUNT or len(manifest["neutral_control_pair_ids"]) != CONTROL_COUNT
        or not neutral <= {case["pair_id"] for case in cases}
    ):
        raise ValueError("El subconjunto neutral de la cola no es el fijado")
    ordered, orders = _schedule(cases, neutral, manifest["seed"])
    if ordered != cases or orders != manifest["second_pass_order_by_case"]:
        raise ValueError("Los casos o brazos de la cola cambiaron de orden")
    if (
        manifest["case_count"] != len(cases) or manifest["pair_count"] != PAIR_COUNT
        or manifest["neutral_control_pair_count"] != CONTROL_COUNT
        or manifest["planned_turns"] != len(cases) + sum(map(len, orders.values()))
        or manifest["prompt_budget"] != check_prompt_budget(cases)
    ):
        raise ValueError("Los conteos o límites de la cola no corresponden al diseño")
    return orders


def _load_manifest(root: Path) -> dict:
    raw = _read(root, QUEUE_MANIFEST)
    if _read(root, QUEUE_SIDECAR) != _sidecar(raw):
        raise ValueError("No coincide la huella del manifiesto de la cola final")
    manifest = json.loads(raw)
    if (
        manifest["id"] != RUN_ID or manifest["status"] != "SEALED_AUTHORIZED_FINAL_QUEUE"
        or manifest["partition"] != "test" or manifest["final_test_opened"] is not True
        or manifest["final_test_run_authorized"] is not True or manifest["additional_spend_usd"] != 0
        or {key: value["path"] for key, value in manifest["artifacts"].items()}
        != {"cases": CASES, "references": REFERENCES, "schema": SCHEMA}
    ):
        raise ValueError("El manifiesto no corresponde a la cola final autorizada")
    return manifest


def _verified_artifact(root: Path, manifest: dict, key: str) -> bytes:
    row = manifest["artifacts"][key]
    raw = _read(root, row["path"])
    if _digest(raw) != row["sha256"]:
        raise ValueError(f"La huella del artefacto fijado no coincide: {key}")
    return raw


def load_final_queue(root: Path) -> tuple[dict, list[dict], dict[str, list[str]]]:
    """Verify and load only public queue artifacts, without opening references or raw data."""
    root = root.resolve()
    manifest = _load_manifest(root)
    for name, digest in manifest["public_dependencies_sha256"].items():
        if not name.startswith(("src/", "configs/", "outputs/")) or _digest(_read(root, name)) != digest:
            raise ValueError(f"Cambió una dependencia pública de la cola: {name}")
    _verified_artifact(root, manifest, "schema")
    cases = [json.loads(line) for line in _verified_artifact(root, manifest, "cases").splitlines()]
    return manifest, cases, _public_checks(manifest, cases)


def load_final_references(root: Path) -> list[dict]:
    """Open the sealed reference from the trusted evaluator only."""
    root = root.resolve()
    manifest = _load_manifest(root)
    return [json.loads(line) for line in _verified_artifact(root, manifest, "references").splitlines()]


def _construct(root: Path):
    from src.agribalyse_reference import load_reference
    from src.data_io import load_manifest
    from src.final_evaluator import load_b0_corpus
    from src.final_holdout_seal import check as check_pretest
    from src.final_preopen_validation import build as build_validation
    from src.mxc_isolation_receipt import check as check_mxc
    from src.splits import group_products, split_groups

    pretest_sha = check_pretest(root)
    pretest = json.loads(_read(root, PRETEST))
    validation = build_validation(root)
    validation_raw = _read(root, VALIDATION)
    if _serialized(validation) != validation_raw or _read(root, VALIDATION.replace(".json", ".sha256")) != (
        f"{_digest(validation_raw)}  {VALIDATION_NAME}\n".encode("ascii")
    ):
        raise ValueError("La validación de preapertura ya no coincide con el sello")
    mxc = check_mxc(root)
    hosted = json.loads(_read(root, HOSTED_VALIDATION))
    if (
        hosted["status"] != "PASS_MXC_HOSTED_SYNTHETIC_VALIDATION" or hosted["final_test_opened"] is not False
        or hosted["mxc_manifest_sha256"] != _digest(_read(root, MXC_MANIFEST)) or hosted["client"] != mxc["client"]
    ):
        raise ValueError("La verificación hospedada no corresponde al entorno MXC fijado")
    roster = json.loads(_read(root, PRIVATE_ROSTER))
    pairs = roster["pairs"]
    design = pretest["design"]
    seed = design["seed"]
    if (
        roster["partition"] != "test" or roster["status"] != "SEALED_METADATA_ONLY" or roster["seed"] != seed
        or len(pairs) != PAIR_COUNT or validation["pairs"] != PAIR_COUNT or pretest_sha != validation["original_seal_sha256"]
        or tuple(design["missing_stages_per_product"]) != MASK_COUNTS
        or design["replicates_per_mask"] != 1
    ):
        raise ValueError("La cohorte adjudicada no coincide con el diseño del test")
    neutral = sorted(pairs, key=lambda pair: _order(seed, design["neutral_control_order_hash_domain"], pair["pair_id"]))
    neutral_ids = [pair["pair_id"] for pair in neutral[:CONTROL_COUNT]]
    if neutral_ids != roster["neutral_control_pair_ids"] or validation["neutral_control_pairs"] != CONTROL_COUNT:
        raise ValueError("El control neutral no coincide con el subconjunto comprometido")

    products, _, audit = load_reference(root, load_manifest(root, "data/manifest.json"))
    by_id = {row["id"]: row for row in products}
    groups = group_products(products)
    split = pretest["partition_commitment"]
    assignments = split_groups(products, seed, split["proportions_by_group"])
    membership = [[key, groups[key], assignments[key]] for key in sorted(groups)]
    if (
        _digest(canonical_bytes(membership)) != split["all_partition_membership_sha256"]
        or audit["status"] != "REFERENCE_AUDITED" or audit["primary_reference"] != "Detail etape / Total"
    ):
        raise ValueError("La referencia oficial o la partición reservada cambió")
    corpus = load_b0_corpus(root)
    audited_corpus = [{"id": row["id"], "group": groups[row["id"]], "stages": row["stages"],
                       **{field: row[field].strip() for field in CONTEXT_FIELDS}}
                      for row in sorted(products, key=lambda row: row["id"])
                      if row["eligible_for_development"] and assignments[row["id"]] == "corpus"]
    if audited_corpus != corpus:
        raise ValueError("La evidencia recuperable difiere del corpus de desarrollo fijado")
    selected = []
    for pair in pairs:
        ids = pair["product_ids"]
        if (
            len(ids) != 2 or [groups[key] for key in ids] != pair["group_ids"]
            or any(assignments[key] != "test" or not by_id[key]["eligible_for_development"] for key in ids)
            or pair["pair_id"] != "P-" + _digest(canonical_bytes([seed, *ids]))[:16]
        ):
            raise ValueError("La composición de la cohorte reservada difiere del sello")
        selected.append(tuple(by_id[key] for key in ids))
    # Reuse the frozen pilot constructor on a temporary input projection only. Its
    # tuning label is an input guard, so reattach the verified test split below.
    constructor_split = {row["id"]: "corpus" for row in corpus}
    constructor_split.update({row["id"]: "tuning" for pair in selected for row in pair})
    constructor_products = [by_id[key] for key in constructor_split]
    cases, references, _ = build_cases(constructor_products, selected, constructor_split, groups, seed,
                                        pretest["reference"]["tolerance_scale_fraction"])
    for case, ref in zip(cases, references, strict=True):
        case["partition"] = ref["partition"] = "test"
        ref["payload_sha256"] = _digest(canonical_bytes(case))
    ordered, orders = _schedule(cases, set(neutral_ids), seed)
    by_case = {ref["case_id"]: ref for ref in references}
    cases_raw = _jsonl(ordered)
    references_raw = _jsonl([by_case[case["case_id"]] for case in ordered])
    schema_raw = _read(root, SCHEMA)
    manifest = {
        "id": RUN_ID, "status": "SEALED_AUTHORIZED_FINAL_QUEUE", "partition": "test",
        "final_test_opened": True, "final_test_run_authorized": True, "additional_spend_usd": 0,
        "seed": seed, "pair_count": PAIR_COUNT, "case_count": len(ordered),
        "neutral_control_pair_count": CONTROL_COUNT, "neutral_control_pair_ids": neutral_ids,
        "planned_turns": len(ordered) + sum(map(len, orders.values())), "exploratory": validation["exploratory"],
        "second_pass_order_by_case": orders, "prompt_budget": check_prompt_budget(ordered),
        "artifacts": {key: {"path": name, "sha256": _digest(raw)} for key, name, raw in (
            ("cases", CASES, cases_raw), ("references", REFERENCES, references_raw), ("schema", SCHEMA, schema_raw),
        )},
        "public_dependencies_sha256": {name: _digest(_read(root, name)) for name in (
            PRETEST, VALIDATION, ROSTER_MANIFEST, MXC_MANIFEST, HOSTED_VALIDATION, DESIGN, HOSTED,
            "src/final_queue.py", "src/pilot_cases.py", "src/pilot_design.py", "src/crewai_hosted.py",
        )},
        "private_roster_sha256": validation["private_roster_sha256"],
        "frozen_corpus_sha256": validation["pinned_file_sha256"]["data/private/pilot_baselines_001/corpus.jsonl"],
    }
    if manifest["planned_turns"] != validation["budget"]["planned_final_turn_slots"]:
        raise ValueError("La cola no coincide con los turnos preasignados")
    _public_checks(manifest, ordered)
    return manifest, cases_raw, references_raw


def seal_final_queue(root: Path, *, authorized: bool = False) -> dict:
    """Open once, write private references first, and commit both artifacts before execution."""
    from src.final_budget_ledger import inference_lock

    if authorized is not True:
        raise ValueError("Se requiere la autorización explícita de apertura del test")
    root = root.resolve()
    with inference_lock(_fixed_path(root, "outputs/.hosted_inference.lock")):
        if _fixed_path(root, QUEUE_SIDECAR).exists():
            manifest, _, _ = load_final_queue(root)
            load_final_references(root)
            return manifest
        manifest, cases_raw, references_raw = _construct(root)
        manifest_raw = _serialized(manifest)
        files = {REFERENCES: references_raw, CASES: cases_raw, QUEUE_MANIFEST: manifest_raw}
        for name, raw in files.items():
            path = _fixed_path(root, name)
            if path.exists() and path.read_bytes() != raw:
                raise ValueError(f"El artefacto parcial difiere de la reconstrucción determinista: {name}")
        for name, raw in files.items():
            path = _fixed_path(root, name)
            if not path.exists():
                _write_atomic(path, raw)
        _write_atomic(_fixed_path(root, QUEUE_SIDECAR), _sidecar(manifest_raw))
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("seal", "check"))
    parser.add_argument("--authorize-open", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    if args.action == "seal":
        manifest = seal_final_queue(root, authorized=args.authorize_open)
    else:
        manifest, _, _ = load_final_queue(root)
        load_final_references(root)
    print(json.dumps({key: manifest[key] for key in (
        "id", "status", "pair_count", "case_count", "neutral_control_pair_count", "planned_turns", "exploratory", "artifacts",
    )}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
