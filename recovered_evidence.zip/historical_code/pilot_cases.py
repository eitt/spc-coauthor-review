"""Prepare one public payload per development pair and mask."""

from collections import Counter
from hashlib import sha256
import json
import math
from pathlib import Path
import re
from statistics import median

from src.baselines import _nested_masks
from src.data_validation import IMPACT_FIELDS, STAGE_FIELDS
from src.reference import IMPACTS, calculate_impacts, compare_impacts

MASK_COUNTS = (0, 2, 4)
RETRIEVAL_K = 4
SIDES = ("A", "B")
UNITS = {impact: unit for impact, (_, unit) in IMPACT_FIELDS.items()}
CONTEXT_FIELDS = ("family", "subgroup", "preparation")


def canonical_bytes(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _context(product: dict) -> dict:
    return {field: product[field].strip() for field in CONTEXT_FIELDS}


def _tolerances(corpus: list[dict], scale_fraction: float) -> dict:
    typical = {impact: median(abs(row["total"][impact]) for row in corpus) for impact in IMPACTS}
    if any(not math.isfinite(value) or value <= 0 for value in typical.values()):
        raise ValueError("La escala del corpus debe ser positiva en cada impacto")
    return {
        impact: max(scale_fraction * scale, 10.0 ** (math.floor(math.log10(scale)) - 2))
        for impact, scale in typical.items()
    }


def _observed_profile(product: dict, side: str, hidden: frozenset[str]) -> dict:
    return {
        stage: {"evidence_id": f"OBS-{side}-{stage}", "impacts": product["stages"][stage]}
        for stage in STAGE_FIELDS
        if stage not in hidden
    }


def _stage_scales(corpus: list[dict]) -> dict:
    scales = {}
    for stage in STAGE_FIELDS:
        for impact in IMPACTS:
            nonzero = [
                abs(row["stages"][stage][impact])
                for row in corpus if row["stages"][stage][impact] != 0
            ]
            scales[stage, impact] = median(nonzero) if nonzero else 1.0
    return scales


def _retrieve(
    corpus: list[dict],
    groups: dict[str, str],
    context: dict,
    observed: dict,
    scales: dict,
) -> list[dict]:
    def rank(row):
        metadata = tuple(
            row[field].strip().casefold() != context[field].casefold()
            for field in ("subgroup", "preparation", "family")
        )
        # Every distance is computed from visible stages. The reference totals are never queried.
        distance = min(
            math.fsum(
                abs(math.asinh(item["impacts"][impact] / scales[stage, impact])
                    - math.asinh(row["stages"][stage][impact] / scales[stage, impact]))
                for stage, item in observed[side].items()
                for impact in IMPACTS
            ) / (len(observed[side]) * len(IMPACTS))
            for side in SIDES
        )
        return metadata, distance, row["id"]

    selected = []
    selected_groups = set()
    for row in sorted(corpus, key=rank):
        group = groups[row["id"]]
        if group not in selected_groups:
            selected.append(row)
            selected_groups.add(group)
        if len(selected) == RETRIEVAL_K:
            break
    return selected


def build_cases(
    products: list[dict],
    pairs: list[tuple[dict, dict]],
    assignments: dict[str, str],
    groups: dict[str, str],
    seed: int,
    scale_fraction: float,
) -> tuple[list[dict], list[dict], dict]:
    corpus = [
        row for row in products if assignments[row["id"]] == "corpus" and row["eligible_for_development"]
    ]
    training_groups = {groups[row["id"]] for row in corpus}
    if not pairs or len(training_groups) < RETRIEVAL_K:
        raise ValueError("Faltan pares de tuning o grupos de corpus para recuperación")
    pilot_groups = [groups[row["id"]] for pair in pairs for row in pair]
    if len(set(pilot_groups)) != len(pilot_groups) or training_groups.intersection(pilot_groups):
        raise ValueError("Un grupo se reutiliza en pares o cruza corpus y tuning")
    if any(
        assignments[row["id"]] != "tuning" or not row["eligible_for_development"]
        for pair in pairs for row in pair
    ):
        raise ValueError("Los pares deben ser elegibles y proceder exclusivamente de tuning")

    tolerance = _tolerances(corpus, scale_fraction)
    scales = _stage_scales(corpus)
    public, references = [], []
    labels = Counter()
    sensitivity_changes = full_agreement = 0
    for a, b in pairs:
        context = _context(a)
        if any(context[field].casefold() != _context(b)[field].casefold() for field in CONTEXT_FIELDS):
            raise ValueError("El par contiene contextos de consumo incompatibles")
        pair_id = "P-" + sha256(canonical_bytes([seed, a["id"], b["id"]])).hexdigest()[:16]
        relation = compare_impacts(a["total"], b["total"], tolerance)
        sensitivity = compare_impacts(a["summary_total"], b["summary_total"], tolerance)
        labels[relation] += 1
        sensitivity_changes += relation != sensitivity
        full_agreement += relation == compare_impacts(
            calculate_impacts(a["stages"]), calculate_impacts(b["stages"]), tolerance
        )
        masks = zip(_nested_masks(a, seed, pair_id), _nested_masks(b, seed, pair_id), strict=True)
        for n, (hidden_a, hidden_b) in zip(MASK_COUNTS, masks, strict=True):
            observed = {"A": _observed_profile(a, "A", hidden_a), "B": _observed_profile(b, "B", hidden_b)}
            retrieved = _retrieve(corpus, groups, context, observed, scales)
            case_id = f"{pair_id}-M{n}"
            payload = {
                "case_id": case_id,
                "pair_id": pair_id,
                "partition": "tuning",
                "masked_stages_per_product": n,
                "context": context,
                "units": UNITS,
                "tolerance": tolerance,
                "hidden_stages": {"A": sorted(hidden_a), "B": sorted(hidden_b)},
                "observed_stages": observed,
                "retrieved_corpus_examples": [
                    {"evidence_id": f"R-{i}", "context": _context(row), "stages": row["stages"]}
                    for i, row in enumerate(retrieved, start=1)
                ],
            }
            public.append(payload)
            references.append({
                "case_id": case_id,
                "pair_id": pair_id,
                "partition": "tuning",
                "products": {side: row["id"] for side, row in zip(SIDES, (a, b), strict=True)},
                "groups": {side: groups[row["id"]] for side, row in zip(SIDES, (a, b), strict=True)},
                "official_stage_tab_totals": {"A": a["total"], "B": b["total"]},
                "summary_totals": {"A": a["summary_total"], "B": b["summary_total"]},
                "expected_relation": relation,
                "sensitivity_relation": sensitivity,
                "retrieved_corpus_product_ids": [row["id"] for row in retrieved],
                "payload_sha256": sha256(canonical_bytes(payload)).hexdigest(),
            })

    validate_public_cases(public, len(pairs))
    return public, references, {
        "tuning_pairs": len(pairs),
        "corpus_products": len(corpus),
        "corpus_groups": len(training_groups),
        "scenarios": len(public),
        "reference_labels_by_pair": dict(sorted(labels.items())),
        "summary_reference_disagreements_by_pair": sensitivity_changes,
        "fully_visible_stage_sum_agreements_by_pair": full_agreement,
        "tolerance": tolerance,
        "tolerance_rule": "max(scale_fraction times corpus median absolute total, one 3-significant-digit step at that median)",
    }


def validate_public_cases(cases: list[dict], pair_count: int) -> None:
    expected_keys = {
        "case_id", "pair_id", "partition", "masked_stages_per_product", "context", "units",
        "tolerance", "hidden_stages", "observed_stages", "retrieved_corpus_examples",
    }
    pairs = {}
    seen = set()
    for case in cases:
        if set(case) != expected_keys or case["partition"] != "tuning":
            raise ValueError("El payload solo acepta campos públicos de tuning")
        if case["units"] != UNITS or set(case["context"]) != set(CONTEXT_FIELDS):
            raise ValueError("Unidades o metadatos no autorizados en el payload")
        compare_impacts(dict.fromkeys(IMPACTS, 0), dict.fromkeys(IMPACTS, 0), case["tolerance"])
        pair_id = case["pair_id"]
        n = case["masked_stages_per_product"]
        if (
            not re.fullmatch(r"P-[0-9a-f]{16}", pair_id) or type(n) is not int or n not in MASK_COUNTS
            or case["case_id"] != f"{pair_id}-M{n}" or case["case_id"] in seen
        ):
            raise ValueError("Identificador o nivel de máscara inválido")
        seen.add(case["case_id"])
        hidden = case["hidden_stages"]
        observed = case["observed_stages"]
        if set(hidden) != set(SIDES) or set(observed) != set(SIDES):
            raise ValueError("El caso debe contener dos alternativas")
        for side in SIDES:
            if len(hidden[side]) != n or len(set(hidden[side])) != n:
                raise ValueError("La máscara tiene una longitud incorrecta")
            if set(observed[side]) != set(STAGE_FIELDS) - set(hidden[side]):
                raise ValueError("El payload revela una etapa oculta o pierde una etapa visible")
            for stage, record in observed[side].items():
                if set(record) != {"evidence_id", "impacts"} or record["evidence_id"] != f"OBS-{side}-{stage}":
                    raise ValueError("Evidencia observada fuera de contrato")
                calculate_impacts({stage: record["impacts"]})
        retrieved = case["retrieved_corpus_examples"]
        if len(retrieved) != RETRIEVAL_K:
            raise ValueError("Faltan ejemplos del corpus")
        for index, example in enumerate(retrieved, start=1):
            if (
                set(example) != {"evidence_id", "context", "stages"}
                or example["evidence_id"] != f"R-{index}"
                or set(example["context"]) != set(CONTEXT_FIELDS)
                or set(example["stages"]) != set(STAGE_FIELDS)
            ):
                raise ValueError("Evidencia de recuperación fuera de contrato")
            calculate_impacts(example["stages"])
        pairs.setdefault(pair_id, {})[n] = hidden

    if len(pairs) != pair_count or len(cases) != pair_count * len(MASK_COUNTS):
        raise ValueError("Faltan pares o escenarios")
    for levels in pairs.values():
        if set(levels) != set(MASK_COUNTS) or any(
            not set(levels[2][side]) < set(levels[4][side]) for side in SIDES
        ):
            raise ValueError("Las máscaras deben estar anidadas dentro del mismo par")


def write_case_jsonl(path: Path, rows: list[dict]) -> str:
    content = b"".join(canonical_bytes(row) + b"\n" for row in rows)
    with path.open("xb") as stream:
        stream.write(content)
    return sha256(content).hexdigest()
