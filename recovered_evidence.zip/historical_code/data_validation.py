"""Validate the raw 3.2 consumer-ready extracts for a development run."""

import csv
import json
import re
from decimal import Decimal
from pathlib import Path
from tempfile import NamedTemporaryFile

from src.data_io import verify_source

IMPACT_FIELDS = {
    "climate_change": ("Changement climatique", "kg CO2 eq/kg de produit"),
    "water_use": ("Épuisement des ressources eau", "m3 depriv./kg de produit"),
    "freshwater_eutrophication": ("Eutrophisation eaux douces", "kg P eq/kg de produit"),
}
STAGE_FIELDS = {
    "agriculture": "Agriculture",
    "processing": "Transformation",
    "packaging": "Emballage",
    "transport": "Transport",
    "distribution": "Supermarché et distribution",
    "consumption": "Consommation",
}
PRODUCT_FIELDS = {
    "ciqual": "Code CIQUAL",
    "family": "Groupe d'aliment",
    "subgroup": "Sous-groupe d'aliment",
    "name": "Nom du Produit en Français",
    "lci": "LCI Name",
}
NUMBER = re.compile(r"[+-]?(?:[0-9]+(?:[.,][0-9]+)?)(?:[eE][+-]?[0-9]+)?")


def parse_number(value: str, label: str) -> Decimal:
    value = value.strip()
    if NUMBER.fullmatch(value) is None:
        raise ValueError(f"Valor ausente o no numérico: {label}")
    return Decimal(value.replace(",", "."))


def _identifier(value: str) -> str:
    value = value.strip()
    if value.isascii() and value.isdecimal():
        return value.lstrip("0") or "0"
    return value


def _normal_label(value: str) -> str:
    value = " ".join(value.split())
    if value.startswith('"') and value.endswith('"') and '""' in value:
        value = value[1:-1].replace('""', '"')
    return value.casefold()


def _read_rows(path: Path, columns: set[str]) -> tuple[dict, int]:
    rows = {}
    empty = 0
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None or not columns.issubset(reader.fieldnames):
            raise ValueError(f"Faltan columnas obligatorias en {path.name}")
        if len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError(f"Cabeceras duplicadas en {path.name}")
        for row in reader:
            if None in row or None in row.values():
                raise ValueError(f"Cardinalidad de columnas inesperada en {path.name}:{reader.line_num}")
            if not any(value.strip() for value in row.values()):
                empty += 1
                continue
            key = _identifier(row["Code AGB"])
            if not key or key in rows:
                raise ValueError(f"Clave AGB ausente o duplicada en {path.name}:{reader.line_num}")
            rows[key] = row
    return rows, empty


def _three_digit_rounding(value: Decimal) -> Decimal:
    return Decimal("0.5").scaleb(value.adjusted() - 2) if value else Decimal(0)


def load_products(root: Path, manifest: dict, *, include_excluded: bool = False) -> tuple[list[dict], list[dict], dict]:
    raw = (root / "data/raw").resolve()
    if not raw.is_relative_to(root):
        raise ValueError("El directorio de datos originales debe quedar en el proyecto")
    paths = {}
    for role, source in manifest["sources"].items():
        path = (raw / source["file"]).resolve()
        if path.parent != raw:
            raise ValueError(f"Nombre de archivo inválido: {role}")
        verify_source(path, source)
        paths[role] = path

    common = {"Code AGB", *PRODUCT_FIELDS.values()}
    total_columns = {name for name, _ in IMPACT_FIELDS.values()}
    stage_columns = {f"{name} - {stage}" for name in total_columns for stage in STAGE_FIELDS.values()}
    totals, empty_totals = _read_rows(paths["summary"], common | total_columns | {"DQR", "Préparation"})
    detail, empty_detail = _read_rows(paths["stages"], common | stage_columns)
    if not totals or set(totals) != set(detail):
        raise ValueError("El cruce de los extractos por clave AGB normalizada debe ser uno a uno")

    products, exclusions = [], []
    padded, eligible = 0, 0
    outside = dict.fromkeys(IMPACT_FIELDS, 0)
    max_relative = dict.fromkeys(IMPACT_FIELDS, 0.0)
    for key, row in sorted(totals.items()):
        stage_row = detail[key]
        padded += row["Code AGB"] != stage_row["Code AGB"]
        for field in ("ciqual", "family", "subgroup"):
            name = PRODUCT_FIELDS[field]
            if _normal_label(row[name]) != _normal_label(stage_row[name]):
                raise ValueError(f"{key}: metadatos incompatibles en {name}")

        reasons = [
            f"METADATA_DISAGREEMENT_{field.upper()}"
            for field in ("name", "lci")
            if _normal_label(row[PRODUCT_FIELDS[field]]) != _normal_label(stage_row[PRODUCT_FIELDS[field]])
        ]
        total, stages = {}, {stage: {} for stage in STAGE_FIELDS}
        for impact, (column, _unit) in IMPACT_FIELDS.items():
            published = parse_number(row[column], f"{key}/{column}")
            values = {
                stage: parse_number(stage_row[f"{column} - {name}"], f"{key}/{column}/{stage}")
                for stage, name in STAGE_FIELDS.items()
            }
            difference = abs(sum(values.values()) - published)
            allowance = _three_digit_rounding(published) + sum(map(_three_digit_rounding, values.values()))
            if published:
                max_relative[impact] = max(max_relative[impact], float(difference / abs(published)))
            if difference > allowance:
                outside[impact] += 1
                reasons.append(f"STAGE_SUM_DISAGREEMENT_{impact.upper()}")
            total[impact] = float(published)
            for stage, value in values.items():
                stages[stage][impact] = float(value)

        exclusions.extend({"product_id": key, "reason": reason} for reason in reasons)
        eligible += not reasons
        if reasons and not include_excluded:
            continue
        products.append({
            "id": key,
            **{name: row[field].strip() for name, field in PRODUCT_FIELDS.items()},
            "preparation": row["Préparation"].strip(),
            "dqr": float(parse_number(row["DQR"], f"{key}/DQR")),
            "eligible_for_development": not reasons,
            "total": total,
            "stages": stages,
        })

    audit = {
        "status": "DEVELOPMENT_ONLY",
        "version": manifest["version"],
        "joined_products": len(totals),
        "padded_id_matches": padded,
        "blank_rows": {"summary": empty_totals, "stages": empty_detail},
        "outside_provisional_rounding_by_impact": outside,
        "max_absolute_relative_difference_by_impact": max_relative,
        "included_products": eligible,
        "excluded_products": len(totals) - eligible,
        "rounding_rule": "Half a three-significant-digit unit per nonzero term, summed across the total and six stages; provisional development screen",
    }
    return products, exclusions, audit


def _write_atomic(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile(dir=path.parent, delete=False) as stream:
        temp = Path(stream.name)
        stream.write(content)
    try:
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def write_prepared(root: Path, products: list[dict], exclusions: list[dict], audit: dict) -> None:
    import io

    import pyarrow as pa
    import pyarrow.parquet as pq

    product_rows = [{key: value for key, value in row.items() if key != "stages"} for row in products]
    stage_rows = [
        {"product_id": row["id"], "stage": stage, **values}
        for row in products
        for stage, values in row["stages"].items()
    ]
    for name, rows in (("products", product_rows), ("stage_impacts", stage_rows)):
        buffer = pa.BufferOutputStream()
        pq.write_table(pa.Table.from_pylist(rows), buffer, compression="zstd")
        _write_atomic(root / f"data/processed/{name}.parquet", buffer.getvalue().to_pybytes())
    exclusions_csv = io.StringIO()
    writer = csv.DictWriter(exclusions_csv, fieldnames=["product_id", "reason"], lineterminator="\n")
    writer.writeheader()
    writer.writerows(exclusions)
    _write_atomic(root / "docs/exclusion_log.csv", exclusions_csv.getvalue().encode("utf-8"))
    _write_atomic(root / "data/processed/preparation_audit.json", json.dumps(audit, indent=2).encode())
