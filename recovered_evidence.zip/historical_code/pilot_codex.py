"""One ChatGPT-authenticated Codex CLI turn for a development pilot pass."""

import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from tempfile import TemporaryDirectory
from time import perf_counter


MAX_PROMPT_BYTES = 16_384
MAX_RESPONSE_BYTES = 8_192
MAX_REPORTED_TOKENS = 32_768
PASS_TIMEOUT_SECONDS = 75
_EFFORTS = {"none", "minimal", "low", "medium", "high", "xhigh"}
_CREDENTIAL_OVERRIDES = (
    "OPENAI_API_KEY",
    "CODEX_API_KEY",
    "CODEX_ACCESS_TOKEN",
    "OPENAI_ACCESS_TOKEN",
    "OPENAI_FEDERATION_RULE_ID",
    "OPENAI_IDENTITY_TOKEN_FILE",
    "OPENAI_WORKLOAD_IDENTITY_CONTEXT",
    "OPENAI_BASE_URL",
    "CHATGPT_BASE_URL",
    "CODEX_CHATGPT_BASE_URL",
    "CODEX_BASE_URL",
)
_DISABLED_FEATURES = (
    "shell_tool",
    "code_mode",
    "apps",
    "plugins",
    "multi_agent",
    "multi_agent_v2",
    "hooks",
    "skill_mcp_dependency_install",
)


def _cli_environment() -> dict[str, str]:
    env = os.environ.copy()
    for name in _CREDENTIAL_OVERRIDES:
        env.pop(name, None)
    env["RUST_LOG"] = "error"
    return env


def _read_events(stdout: str | bytes) -> tuple[list[dict], int]:
    if isinstance(stdout, bytes):
        stdout = stdout.decode("utf-8", errors="replace")
    events, malformed = [], 0
    for line in stdout.splitlines():
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except (ValueError, RecursionError):
            malformed += 1
            continue
        if isinstance(event, dict) and isinstance(event.get("type"), str):
            events.append(event)
        else:
            malformed += 1
    return events, malformed


def _turn_usage(turn: dict) -> dict[str, int]:
    usage = turn.get("usage")
    if not isinstance(usage, dict):
        return {}
    return {
        key: value
        for key, value in usage.items()
        if type(value) is int and value >= 0
    }


def _interpret_attempt(
    stdout: str | bytes,
    return_code: int | None,
    *,
    max_response_bytes: int,
    max_reported_tokens: int,
) -> tuple[str, dict]:
    events, malformed = _read_events(stdout)
    turns = [event for event in events if event["type"] == "turn.completed"]
    items = [
        event["item"]
        for event in events
        if isinstance(event.get("item"), dict)
    ]
    observed_item_types = {
        item["type"] if isinstance(item.get("type"), str) else "<invalid>" for item in items
    }
    tool_types = observed_item_types - {"agent_message", "reasoning"}
    replies = [
        event["item"]["text"]
        for event in events
        if event["type"] == "item.completed"
        and isinstance(event.get("item"), dict)
        and event["item"].get("type") == "agent_message"
        and isinstance(event["item"].get("text"), str)
    ]
    reply = replies[-1] if replies else ""
    response_bytes = len(reply.encode("utf-8", errors="replace"))
    usage_by_turn = [_turn_usage(turn) for turn in turns]
    usage = usage_by_turn[0] if len(usage_by_turn) == 1 else {}
    total_tokens = (
        usage["input_tokens"] + usage["output_tokens"]
        if {"input_tokens", "output_tokens"} <= usage.keys()
        else None
    )
    if return_code is None:
        status = "CLI_TIMEOUT"
    elif return_code != 0 or any(event["type"] in {"error", "turn.failed"} for event in events):
        status = "CLI_FAILED"
    elif malformed:
        status = "MALFORMED_CLI_EVENTS"
    elif len(turns) != 1:
        status = "UNEXPECTED_TURN_COUNT"
    elif tool_types:
        status = "UNEXPECTED_TOOL_EVENTS"
    elif not reply.strip():
        status = "MISSING_REPLY"
    elif response_bytes > max_response_bytes:
        status = "RESPONSE_BYTE_LIMIT"
    elif total_tokens is None:
        status = "MISSING_TOKEN_USAGE"
    elif total_tokens > max_reported_tokens:
        status = "REPORTED_TOKEN_LIMIT"
    else:
        status = "OK"
    return reply, {
        "transport_status": status,
        "cli_return_code": return_code,
        "completed_cli_turns": len(turns),
        "malformed_cli_event_lines": malformed,
        "observed_tool_event_types": sorted(tool_types),
        "response_utf8_bytes": response_bytes,
        "cli_reported_token_usage": usage,
        "cli_reported_usage_by_completed_turn": usage_by_turn,
        "reported_input_plus_output_tokens": total_tokens,
        "model_ids_reported_by_cli_events": sorted({
            event["model"] for event in events if isinstance(event.get("model"), str)
        }),
    }


def invoke_structured(
    prompt: str,
    schema: dict,
    workdir: Path,
    *,
    model: str,
    effort: str,
    prompt_byte_limit: int = MAX_PROMPT_BYTES,
    response_byte_limit: int = MAX_RESPONSE_BYTES,
    token_ceiling: int = MAX_REPORTED_TOKENS,
    timeout: int = PASS_TIMEOUT_SECONDS,
) -> tuple[str, dict]:
    """Attempt one isolated CLI turn and return raw text plus audit metadata.

    The caller validates the model's JSON and accounts for each scheduled pass.
    The token ceiling rejects an over-budget completed response locally. It
    cannot stop hosted generation before those tokens have been consumed.
    """
    limits = (prompt_byte_limit, response_byte_limit, token_ceiling, timeout)
    if any(type(value) is not int or value < 1 for value in limits):
        raise ValueError("Los límites de cada pasada deben ser enteros positivos.")
    if not re.fullmatch(r"[a-zA-Z0-9_.-]+", model) or effort not in _EFFORTS:
        raise ValueError("El piloto requiere un modelo y un esfuerzo explícitos.")

    parent = Path(workdir).resolve(strict=True)
    project = Path(__file__).resolve().parent.parent
    if not parent.is_dir() or parent.is_relative_to(project):
        raise ValueError("La inferencia requiere una carpeta temporal fuera del proyecto.")
    payload = prompt.encode("utf-8")
    prompt_bytes = len(payload)
    metadata = {
        "requested_model": model,
        "requested_reasoning_effort": effort,
        "provider": "openai",
        "inference": "hosted",
        "authentication": None,
        "paid_platform_api_key_used": False,
        "server_model_revision": None,
        "provider_requests": None,
        "provider_side_token_limit_enforced": False,
        "attempted_cli_turns": 0,
        "completed_cli_turns": 0,
        "cli_elapsed_seconds": None,
        "cli_reported_token_usage": {},
        "reported_input_plus_output_tokens": None,
        "prompt_utf8_bytes": prompt_bytes,
        "max_prompt_utf8_bytes": prompt_byte_limit,
        "max_accepted_response_utf8_bytes": response_byte_limit,
        "max_accepted_reported_input_plus_output_tokens": token_ceiling,
        "cli_timeout_seconds": timeout,
    }
    if prompt_bytes > prompt_byte_limit:
        return "", {**metadata, "transport_status": "PROMPT_BYTE_LIMIT"}
    codex = shutil.which("codex")
    if not codex:
        return "", {**metadata, "transport_status": "CODEX_NOT_FOUND"}

    env = _cli_environment()
    with TemporaryDirectory(prefix="pilot-turn-", dir=parent) as temporary:
        directory = Path(temporary).resolve()
        if not directory.is_relative_to(parent):
            raise ValueError("La carpeta temporal de inferencia debe quedar aislada.")
        options = {"cwd": directory, "env": env, "capture_output": True}
        try:
            auth = subprocess.run(
                [codex, "-c", 'model_provider="openai"', "login", "status"],
                timeout=12,
                encoding="utf-8",
                **options,
            )
        except (OSError, subprocess.TimeoutExpired):
            return "", {**metadata, "transport_status": "AUTH_STATUS_UNAVAILABLE"}
        if auth.returncode or "Logged in using ChatGPT" not in auth.stdout + auth.stderr:
            return "", {**metadata, "transport_status": "CHATGPT_AUTH_REQUIRED"}
        metadata["authentication"] = "existing ChatGPT CLI session"
        try:
            client = subprocess.run(
                [codex, "--version"], timeout=10, check=True, encoding="utf-8", **options
            )
        except (OSError, subprocess.SubprocessError):
            return "", {**metadata, "transport_status": "CLI_VERSION_UNAVAILABLE"}
        metadata["client"] = client.stdout.strip()

        schema_path = directory / "response-schema.json"
        schema_path.write_text(json.dumps(schema, allow_nan=False), encoding="utf-8")
        args = [
            codex, "--ask-for-approval", "never", "exec", "--ignore-user-config",
            "--skip-git-repo-check", "--ephemeral", "--sandbox", "read-only",
        ]
        for feature in _DISABLED_FEATURES:
            args.extend(["--disable", feature])
        args.extend([
            "-c", 'model_provider="openai"', "-c", 'forced_login_method="chatgpt"',
            "-c", 'web_search="disabled"', "-c", "project_doc_max_bytes=0",
            "-c", "mcp_servers={}", "-c", "hide_agent_reasoning=true",
            "-c", f'model_reasoning_effort="{effort}"',
            "--model", model, "--output-schema", str(schema_path), "--color", "never", "--json", "-",
        ])
        metadata["attempted_cli_turns"] = 1
        started = perf_counter()
        try:
            process = subprocess.run(args, input=payload, timeout=timeout, **options)
            stdout, return_code = process.stdout, process.returncode
        except subprocess.TimeoutExpired as error:
            stdout, return_code = error.stdout or b"", None
        except (OSError, UnicodeError):
            return "", {
                **metadata,
                "transport_status": "CLI_EXEC_UNAVAILABLE",
                "cli_elapsed_seconds": round(perf_counter() - started, 3),
            }
        metadata["cli_elapsed_seconds"] = round(perf_counter() - started, 3)
        reply, observations = _interpret_attempt(
            stdout,
            return_code,
            max_response_bytes=response_byte_limit,
            max_reported_tokens=token_ceiling,
        )
        return reply, {**metadata, **observations}
