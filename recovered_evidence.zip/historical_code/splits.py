"""Agrupación propuesta y pares exploratorios de desarrollo para AGRIBALYSE 3.2."""

import hashlib
import math
import re
import unicodedata
from collections import Counter, defaultdict
from numbers import Real


PARTITIONS = ("corpus", "tuning", "calibration", "test")
DEFAULT_PROPORTIONS = dict(zip(PARTITIONS, (0.5, 0.2, 0.1, 0.2)))
DEVELOPMENT_SUBGROUPS = {
    "algues", "fruits", "legumes", "legumineuses", "poissons crus", "poissons cuits",
    "mollusques et crustaces crus", "mollusques et crustaces cuits",
}
FORM_PATTERNS = {
    "raw": r"\bcrue?s?\b",
    "cooked": r"\b(?:cuite?s?|bouillie?s?|grillee?s?|poelee?s?|rotie?s?|braisee?s?)\b",
    "fresh": r"\b(?:frais|fraiches?)\b",
    "dried": r"\b(?:secs?|seche|seches|sechee|sechees|deshydratee?s?)\b",
    "canned": r"\b(?:appertisee?s?|en conserve|en boite)\b",
    "frozen": r"\b(?:sur)?congelee?s?\b|\bsurgelee?s?\b",
    "smoked": r"\bfumee?s?\b",
    "drained": r"(?<!non )\begouttee?s?\b",
    "undrained": r"\bnon egouttee?s?\b",
    "skinned": r"\b(?:pele|epluche)e?s?\b",
    "oven": r"\bau four\b",
    "steam": r"\ba la vapeur\b",
    "water": r"\ba l eau\b",
    "grill_pan": r"\b(?:grillee?s?|poelee?s?)\b",
}
PRIMARY_FORMS = {"raw", "cooked", "fresh", "dried", "canned", "frozen", "smoked"}
EXCLUDE_FORM = re.compile(
    r"\b(?:melanges?|sauces?|salades?|compotes?|purees?|jus|sirops?|poudres?|farines?|"
    r"a reconstituer|pour cuisson|(?:non )?rehydratee?s?|reconstituee?s?)\b"
)


def _text(value):
    if not isinstance(value, str):
        return ""
    folded = unicodedata.normalize("NFKD", value.casefold().replace("œ", "oe"))
    plain = "".join(char for char in folded if not unicodedata.combining(char))
    return " ".join(re.findall(r"[a-z0-9]+", plain))


def _index(products):
    by_id = {}
    for product in products:
        product_id = product.get("id")
        if not isinstance(product_id, str) or not product_id or product_id != product_id.strip():
            raise ValueError("Cada producto debe tener un Code AGB de texto no vacío.")
        if product_id in by_id:
            raise ValueError(f"Code AGB duplicado: {product_id}.")
        by_id[product_id] = product
    return by_id


def _stage_fingerprint(product):
    stages = product.get("stages", {})
    impacts = set(product.get("total", {}))
    if len(stages) != 6 or len(impacts) != 3:
        return None
    signature = []
    for stage, row in sorted(stages.items()):
        if set(row) != impacts:
            return None
        ordered = tuple(sorted(row.items()))
        if any(isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value)
               for _, value in ordered):
            return None
        signature.append((stage, ordered))
    return tuple(signature)


def _group_keys(product):
    agb_base = re.sub(r"_\d+$", "", product["id"])
    ciqual = _text(product.get("ciqual"))
    name = product.get("name") or ""
    name_stem = _text(re.sub(r"\([^)]*\)", "", name).split(",", 1)[0])
    family = _text(product.get("family"))
    yield "agb", agb_base
    for key, value in (
        ("ciqual", ciqual), ("name", _text(name)), ("lci", _text(product.get("lci"))),
        ("family_name_stem", (family, name_stem) if family and name_stem else None),
        ("stages", _stage_fingerprint(product)),
    ):
        if value:
            yield key, value


def group_products(products):
    """Devuelve el componente transitivo de cada Code AGB, con ID mínimo estable."""
    by_id = _index(products)
    parent = {product_id: product_id for product_id in by_id}
    seen = {}

    def representative(product_id):
        while parent[product_id] != product_id:
            parent[product_id] = parent[parent[product_id]]
            product_id = parent[product_id]
        return product_id

    for product_id, product in sorted(by_id.items()):
        for key in _group_keys(product):
            previous = seen.setdefault(key, product_id)
            a, b = sorted((representative(previous), representative(product_id)))
            parent[b] = a
    return {product_id: representative(product_id) for product_id in sorted(by_id)}


def _order(seed, domain, key):
    return hashlib.sha256(f"{seed}\0{domain}\0{key}".encode("utf-8")).digest(), key


def split_groups(products, seed, proportions=None):
    """Asigna grupos íntegros a particiones propuestas, antes de construir casos."""
    proportions = DEFAULT_PROPORTIONS if proportions is None else proportions
    if set(proportions) != set(PARTITIONS) or any(
        isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value) or value <= 0
        for value in proportions.values()
    ) or not math.isclose(sum(proportions.values()), 1, rel_tol=0, abs_tol=1e-9):
        raise ValueError("Las cuatro proporciones de partición deben ser positivas y sumar 1.")

    by_id = _index(products)
    groups = group_products(by_id.values())
    group_strata = defaultdict(Counter)
    for product_id, group in groups.items():
        product = by_id[product_id]
        stratum = (_text(product.get("family")), _text(product.get("subgroup")))
        group_strata[group][stratum] += 1

    strata = defaultdict(list)
    for group, counts in group_strata.items():
        stratum = min(counts, key=lambda label: (-counts[label], label))
        strata[stratum].append(group)

    targets = {partition: len(group_strata) * proportions[partition] for partition in PARTITIONS}
    remaining = {partition: math.floor(targets[partition]) for partition in PARTITIONS}
    remainders = sorted(PARTITIONS, key=lambda p: -(targets[p] - remaining[p]))
    for partition in remainders[:len(group_strata) - sum(remaining.values())]:
        remaining[partition] += 1

    group_assignment = {}
    for stratum, members in sorted(strata.items(), key=lambda item: (-len(item[1]), item[0])):
        stratum_counts = Counter()
        for group in sorted(members, key=lambda key: _order(seed, "split", key)):
            partition = max(
                (p for p in PARTITIONS if remaining[p]),
                key=lambda p: (len(members) * proportions[p] - stratum_counts[p], remaining[p]),
            )
            group_assignment[group] = partition
            stratum_counts[partition] += 1
            remaining[partition] -= 1
    return {product_id: group_assignment[group] for product_id, group in groups.items()}


def _compatibility_key(product):
    family = _text(product.get("family"))
    subgroup = _text(product.get("subgroup"))
    preparation = _text(product.get("preparation"))
    name = _text(product.get("name"))
    if not family or subgroup not in DEVELOPMENT_SUBGROUPS or not preparation or EXCLUDE_FORM.search(name):
        return None
    forms = tuple(form for form, pattern in FORM_PATTERNS.items() if re.search(pattern, name))
    if not PRIMARY_FORMS.intersection(forms) or {"raw", "cooked"}.issubset(forms):
        return None
    return family, subgroup, preparation, forms


def build_pairs(products, assignments, partition, seed):
    """Construye pares exploratorios de tuning y utiliza cada grupo a lo sumo una vez."""
    if partition != "tuning":
        raise ValueError("Los pares exploratorios solo se construyen en tuning.")
    by_id = _index(products)
    if set(assignments) != set(by_id) or any(value not in PARTITIONS for value in assignments.values()):
        raise ValueError("La asignación debe cubrir cada Code AGB con una partición reconocida.")

    groups = group_products(by_id.values())
    group_partitions = defaultdict(set)
    eligible = defaultdict(lambda: defaultdict(list))
    for product_id, group in groups.items():
        group_partitions[group].add(assignments[product_id])
        product = by_id[product_id]
        if assignments[product_id] == partition and product.get("eligible_for_development", True) is True:
            key = _compatibility_key(product)
            if key is not None:
                eligible[key][group].append(product_id)
    if any(len(partitions) > 1 for partitions in group_partitions.values()):
        raise ValueError("La asignación separa integrantes de un mismo grupo.")

    used = set()
    pairs = []
    for _, members in sorted(eligible.items(), key=lambda item: (len(item[1]), item[0])):
        candidates = sorted(set(members) - used, key=lambda key: _order(seed, "pair", key))
        for group_a, group_b in zip(candidates[::2], candidates[1::2]):
            id_a = min(members[group_a], key=lambda key: _order(seed, "representative", key))
            id_b = min(members[group_b], key=lambda key: _order(seed, "representative", key))
            pairs.append((by_id[id_a], by_id[id_b]))
            used.update((group_a, group_b))
    return pairs
