"""Point-prediction controls for the AGRIBALYSE development exercise."""

import csv
import json
from collections import defaultdict
from hashlib import sha256
from math import asinh, isfinite, sinh
from pathlib import Path
from random import Random
from statistics import median

from src.data_validation import STAGE_FIELDS
from src.reference import IMPACTS, calculate_impacts, compare_impacts


def _nested_masks(product: dict, seed: int, scope: str) -> list[frozenset[str]]:
    stages = list(STAGE_FIELDS)
    identity = sha256(f"{seed}:{scope}:{product['id']}".encode()).digest()
    Random(identity).shuffle(stages)
    return [frozenset(stages[:n]) for n in (0, 2, 4)]


def _observed(product: dict, mask: frozenset[str]) -> dict:
    return {stage: values for stage, values in product["stages"].items() if stage not in mask}


def _scale(corpus: list[dict], stage: str, impact: str) -> float:
    values = [abs(row["stages"][stage][impact]) for row in corpus if row["stages"][stage][impact]]
    return median(values) if values else 1.0


def _strata(product: dict) -> tuple:
    return (product["family"], product["subgroup"]), (product["family"],), ()


class HierarchicalMedian:
    def __init__(self, corpus: list[dict]):
        cells = defaultdict(list)
        for product in corpus:
            for stage, profile in product["stages"].items():
                for level in _strata(product):
                    for impact, value in profile.items():
                        cells[level, stage, impact].append(value)
        self.medians = {key: median(values) for key, values in cells.items()}

    def predict_stage(self, product: dict, stage: str, observed: dict) -> dict:
        return {
            impact: next(
                self.medians[level, stage, impact]
                for level in _strata(product)
                if (level, stage, impact) in self.medians
            )
            for impact in IMPACTS
        }


class CorpusRidge:
    """Fit one multi-impact model per hidden stage using only corpus masks."""

    def __init__(self, corpus: list[dict], seed: int):
        from sklearn.feature_extraction import DictVectorizer
        from sklearn.linear_model import Ridge

        self.scales = {
            (stage, impact): _scale(corpus, stage, impact)
            for stage in STAGE_FIELDS
            for impact in IMPACTS
        }
        features, labels = defaultdict(list), defaultdict(list)
        for product in corpus:
            for mask in _nested_masks(product, seed, "train")[1:]:
                observed = _observed(product, mask)
                public = _product_context(product)
                feature = self._features(public, observed)
                for stage in mask:
                    features[stage].append(feature)
                    labels[stage].append([
                        asinh(product["stages"][stage][impact] / self.scales[stage, impact])
                        for impact in IMPACTS
                    ])
        self.models = {}
        for stage in STAGE_FIELDS:
            encoder = DictVectorizer()
            matrix = encoder.fit_transform(features[stage])
            model = Ridge(alpha=1.0, solver="lsqr").fit(matrix, labels[stage])
            self.models[stage] = encoder, model

    def _features(self, product: dict, observed: dict) -> dict:
        features = {key: product[key] for key in ("family", "subgroup", "preparation")}
        for stage in STAGE_FIELDS:
            features[f"{stage}:absent"] = float(stage not in observed)
            if stage in observed:
                for impact in IMPACTS:
                    value = observed[stage][impact]
                    features[f"{stage}:{impact}"] = asinh(value / self.scales[stage, impact])
        return features

    def predict_stage(self, product: dict, stage: str, observed: dict) -> dict:
        encoder, model = self.models[stage]
        estimate = model.predict(encoder.transform([self._features(product, observed)]))[0]
        return {
            impact: sinh(float(value)) * self.scales[stage, impact]
            for impact, value in zip(IMPACTS, estimate, strict=True)
        }


def _product_context(product: dict) -> dict:
    return {key: product[key] for key in ("family", "subgroup", "preparation")}


def _predict_total(model, product: dict, observed: dict) -> dict:
    public = _product_context(product)
    completed = dict(observed)
    for stage in STAGE_FIELDS:
        if stage not in observed:
            completed[stage] = model.predict_stage(public, stage, observed)
    return calculate_impacts(completed)


def evaluate_development(
    corpus: list[dict],
    pairs: list[tuple[dict, dict]],
    seed: int,
    tolerance_fraction: float,
) -> tuple[list[dict], dict]:
    if not corpus or not pairs:
        raise ValueError("El diagnóstico requiere productos de corpus y pares de tuning")
    if not isfinite(tolerance_fraction) or tolerance_fraction < 0:
        raise ValueError("La fracción de tolerancia debe ser finita y no negativa")
    training_ids = {row["id"] for row in corpus}
    tuning_ids = [row["id"] for pair in pairs for row in pair]
    if training_ids.intersection(tuning_ids) or len(set(tuning_ids)) != len(tuning_ids):
        raise ValueError("Se detectaron productos compartidos o repetidos")

    tolerance = {
        impact: tolerance_fraction * median(abs(row["total"][impact]) for row in corpus)
        for impact in IMPACTS
    }
    models = {"B0": HierarchicalMedian(corpus), "B1": CorpusRidge(corpus, seed)}
    results = []
    for a, b in pairs:
        case = sha256(f"{a['id']}:{b['id']}".encode()).hexdigest()[:16]
        reference = compare_impacts(a["total"], b["total"], tolerance)
        for mask_a, mask_b in zip(_nested_masks(a, seed, case), _nested_masks(b, seed, case), strict=True):
            observed_a, observed_b = _observed(a, mask_a), _observed(b, mask_b)
            for label, model in models.items():
                prediction = compare_impacts(
                    _predict_total(model, a, observed_a),
                    _predict_total(model, b, observed_b),
                    tolerance,
                )
                results.append({
                    "case_id": case,
                    "masked_stages_per_product": len(mask_a),
                    "method": label,
                    "relation": prediction,
                    "published_total_reference": reference,
                    "error": int(prediction != reference),
                })
    strata = defaultdict(list)
    for result in results:
        strata[result["method"], result["masked_stages_per_product"]].append(result["error"])
    metrics = [
        {"method": method, "masked_stages_per_product": mask, "pairs": len(errors), "errors": sum(errors)}
        for (method, mask), errors in sorted(strata.items())
    ]
    return results, {
        "status": "DEVELOPMENT_ONLY",
        "partition": "tuning",
        "training_products": len(corpus),
        "distinct_pairs": len(pairs),
        "tolerance": tolerance,
        "tolerance_rule": "Draft scale fraction × corpus median absolute published impact; no final rounding floor",
        "metrics": metrics,
        "llm_calls": 0,
        "probability_calibration": "NOT_RUN",
        "final_test_opened": False,
    }


def write_development_run(target: Path, results: list[dict], summary: dict) -> None:
    target.mkdir(parents=True, exist_ok=False)
    with (target / "cases.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)
    (target / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
