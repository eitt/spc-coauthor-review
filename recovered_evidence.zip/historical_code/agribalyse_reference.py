"""Reconcile the official stage worksheet and screen ADEME's known data errors."""

from collections import Counter, defaultdict
from decimal import Decimal
from math import fsum, isfinite, ulp
from pathlib import Path
import re
import unicodedata

from src.data_io import verify_source
from src.data_validation import (
    IMPACT_FIELDS,
    STAGE_FIELDS,
    _identifier,
    _normal_label,
    _three_digit_rounding,
    load_products,
)


WORKBOOK_FILE_ID = 641911
WORKBOOK_RELEASE = "15.0"
WORKBOOK_URL = f"https://entrepot.recherche.data.gouv.fr/api/access/datafile/{WORKBOOK_FILE_ID}"
PACKAGING_DUPLICATES = {"9901", "26232", "26013", "25998", "26037", "26034", "27029"}
ERROR_TERMS = {
    "EGG": re.compile(r"\b(?:oeufs?|eggs?)\b"),
    "QUINOA": re.compile(r"\bquinoa\b"),
}


def _source_error_flags(text: str) -> set[str]:
    normalized = unicodedata.normalize("NFKD", text.casefold().replace("œ", "oe"))
    normalized = "".join(char for char in normalized if not unicodedata.combining(char))
    return {reason for reason, pattern in ERROR_TERMS.items() if pattern.search(normalized)}


def _value_row(sheet, row: int) -> tuple:
    return next(sheet.iter_rows(min_row=row, max_row=row, values_only=True))


def _impact_columns(sheet, *, stages: bool) -> dict[str, int]:
    headers = _value_row(sheet, 2)
    units = _value_row(sheet, 3)
    labels = _value_row(sheet, 4) if stages else units
    id_header = str(labels[0]).replace("\n", " ")
    if id_header != "Code AGB":
        raise ValueError(f"{sheet.title}: falta la cabecera de código AGB")
    columns = {}
    expected_stages = (*STAGE_FIELDS.values(), "Total")
    for impact, (heading, unit) in IMPACT_FIELDS.items():
        if headers.count(heading) != 1:
            raise ValueError(f"{sheet.title}: encabezado de impacto ausente o duplicado ({heading})")
        index = headers.index(heading)
        if units[index] != unit or (stages and labels[index:index + 7] != expected_stages):
            raise ValueError(f"{sheet.title}: unidad o etapas inesperadas ({heading})")
        columns[impact] = index
    return columns


def _number(value, label: str) -> float:
    if type(value) not in (int, float) or not isfinite(value):
        raise ValueError(f"Valor no numérico o no finito en el libro: {label}")
    return float(value)


def _match_rows(
    sheet,
    first_row: int,
    match_columns: list[int],
    last_column: int,
    expected: dict[str, tuple],
    products: dict[str, dict],
) -> dict[str, tuple]:
    """Match all AGB rows against pinned CSV values, including revised packaging rows."""
    matched = {}
    counts = Counter()
    for row in sheet.iter_rows(min_row=first_row, max_col=last_column + 1, values_only=True):
        # The stage sheet's calculated "Nom et code" cell emits this text on blank rows.
        nonempty = [(index, value) for index, value in enumerate(row) if value is not None]
        if not nonempty or (sheet.title == "Detail etape" and nonempty == [(7, " ()")]):
            continue
        key = _identifier(str(row[0])) if row[0] is not None else ""
        if key not in products:
            raise ValueError(f"{sheet.title}: código AGB sin correspondencia ({key})")
        counts[key] += 1
        vector = tuple(_number(row[index], f"{sheet.title}/{key}/{index + 1}") for index in match_columns)
        if vector != expected[key]:
            continue
        if key in matched:
            raise ValueError(f"{sheet.title}: el CSV no distingue las versiones de {key}")
        product = products[key]
        if _identifier(str(row[1])) != _identifier(product["ciqual"]) or any(
            _normal_label(str(row[index])) != _normal_label(product[field])
            for index, field in ((2, "family"), (3, "subgroup"))
        ):
            raise ValueError(f"{sheet.title}: metadatos incompatibles para {key}")
        matched[key] = row
    if set(counts) != set(products) or set(matched) != set(products):
        raise ValueError(f"{sheet.title}: no se pudo conciliar cada AGB con su fila CSV")
    if {key for key, count in counts.items() if count == 2} != PACKAGING_DUPLICATES or max(counts.values()) != 2:
        raise ValueError(f"{sheet.title}: cardinalidad inesperada de correcciones de empaque")
    return matched


def _recipe_flags(sheet, products: dict[str, dict]) -> tuple[set[str], dict[str, set[str]]]:
    labels = _value_row(sheet, 3)
    if " ".join(str(labels[0]).split()) != "Ciqual AGB" or labels[6] != "Ingredients":
        raise ValueError("Detail ingredient: cambiaron las columnas de AGB o ingrediente")
    covered = set()
    flags = defaultdict(set)
    for row in sheet.iter_rows(min_row=4, max_col=7, values_only=True):
        if all(value is None for value in row):
            continue
        key = _identifier(str(row[0])) if row[0] is not None else ""
        if key not in products or not isinstance(row[6], str) or not row[6].strip():
            raise ValueError(f"Detail ingredient: código o ingrediente sin resolver ({key})")
        covered.add(key)
        flags[key].update(_source_error_flags(row[6]))
    return covered, flags


def _reconciliation(components: list[float], published: float, *, decimal_rounding: bool) -> tuple[float, bool]:
    if decimal_rounding:
        *parts, total = [Decimal(str(value)) for value in (*components, published)]
        difference = abs(sum(parts) - total)
        allowance = sum(
            max(Decimal("0.5").scaleb(value.as_tuple().exponent), _three_digit_rounding(value))
            for value in (*parts, total) if value
        )
        return float(difference), difference <= allowance
    difference = abs(fsum(components) - published)
    allowance = 16 * sum(ulp(value) for value in (*components, published))
    return difference, difference <= allowance


def load_reference(root: Path, manifest: dict) -> tuple[list[dict], list[dict], dict]:
    """Load all products and audit source totals without preparing experiment cases."""
    from openpyxl import load_workbook

    root = root.resolve()
    workbook_source = manifest.get("supplemental_audit_source", {})
    if (
        workbook_source.get("file_id") != WORKBOOK_FILE_ID
        or workbook_source.get("dataverse_release") != WORKBOOK_RELEASE
        or workbook_source.get("url") != WORKBOOK_URL
    ):
        raise ValueError("Se requiere el libro oficial de Dataverse 641911, versión 15.0")
    raw = (root / "data/raw").resolve()
    workbook_path = (raw / workbook_source["file"]).resolve()
    if not raw.is_relative_to(root) or workbook_path.parent != raw:
        raise ValueError("El libro original debe quedar en data/raw del proyecto")
    if not workbook_path.is_file():
        raise ValueError(f"Falta {workbook_path.name}. Fuente oficial: {WORKBOOK_URL}")
    verify_source(workbook_path, workbook_source)
    products, csv_exclusions, csv_audit = load_products(root, manifest, include_excluded=True)
    by_id = {product["id"]: product for product in products}

    workbook = load_workbook(workbook_path, read_only=True, data_only=True, keep_links=False)
    try:
        summary, detail = workbook["Synthese"], workbook["Detail etape"]
        summary_columns = list(_impact_columns(summary, stages=False).values())
        _match_rows(
            summary, 4, summary_columns, max(summary_columns),
            {key: tuple(product["total"].values()) for key, product in by_id.items()}, by_id,
        )
        stage_columns = _impact_columns(detail, stages=True)
        stage_rows = _match_rows(
            detail, 5,
            [index + offset for index in stage_columns.values() for offset in range(len(STAGE_FIELDS))],
            max(stage_columns.values()) + len(STAGE_FIELDS),
            {key: tuple(product["stages"][stage][impact] for impact in IMPACT_FIELDS for stage in STAGE_FIELDS)
             for key, product in by_id.items()},
            by_id,
        )
        recipe_covered, recipe_flags = _recipe_flags(workbook["Detail ingredient"], by_id)
    finally:
        workbook.close()

    exclusions = [record for record in csv_exclusions if record["reason"].startswith("METADATA_DISAGREEMENT_")]
    flagged = {record["product_id"] for record in exclusions}
    max_difference = dict.fromkeys(IMPACT_FIELDS, 0.0)
    max_relative = dict.fromkeys(IMPACT_FIELDS, 0.0)
    precision_counts = Counter()
    for product in products:
        key = product["id"]
        row = stage_rows[key]
        corrected_packaging = key in PACKAGING_DUPLICATES
        if corrected_packaging and "(emballage corrigé)" not in str(row[4]).casefold():
            raise ValueError(f"Detail etape: no se identificó el empaque corregido para {key}")
        same_tab = {}
        for impact, index in stage_columns.items():
            published = _number(row[index + len(STAGE_FIELDS)], f"Detail etape/{key}/{impact}/Total")
            components = [product["stages"][stage][impact] for stage in STAGE_FIELDS]
            decimal_rounding = impact == "climate_change" or corrected_packaging
            difference, matches = _reconciliation(components, published, decimal_rounding=decimal_rounding)
            if not matches:
                raise ValueError(f"El total oficial de etapas no concilia: {key}/{impact}")
            precision_counts["decimal" if decimal_rounding else "binary_ulp"] += 1
            max_difference[impact] = max(max_difference[impact], difference)
            if published:
                max_relative[impact] = max(max_relative[impact], difference / abs(published))
            same_tab[impact] = published

        names = (product["name"], product["lci"], str(row[4]), str(row[5]))
        name_flags = _source_error_flags(" ".join(names))
        for source, flags in (("NAME", name_flags), ("INGREDIENT", recipe_flags.get(key, set()))):
            for reason in sorted(flags):
                exclusions.append({"product_id": key, "reason": f"SOURCE_{reason}_ERROR_{source}"})
                flagged.add(key)
        product["summary_total"] = product["total"]
        product["total"] = same_tab
        product["eligible_for_development"] = key not in flagged

    audit = {
        "status": "REFERENCE_AUDITED",
        "version": manifest["version"],
        "joined_products": len(products),
        "included_products": len(products) - len(flagged),
        "excluded_products": len(flagged),
        "padded_id_matches": csv_audit["padded_id_matches"],
        "blank_rows": csv_audit["blank_rows"],
        "primary_reference": "Detail etape / Total",
        "sensitivity_reference": "Synthese / totals, matched to verified CSV",
        "packaging_corrected_agb": sorted(PACKAGING_DUPLICATES),
        "recipe_products_covered": len(recipe_covered),
        "recipe_products_not_covered": len(products) - len(recipe_covered),
        "exclusions_by_reason": dict(sorted(Counter(record["reason"] for record in exclusions).items())),
        "max_absolute_stage_difference_by_impact": max_difference,
        "max_absolute_relative_stage_difference_by_impact": max_relative,
        "reconciliations_by_precision": dict(precision_counts),
        "rounding_rule": "Climate and all impacts in the seven corrected packaging rows: "
                         "sum of larger half-steps at stored decimal or third significant digit. "
                         "Other water and eutrophication rows: 16 times sum of binary float ulps.",
        "workbook": {key: workbook_source[key] for key in ("file", "file_id", "dataverse_release", "url", "sha256")},
        "csv_sha256": {role: source["sha256"] for role, source in manifest["sources"].items()},
    }
    return products, sorted(exclusions, key=lambda item: (item["product_id"], item["reason"])), audit
