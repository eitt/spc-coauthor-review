"""Offline paired evaluation of the prespecified hosted study and corpus median B0."""

import argparse
from collections import Counter, defaultdict
from hashlib import sha256
import json
from math import comb, isfinite
from pathlib import Path
from random import Random
from statistics import mean

from src.baselines import HierarchicalMedian, _predict_total
from src.comparable_pilot_baselines import _validate_corpus
from src.confidence_scoring import SKIPPED, _outcome
from src.crewai_pilot import _jsonl, load_public_plan
from src.pilot_cases import CONTEXT_FIELDS, MASK_COUNTS, SIDES, canonical_bytes, validate_public_cases
from src.pilot_design import evaluate_pass
from src.pilot_scoring import _index
from src.reference import compare_impacts


CONTROL = "CONTROL_2PASS"
DOMINANCE = {"A_DOMINATES", "B_DOMINATES"}
MINIMUM_PAIRS = 77
MAXIMUM_PAIRS = 80
MAXIMUM_CONTROL_PAIRS = 24
CORPUS_SHA256 = "24428c173eb96defe96db88e4b94abb509e1fb5008c380d16e6897d10da066fc"
CORPUS_MANIFEST_SHA256 = "2a60b6f208e86da6b5422e0ab71e05b62936cff1cdc8c21362f33ec46c384a0c"
INTERVAL_ASSUMPTION = "Intervals assume independent pairs drawn from a common population."


def _digest(raw):
    return sha256(raw).hexdigest()


def load_b0_corpus(root):
    """Read only the original, attested eligible-corpus export, with no raw workbook I/O."""
    source = root / "data/private/pilot_baselines_001"
    manifest_raw = (source / "corpus_manifest.json").read_bytes()
    corpus_raw = (source / "corpus.jsonl").read_bytes()
    if _digest(manifest_raw) != CORPUS_MANIFEST_SHA256 or _digest(corpus_raw) != CORPUS_SHA256:
        raise ValueError("El corpus B0 o su manifiesto cambiaron desde la exportación fijada")
    manifest = json.loads(manifest_raw)
    corpus = _jsonl(corpus_raw)
    by_id = _validate_corpus(corpus)
    if (
        manifest["partition"] != "corpus" or manifest["status"] != "EXPORTED_ELIGIBLE_CORPUS"
        or manifest["corpus_sha256"] != CORPUS_SHA256
        or manifest["training_products"] != len(by_id)
        or manifest["training_groups"] != len({row["group"] for row in by_id.values()})
    ):
        raise ValueError("El manifiesto no acredita los productos y grupos del corpus B0")
    return corpus


def _verify_references(cases, truth, corpus):
    corpus_groups = {row["group"] for row in corpus.values()}
    used_ids, used_groups, members = set(), set(), {}
    for case_id, case in cases.items():
        ref = truth[case_id]
        pair, mask = case["pair_id"], case["masked_stages_per_product"]
        totals = ref["official_stage_tab_totals"]
        if (
            ref["partition"] != case["partition"] or ref["pair_id"] != pair
            or ref.get("masked_stages_per_product", mask) != mask
            or ref["payload_sha256"] != _digest(canonical_bytes(case))
            or ref["expected_relation"] != compare_impacts(totals["A"], totals["B"], case["tolerance"])
        ):
            raise ValueError(f"La referencia oficial no corresponde al caso fijado {case_id}")
        ids = tuple(ref["products"][side] for side in SIDES)
        groups = tuple(ref["groups"][side] for side in SIDES)
        signature = (ids, groups, totals, case["context"], case["tolerance"])
        if pair in members:
            if members[pair] != signature:
                raise ValueError(f"El par {pair} cambió entre sus máscaras")
        else:
            if (
                any(not isinstance(value, str) or not value.strip() for value in (*ids, *groups))
                or len(set(ids)) != 2 or len(set(groups)) != 2
                or set(ids).intersection(corpus) or set(groups).intersection(corpus_groups)
                or used_ids.intersection(ids) or used_groups.intersection(groups)
            ):
                raise ValueError(f"Se reutiliza un producto o grupo, o se cruza con el corpus en {pair}")
            members[pair] = signature
            used_ids.update(ids)
            used_groups.update(groups)
        retrieved_groups = set()
        for product_id, example in zip(ref["retrieved_corpus_product_ids"], case["retrieved_corpus_examples"], strict=True):
            row = corpus.get(product_id)
            if (
                row is None or row["group"] in retrieved_groups or row["stages"] != example["stages"]
                or any(row[field] != example["context"][field] for field in CONTEXT_FIELDS)
            ):
                raise ValueError(f"La evidencia recuperada no coincide con el corpus fijado en {case_id}")
            retrieved_groups.add(row["group"])
        full = cases[f"{pair}-M0"]["observed_stages"]
        if any(record != full[side][stage] for side in SIDES for stage, record in case["observed_stages"][side].items()):
            raise ValueError(f"Una etapa visible cambió entre máscaras en {case_id}")


def _orders(cases, planned_orders):
    if cases.keys() != planned_orders.keys():
        raise ValueError("El orden de brazos debe cubrir todos los casos fijados")
    orders = {}
    by_pair = defaultdict(set)
    for case_id, case in cases.items():
        order = tuple(planned_orders[case_id])
        if order not in {("A11",), ("A11", CONTROL), (CONTROL, "A11")}:
            raise ValueError(f"Orden de brazos fuera del diseño en {case_id}")
        orders[case_id] = order
        by_pair[case["pair_id"]].add(CONTROL in order)
    if any(len(flags) != 1 for flags in by_pair.values()) or sum(True in flags for flags in by_pair.values()) > MAXIMUM_CONTROL_PAIRS:
        raise ValueError("El control debe cubrir las tres máscaras de un máximo de 24 pares")
    return orders


def _b0(model, case):
    totals = {
        side: _predict_total(model, case["context"], {
            stage: record["impacts"] for stage, record in case["observed_stages"][side].items()
        }) for side in SIDES
    }
    relation = compare_impacts(totals["A"], totals["B"], case["tolerance"])
    return {"status": "VALID", "relation": relation, "totals": totals}


def _arm_outcome(row, canonical, case, expected):
    if row is not None:
        status = row["status"]
        transport = row.get("transport", {})
        transport_status = transport.get("transport_status")
        if status in {"PENDING", "RUNNING"}:
            if transport.get("attempted_cli_turns") not in (None, 0):
                raise ValueError(f"Un intento pendiente declara un turno completado en {case['case_id']}")
        elif status == "INVALID_OUTPUT":
            if transport.get("attempted_cli_turns") != 1 or (
                evaluate_pass(row["raw_response"], transport, canonical, case)["status"] != status
            ):
                raise ValueError(f"El fallo de validación guardado no se reproduce en {case['case_id']}")
        elif status not in {"VALID", SKIPPED} and status != transport_status:
            raise ValueError(f"El estado y el transporte no coinciden en {case['case_id']}")
        if status != "VALID" and row.get("relation") is not None:
            raise ValueError(f"Un intento no válido declara una relación en {case['case_id']}")
    outcome = _outcome(row, canonical, case, expected)
    return {key: outcome[key] for key in ("status", "loss", "relation") if key in outcome}


def _hosted_outcomes(case, expected, canonical, order, result, checkpoints):
    case_id = case["case_id"]
    arms = ("A10", *order)
    if checkpoints.keys() - set(arms):
        raise ValueError(f"Hay intentos de brazos fuera del diseño en {case_id}")
    rows = checkpoints
    if result is not None:
        rows = result["arms"]
        if (
            result.get("payload_sha256") != _digest(canonical_bytes(case))
            or result.get("second_pass_order") != list(order) or set(rows) != set(arms)
            or any(rows[arm] != saved for arm, saved in checkpoints.items())
        ):
            raise ValueError(f"El resultado no corresponde al payload, brazos u orden fijados en {case_id}")
    outcomes = {arm: _arm_outcome(rows.get(arm), canonical, case, expected) for arm in arms}
    first = rows.get("A10", {})
    first_transport_ok = first.get("transport", {}).get("transport_status") == "OK"
    first_failed = outcomes["A10"]["loss"] == 1 and not first_transport_ok
    if outcomes["A10"]["status"] == SKIPPED:
        raise ValueError(f"La primera pasada no puede figurar omitida en {case_id}")
    for arm in order:
        if outcomes[arm]["status"] == SKIPPED and not first_failed:
            raise ValueError(f"{arm} figura omitido sin fallo de transporte previo en {case_id}")
        if arm not in rows and first_failed:
            outcomes[arm] = {"status": SKIPPED, "loss": 1}
        if arm in rows and outcomes[arm]["status"] != SKIPPED and not first_transport_ok:
            raise ValueError(f"{arm} tiene un intento sin transporte previo satisfactorio en {case_id}")
    if result is not None and any(outcome["loss"] is None for outcome in outcomes.values()):
        raise ValueError(f"Un resultado finalizado incluye un brazo pendiente en {case_id}")
    return outcomes, rows


def _metrics(records, arm):
    scheduled = [row for row in records if arm in row["arms"]]
    settled = [row for row in scheduled if row["arms"][arm]["loss"] is not None]
    statuses = Counter(row["arms"][arm]["status"] for row in scheduled)
    claimed = [row for row in settled if row["arms"][arm].get("relation") in DOMINANCE]
    errors = sum(row["arms"][arm]["loss"] for row in settled)
    return {
        "scheduled_scenarios": len(scheduled), "settled_scenarios": len(settled),
        "pending_scenarios": len(scheduled) - len(settled), "status_counts": dict(statuses),
        "valid_scenarios": statuses["VALID"], "errors_including_failures": errors,
        "error_rate_among_settled": errors / len(settled) if settled else None,
        "dominance_claims": len(claimed),
        "false_dominance_claims": sum(row["arms"][arm]["loss"] for row in claimed),
    }


def _upper_binomial(successes, trials, alpha):
    """Upper one-sided exact binomial confidence bound by CDF inversion."""
    if successes == trials:
        return 1.0
    lo, hi = 0.0, 1.0
    coefficients = [comb(trials, k) for k in range(successes + 1)]
    for _ in range(53):
        p = (lo + hi) / 2
        cdf = sum(coefficient * p**k * (1 - p)**(trials - k) for k, coefficient in enumerate(coefficients))
        if cdf > alpha:
            lo = p
        else:
            hi = p
    return hi


def _percentile(sorted_values, probability):
    offset = probability * (len(sorted_values) - 1)
    index = int(offset)
    if index == offset:
        return sorted_values[index]
    return sorted_values[index] + (offset - index) * (sorted_values[index + 1] - sorted_values[index])


def _paired(records, left, right, precision):
    by_pair = defaultdict(list)
    pending = 0
    for row in records:
        arms = row["arms"]
        if left not in arms or right not in arms:
            continue
        differences = by_pair[row["pair_id"]]
        a, b = arms[left]["loss"], arms[right]["loss"]
        if a is None or b is None:
            pending += 1
        else:
            differences.append(a - b)
    differences = [mean(values) for _, values in sorted(by_pair.items()) if len(values) == len(MASK_COUNTS)]
    n = len(differences)
    report = {
        "scheduled_pairs": len(by_pair), "complete_pairs": n, "jointly_pending_scenarios": pending,
        "mean_paired_loss_difference": None, "cluster_percentile_interval": None,
        "conservative_sign_interval": None, "precision_interval": None,
        "precision_half_width_pp": None, "meets_operational_precision": False,
    }
    if not n:
        return report
    alpha = (1 - precision["confidence"]) / 2
    rng = Random(precision["bootstrap_seed"])
    sample_means = sorted(mean(rng.choices(differences, k=n)) for _ in range(precision["cluster_percentile_bootstrap_resamples"]))
    bootstrap = [_percentile(sample_means, p) for p in (alpha, 1 - alpha)]
    sign = [
        -_upper_binomial(sum(value < 0 for value in differences), n, alpha),
        _upper_binomial(sum(value > 0 for value in differences), n, alpha),
    ]
    degenerate = bootstrap[0] == bootstrap[1]
    interval = sign if degenerate else bootstrap
    half_width = (interval[1] - interval[0]) * 50
    return {
        **report, "mean_paired_loss_difference": mean(differences), "cluster_percentile_interval": bootstrap,
        "conservative_sign_interval": sign, "precision_interval": "conservative_sign" if degenerate else "cluster_percentile",
        "precision_half_width_pp": half_width,
        "meets_operational_precision": n >= MINIMUM_PAIRS and half_width <= precision["operational_target_half_width_pp"],
    }


def _resources(transports):
    # Pending checkpoints and interruptions have uncertain launch or telemetry, tracked explicitly.
    used = [row for row in transports if row.get("attempted_cli_turns") != 0]
    turns = [row.get("attempted_cli_turns") for row in used]
    tokens = [row.get("reported_input_plus_output_tokens") for row in used]
    elapsed = [row.get("cli_elapsed_seconds") for row in used]
    valid_tokens = [value for value in tokens if type(value) is int and value >= 0]
    valid_elapsed = [value for value in elapsed if type(value) in (int, float) and isfinite(value) and value >= 0]
    return {
        "known_turns": sum(turn == 1 for turn in turns), "turns_with_uncertain_launch": turns.count(None),
        "reported_tokens": sum(valid_tokens), "turns_without_token_telemetry": len(used) - len(valid_tokens),
        "reported_cli_seconds": sum(valid_elapsed), "turns_without_latency_telemetry": len(used) - len(valid_elapsed),
    }


def evaluate_final(cases, references, results, canonical, corpus, *, second_pass_order_by_case, precision,
                   checkpoints=None, authorize_test=False):
    """Score supplied data only. Case/reference I/O and test authorization belong to the caller."""
    planned = _index(cases, "Casos")
    partitions = {case.get("partition") for case in planned.values()}
    allowed = {"tuning", "calibration", "test"} if authorize_test is True else {"tuning", "calibration"}
    if len(partitions) != 1 or not partitions <= allowed:
        raise ValueError("La partición está mezclada, vacía o sin autorización")
    partition = next(iter(partitions))
    corpus_hash = _digest(b"".join(canonical_bytes(row) + b"\n" for row in corpus))
    if partition == "test" and corpus_hash != CORPUS_SHA256:
        raise ValueError("La evaluación final requiere el corpus B0 fijado")
    expected_precision = {
        "confidence": 0.95, "bootstrap_seed": 20261108, "cluster_percentile_bootstrap_resamples": 2000,
        "operational_target_half_width_pp": 10, "practically_relevant_error_reduction_pp": 5,
    }
    if any(precision.get(key) != value for key, value in expected_precision.items()):
        raise ValueError("Los parámetros del intervalo cambiaron desde el diseño fijado")
    pair_count = len({case["pair_id"] for case in planned.values()})
    if pair_count > MAXIMUM_PAIRS:
        raise ValueError("Se supera el máximo de pares del diseño fijado")
    # The pilot validator checks the payload schema and exact masks independently of partition.
    validate_public_cases([{**case, "partition": "tuning"} for case in planned.values()], pair_count)
    truth = _index(references, "Referencias")
    observed = _index(results, "Resultados")
    checkpoints = checkpoints if checkpoints is not None else {}
    if planned.keys() != truth.keys() or (observed.keys() | checkpoints.keys()) - planned.keys():
        raise ValueError("Casos, referencias y resultados no cubren un dominio compatible")
    orders = _orders(planned, second_pass_order_by_case)
    training = _validate_corpus(corpus)
    _verify_references(planned, truth, training)
    b0 = HierarchicalMedian(list(training.values()))
    records, physical = [], []
    attributed = {arm: [] for arm in ("A10", "A11", CONTROL, "B0")}
    for case_id, case in sorted(planned.items()):
        expected = truth[case_id]["expected_relation"]
        outcomes, rows = _hosted_outcomes(case, expected, canonical, orders[case_id],
                                          observed.get(case_id), checkpoints.get(case_id, {}))
        transports = {arm: row.get("transport", {}) for arm, row in rows.items()}
        physical.extend(transports.values())
        if "A10" in transports:
            attributed["A10"].append(transports["A10"])
        for arm in orders[case_id]:
            if arm in transports:
                attributed[arm].append(transports[arm])
            if arm in transports or outcomes[arm]["status"] == SKIPPED:
                attributed[arm].append(transports["A10"])
        baseline = _b0(b0, case)
        outcomes["B0"] = {**baseline, "loss": int(baseline["relation"] != expected)}
        records.append({
            "case_id": case_id, "pair_id": case["pair_id"], "mask": case["masked_stages_per_product"],
            "expected_relation": expected, "arms": outcomes,
        })
    by_arm = {arm: _metrics(records, arm) for arm in attributed}
    comparisons = (("A11", "A10"), ("A10", "B0"), ("A11", "B0"), ("A11", CONTROL), (CONTROL, "A10"))
    contrasts = {f"{left}_minus_{right}": _paired(records, left, right, precision) for left, right in comparisons}
    complete = all(row["pending_scenarios"] == 0 for row in by_arm.values())
    return {
        "status": "OFFLINE_EVALUATION_COMPLETE" if complete else "OFFLINE_EVALUATION_INCOMPLETE",
        "partition": partition, "final_test_opened": partition == "test", "pairs": pair_count,
        "scenarios": len(records), "primary_contrast": "A11_minus_A10", "interval_assumption": INTERVAL_ASSUMPTION,
        "exploratory": not complete or not contrasts["A11_minus_A10"]["meets_operational_precision"],
        "practically_relevant_error_reduction_pp": precision["practically_relevant_error_reduction_pp"],
        "b0_fit": {"training_partition": "corpus", "products": len(training), "llm_turns": 0,
                   "groups": len({row["group"] for row in training.values()}), "corpus_sha256": corpus_hash},
        "by_arm": by_arm, "by_arm_and_mask": {
            arm: {str(mask): _metrics([row for row in records if row["mask"] == mask], arm) for mask in MASK_COUNTS}
            for arm in attributed
        },
        "contrasts": contrasts, "physical_resources": _resources(physical),
        "attributed_resources": {arm: _resources(rows) for arm, rows in attributed.items()}, "cases": records,
    }


def replay_development(root):
    """Replay the existing 36 development cases without inference or test access."""
    run_id = "pilot_dev_001"
    plan, cases, canonical = load_public_plan(root, run_id)
    reference_raw = (root / "data/private" / run_id / "reference.jsonl").read_bytes()
    if _digest(reference_raw) != plan["reference_file_sha256"]:
        raise ValueError("La referencia de desarrollo cambió desde el piloto fijado")
    run = root / "outputs" / run_id / "results"
    results = [json.loads((run / f"{case['case_id']}.json").read_bytes()) for case in cases]
    design = json.loads((root / "configs/pretest_design_001.json").read_bytes())
    return evaluate_final(cases, _jsonl(reference_raw), results, canonical, load_b0_corpus(root),
                          second_pass_order_by_case=plan["second_pass_order_by_case"], precision=design["precision"])


def main():
    parser = argparse.ArgumentParser(description="Reproduce sin inferencia los resultados del piloto de desarrollo con B0.")
    parser.parse_args()
    report = replay_development(Path(__file__).resolve().parents[1])
    print(json.dumps({key: value for key, value in report.items() if key != "cases"}, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
