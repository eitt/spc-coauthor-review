"""Seal a reserved roster using only a projection of food metadata."""

import argparse
from collections import Counter, defaultdict
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path

from src.pilot_cases import canonical_bytes
from src.splits import _order, _text


ID = "pretest_final_roster_001"
PRIVATE = f"data/private/{ID}"
PUBLIC = f"outputs/{ID}"
METADATA = f"{PRIVATE}/metadata.json"
REVIEW = f"{PRIVATE}/review.json"
ROSTER = f"{PRIVATE}/pair_roster.json"
MANIFEST = f"{PUBLIC}/roster_manifest.json"
SIDECAR = f"{PUBLIC}/roster_manifest.sha256"
CONTEXT = ("family", "subgroup", "preparation")
FIELDS = ("id", "group", "name", "lci", *CONTEXT, "eligible")


def _digest(value) -> str:
    return sha256(canonical_bytes(value)).hexdigest()


def _local(root: Path, relative: str) -> Path:
    path = root / relative
    if path.resolve() != path or not path.is_relative_to(root):
        raise ValueError("Ruta de metadatos fuera de su destino fijado")
    return path


def _save(root: Path, relative: str, raw: bytes) -> None:
    from src.data_validation import _write_atomic

    path = _local(root, relative)
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError(f"El artefacto ya existe con otro contenido: {relative}")
        return
    _write_atomic(path, raw)


def _sealed_json(value) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")


def _prior_seal(root: Path) -> tuple[dict, str]:
    from src.final_holdout_seal import MANIFEST_NAME, SEAL_DIR, SIDECAR_NAME, _path, _sidecar

    raw = _path(root, f"{SEAL_DIR}/{MANIFEST_NAME}").read_bytes()
    if _path(root, f"{SEAL_DIR}/{SIDECAR_NAME}").read_bytes() != _sidecar(raw):
        raise ValueError("No coincide la huella del manifiesto de la partición")
    return json.loads(raw), sha256(raw).hexdigest()


def _frozen_grouping_products(summary: Path, stages: Path) -> tuple[dict, set[str]]:
    from src.data_validation import (
        IMPACT_FIELDS, PRODUCT_FIELDS, STAGE_FIELDS, _normal_label, _read_rows, parse_number,
    )

    common = {"Code AGB", *PRODUCT_FIELDS.values()}
    stage_columns = {f"{column} - {stage}" for column, _ in IMPACT_FIELDS.values() for stage in STAGE_FIELDS.values()}
    summary_rows, _ = _read_rows(summary, common | {"Préparation"})
    stage_rows, _ = _read_rows(stages, common | stage_columns)
    if not summary_rows or summary_rows.keys() != stage_rows.keys():
        raise ValueError("No se reproduce el cruce por código AGB de la partición sellada")
    products, excluded = {}, set()
    for key, row in sorted(summary_rows.items()):
        detail = stage_rows[key]
        different = {field for field, column in PRODUCT_FIELDS.items()
                     if _normal_label(row[column]) != _normal_label(detail[column])}
        if different - {"name", "lci"}:
            raise ValueError("Metadatos de los extractos incompatibles para agrupar")
        if different:
            excluded.add(key)
        products[key] = {
            "id": key, **{field: row[column].strip() for field, column in PRODUCT_FIELDS.items()},
            "preparation": row["Préparation"].strip(),
            # Frozen _stage_fingerprint uses only the keys of total, never its values.
            "total": dict.fromkeys(IMPACT_FIELDS),
            "stages": {stage: {
                impact: float(parse_number(detail[f"{column} - {label}"], "firma de agrupación"))
                for impact, (column, _) in IMPACT_FIELDS.items()
            } for stage, label in STAGE_FIELDS.items()},
        }
    return products, excluded


def _workbook_exclusions(path: Path, products: dict[str, dict]) -> set[str]:
    from openpyxl import load_workbook

    from src.agribalyse_reference import PACKAGING_DUPLICATES, _recipe_flags, _source_error_flags
    from src.data_validation import _identifier, _normal_label

    workbook = load_workbook(path, read_only=True, data_only=True, keep_links=False)
    try:
        _, recipe_flags = _recipe_flags(workbook["Detail ingredient"], products)
        metadata = workbook["Detail etape"]
        columns = next(metadata.iter_rows(min_row=4, max_row=4, max_col=6, values_only=True))
        if str(columns[0]).replace("\n", " ") != "Code AGB":
            raise ValueError("La hoja de etapas no empieza con el código AGB")
        seen = Counter()
        checked = set()
        excluded = {key for key, flags in recipe_flags.items() if flags}
        for code, ciqual, family, subgroup, name, lci in metadata.iter_rows(
            min_row=5, max_col=6, values_only=True,
        ):
            if not any((code, ciqual, family, subgroup, name, lci)):
                continue
            key = _identifier(str(code)) if code is not None else ""
            if key not in products or not isinstance(name, str) or not isinstance(lci, str):
                raise ValueError("Metadatos del libro sin correspondencia")
            seen[key] += 1
            corrected = "(emballage corrigé)" in name.casefold()
            if key in PACKAGING_DUPLICATES and not corrected:
                continue
            product = products[key]
            if key in checked or corrected != (key in PACKAGING_DUPLICATES) or (
                _identifier(str(ciqual)) != _identifier(product["ciqual"])
                or _normal_label(str(family)) != _normal_label(product["family"])
                or _normal_label(str(subgroup)) != _normal_label(product["subgroup"])
            ):
                raise ValueError("La fila de metadatos no coincide con el original fijado")
            checked.add(key)
            if _source_error_flags(" ".join((product["name"], product["lci"], name, lci))):
                excluded.add(key)
        if checked != set(products) or {key for key, count in seen.items() if count == 2} != PACKAGING_DUPLICATES:
            raise ValueError("El libro no reproduce la cobertura de los metadatos de referencia")
        return excluded
    finally:
        workbook.close()


def project_metadata(root: Path) -> dict:
    """Trusted boundary. Pass only the whitelisted projection to adjudication."""
    import yaml

    from src.data_io import load_manifest, verify_source
    from src.final_holdout_seal import DATA_MANIFEST, SPLIT_CONFIG, _file_hash, _path
    from src.splits import group_products, split_groups

    seal, prior_sha = _prior_seal(root)
    if any(_file_hash(root, name) != seal["pinned_file_sha256"][name] for name in (
        SPLIT_CONFIG, DATA_MANIFEST, "src/splits.py", "src/data_validation.py", "src/agribalyse_reference.py",
    )):
        raise ValueError("Cambiaron las reglas de agrupación o elegibilidad fijadas")
    config = yaml.safe_load(_path(root, SPLIT_CONFIG).read_bytes())
    source = load_manifest(root, DATA_MANIFEST)
    paths = {}
    for role, spec in {**source["sources"], "official_workbook": source["supplemental_audit_source"]}.items():
        relative = f"data/raw/{spec['file']}"
        if seal["official_source_sha256"][role] != {"path": relative, "sha256": spec["sha256"], "bytes": spec["bytes"]}:
            raise ValueError("La fuente de metadatos no coincide con el manifiesto sellado")
        paths[role] = _path(root, relative)
        verify_source(paths[role], spec)
    products, excluded = _frozen_grouping_products(paths["summary"], paths["stages"])
    groups = group_products(products.values())
    seed, proportions = config["project"]["seed"], config["splits"]["proportions"]
    assignments = split_groups(products.values(), seed, proportions)
    membership_sha = _digest([[key, groups[key], assignments[key]] for key in sorted(groups)])
    if membership_sha != seal["partition_commitment"]["all_partition_membership_sha256"]:
        raise ValueError("La proyección no coincide con la partición sellada")
    # The previously reconciled official workbook is pinned above. Use only its metadata exclusions.
    excluded.update(_workbook_exclusions(paths["official_workbook"], products))
    if len(products) != 2451 or len(excluded) != 360:
        raise ValueError("No se reproduce la cobertura de la auditoría de referencia fijada")
    rows = [
        {**{field: row[field] for field in ("id", "name", "lci", *CONTEXT)},
         "group": groups[row["id"]], "eligible": row["id"] not in excluded}
        for row in products.values() if assignments[row["id"]] == "test"
    ]
    return {"prior_manifest_sha256": prior_sha, "membership_sha256": membership_sha, "seed": seed, "rows": rows}


def _metadata(root: Path) -> tuple[dict, dict]:
    metadata = json.loads(_local(root, METADATA).read_bytes())
    if set(metadata) != {"prior_manifest_sha256", "membership_sha256", "seed", "rows"}:
        raise ValueError("La proyección solo admite metadatos y una bandera de elegibilidad")
    rows = metadata["rows"]
    by_id = {row["id"]: row for row in rows}
    if len(by_id) != len(rows) or any(
        set(row) != set(FIELDS) or type(row["eligible"]) is not bool
        or any(not isinstance(row[field], str) for field in FIELDS[:-1]) for row in rows
    ):
        raise ValueError("La proyección solo admite metadatos y una bandera de elegibilidad")
    return metadata, by_id


def _context(row: dict) -> tuple[str, ...]:
    return tuple(_text(row[field]) for field in CONTEXT)


def _capacity(edges: list[tuple[str, str]]) -> int:
    """Solve general-graph matching as binary edge selection with degree at most one."""
    if not edges:
        return 0

    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import coo_array

    vertices = {group: i for i, group in enumerate(sorted({group for edge in edges for group in edge}))}
    matrix = coo_array(
        (np.ones(2 * len(edges)), ([vertices[group] for edge in edges for group in edge],
                                  np.repeat(np.arange(len(edges)), 2))),
        shape=(len(vertices), len(edges)),
    ).tocsc()
    result = milp(
        -np.ones(len(edges)), integrality=np.ones(len(edges)), bounds=Bounds(0, 1),
        constraints=LinearConstraint(matrix, 0, 1), options={"mip_rel_gap": 0.0},
    )
    if not result.success or result.mip_gap != 0:
        raise ValueError("No se demostró el emparejamiento máximo de grupos")
    chosen = [edge for edge, decision in zip(edges, result.x, strict=True) if decision > 0.5]
    if len({group for edge in chosen for group in edge}) != 2 * len(chosen) or -result.fun != len(chosen):
        raise ValueError("El emparejamiento óptimo reutiliza grupos o no es entero")
    return len(chosen)


def _screen(rows: list[dict], key) -> dict:
    buckets = defaultdict(set)
    for row in rows:
        stratum = key(row)
        if stratum and all(stratum):
            buckets[stratum].add(row["group"])
    edges = sorted({edge for groups in buckets.values() for edge in combinations(sorted(groups), 2)})
    return {"group_edges": len(edges), "maximum_group_disjoint_pairs": _capacity(edges)}


def _pair(seed: int, domain: str, rows: tuple[dict, dict], review_class: str, strict: bool) -> dict:
    a, b = sorted(rows, key=lambda row: _order(seed, domain, row["id"]))
    return {
        "pair_id": "P-" + _digest([seed, a["id"], b["id"]])[:16],
        "product_ids": [a["id"], b["id"]],
        "group_ids": [a["group"], b["group"]],
        "review_class": review_class,
        "matches_lexical_screen": strict,
    }


def _adjudicate(metadata: dict, by_id: dict, review: dict, design: dict) -> tuple[dict, dict]:
    from src.development_capacity import _form_key

    if review["metadata_sha256"] != _digest(metadata) or review["status"] != "BLIND_METADATA_ADJUDICATION":
        raise ValueError("La revisión no corresponde a la proyección sellada")
    if not (design["seed"] == metadata["seed"] and design["final_pairs_target_and_maximum"] == 80):
        raise ValueError("El diseño del listado reservado cambió")
    seed, domain = metadata["seed"], design["pair_order_hash_domain"]
    candidates = []
    reviewed_classes = set()
    reviewed_products = set()
    seen_product_edges = set()
    for review_class in review["classes"]:
        tag, ids, reason = (review_class[field] for field in ("class", "product_ids", "reason"))
        rows = [by_id[key] for key in ids]
        if (
            tag in reviewed_classes or not reason.strip() or len(ids) != len(set(ids))
            or len({row["group"] for row in rows}) < 2 or not all(row["eligible"] for row in rows)
            or len({_context(row) for row in rows}) != 1 or not all(_context(rows[0]))
        ):
            raise ValueError("Clase de comparabilidad vacía, duplicada o con contexto incompatible")
        reviewed_classes.add(tag)
        reviewed_products.update(ids)
        for a, b in combinations(rows, 2):
            if a["group"] == b["group"]:
                continue
            product_edge = tuple(sorted((a["id"], b["id"])))
            if product_edge in seen_product_edges:
                raise ValueError("Una comparación aparece en más de una clase")
            seen_product_edges.add(product_edge)
            strict = _form_key(a) is not None and _form_key(a) == _form_key(b)
            candidates.append(_pair(seed, "pretest-final-orientation", (a, b), tag, strict))

    if len({row["pair_id"] for row in candidates}) != len(candidates):
        raise ValueError("Identificadores de pares no únicos")
    candidates.sort(key=lambda row: _order(seed, domain, row["pair_id"]))
    # A single representative product edge per group edge suffices for cardinality.
    representatives = {}
    lexical = set()
    for row in candidates:
        edge = tuple(sorted(row["group_ids"]))
        representatives.setdefault(edge, row)
        if row["matches_lexical_screen"]:
            lexical.add(edge)

    maximum = _capacity(list(representatives))
    target = min(maximum, design["final_pairs_target_and_maximum"])
    selected = _ordered_matching(representatives, target)
    neutral = sorted(
        selected, key=lambda row: _order(seed, design["neutral_control_order_hash_domain"], row["pair_id"]),
    )[:24]
    eligible = [row for row in by_id.values() if row["eligible"]]
    roster = {
        "status": "SEALED_METADATA_ONLY", "partition": "test", "seed": seed,
        "metadata_sha256": _digest(metadata), "review_sha256": _digest(review),
        "pairs": selected, "neutral_control_pair_ids": [row["pair_id"] for row in neutral],
    }
    counts = {
        "reserved_products": len(by_id), "reserved_groups": len({row["group"] for row in by_id.values()}),
        "source_eligible_products": len(eligible), "source_eligible_groups": len({row["group"] for row in eligible}),
        "strict_lexical_screen": _screen(eligible, _form_key),
        "context_only_upper_bound": _screen(eligible, _context),
        "review_classes": len(reviewed_classes), "review_products": len(reviewed_products),
        "review_product_edges": len(candidates), "review_group_edges": len(representatives),
        "maximum_reviewed_strict_group_disjoint_pairs": _capacity(sorted(lexical)),
        "maximum_reviewed_group_disjoint_pairs": maximum,
        "sealed_group_disjoint_pairs": target, "sealed_distinct_groups": 2 * target,
        "sealed_pairs_matching_lexical_screen": sum(row["matches_lexical_screen"] for row in selected),
        "sealed_pairs_with_documented_form_and_use": sum(not row["matches_lexical_screen"] for row in selected),
        "sealed_neutral_control_pairs": len(neutral),
    }
    return roster, counts


def _ordered_matching(representatives: dict, target: int) -> list[dict]:
    """Choose the earliest feasible edges without sacrificing cardinality."""
    selected = []
    used = set()
    remaining_edges = list(representatives)
    for i, edge in enumerate(remaining_edges):
        if len(selected) == target:
            break
        if used.intersection(edge):
            continue
        blocked = used.union(edge)
        remaining = [other for other in remaining_edges[i + 1:] if not blocked.intersection(other)]
        needed = target - len(selected) - 1
        if needed and _capacity(remaining) < needed:
            continue
        selected.append(representatives[edge])
        used.update(edge)
    if len(selected) != target or len(used) != 2 * target:
        raise ValueError("El orden fijado no recuperó la cardinalidad esperada")
    return selected


def _artifacts(root: Path) -> dict[str, bytes]:
    metadata, by_id = _metadata(root)
    review = json.loads(_local(root, REVIEW).read_bytes())
    design_raw = _local(root, "configs/pretest_design_001.json").read_bytes()
    design = json.loads(design_raw)
    if design["final_test_opened"] is not False or design["final_test_run_authorized"] is not False:
        raise ValueError("Se requiere un diseño sin autorización de apertura")
    prior, prior_sha = _prior_seal(root)
    if (
        metadata["prior_manifest_sha256"] != prior_sha
        or metadata["membership_sha256"] != prior["partition_commitment"]["all_partition_membership_sha256"]
        or sha256(design_raw).hexdigest() != prior["pinned_file_sha256"]["configs/pretest_design_001.json"]
    ):
        raise ValueError("El diseño o la partición dejó de coincidir con el sello anterior")
    roster, counts = _adjudicate(metadata, by_id, review, design["design"])
    prior_counts = prior["partition_commitment"]["aggregate_counts"]
    if (counts["reserved_products"], counts["reserved_groups"]) != (
        prior_counts["products_by_partition"]["test"], prior_counts["groups_by_partition"]["test"],
    ):
        raise ValueError("Cambió la cobertura de la proyección fijada")
    roster_raw = _sealed_json(roster)
    manifest = {
        "id": ID, "status": "SEALED_METADATA_ONLY", "partition": "test",
        "final_test_opened": False, "final_test_run_authorized": False,
        "final_test_case_files_read_or_written": 0, "final_test_labels_read_or_generated": 0,
        "inference_attempts": 0, "additional_spend_usd": 0, "reserved_identities_exported": False,
        "prior_manifest_sha256": metadata["prior_manifest_sha256"],
        "partition_membership_sha256": metadata["membership_sha256"],
        "metadata_sha256": _digest(metadata), "adjudication_sha256": _digest(review),
        "pair_roster_sha256": sha256(roster_raw).hexdigest(),
        "selector_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "aggregate_counts": counts,
        "operational_precision_planning_threshold": design["design"]["final_pairs_minimum_for_operational_precision_scenario"],
        "operational_precision_planning_threshold_met": (
            counts["sealed_group_disjoint_pairs"] >= design["design"]["final_pairs_minimum_for_operational_precision_scenario"]
        ),
        "scope": "Máximo exacto sobre las clases aceptadas de forma y uso dentro de contexto; el techo de contexto no valida comparabilidad.",
        "projection_policy": "El proceso de agrupación usa etapas de la fuente pública solo como huellas exactas. No interpreta totales publicados. El libro se consulta por código, nombres, categorías e ingredientes para reproducir exclusiones. La revisión solo recibe metadatos y la elegibilidad.",
        "hash_encoding": "canonical JSON for metadata and review, exact UTF-8 file bytes for roster and public manifest",
    }
    manifest_raw = _sealed_json(manifest)
    sidecar = f"{sha256(manifest_raw).hexdigest()}  {Path(MANIFEST).name}\n".encode("ascii")
    return {ROSTER: roster_raw, MANIFEST: manifest_raw, SIDECAR: sidecar}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("project", "seal", "check"))
    args = parser.parse_args()
    root = Path.cwd().resolve()
    if args.command == "project":
        metadata = project_metadata(root)
        _save(root, METADATA, _sealed_json(metadata))
        print(json.dumps({"metadata_sha256": _digest(metadata), "products": len(metadata["rows"])}))
        return

    artifacts = _artifacts(root)
    for relative, raw in artifacts.items():
        if args.command == "seal":
            _save(root, relative, raw)
        elif _local(root, relative).read_bytes() != raw:
            raise ValueError(f"No coincide el sello de {relative}")
    print(artifacts[MANIFEST].decode("utf-8"), end="")


if __name__ == "__main__":
    main()
