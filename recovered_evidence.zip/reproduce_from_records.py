"""Reproduce métricas, recursos y bootstrap desde registros retenidos. Sin red/modelos.
Ejecutar en el directorio de este archivo: python -B reproduce_from_records.py
"""
from pathlib import Path
from collections import defaultdict,Counter
from decimal import Decimal
from fractions import Fraction
from statistics import median,mean
from random import Random
from math import fsum,comb
import csv,json,hashlib,sys
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def jsonl(p):return [json.loads(l) for l in p.read_text(encoding='utf-8-sig').splitlines() if l.strip()]
def compare(a,b,t):
    d={k:Fraction(str(a[k]))-Fraction(str(b[k])) for k in t};aa=any(d[k]<-Fraction(str(t[k])) for k in t);bb=any(d[k]>Fraction(str(t[k])) for k in t)
    return 'TRADEOFF' if aa and bb else 'A_DOMINATES' if aa else 'B_DOMINATES' if bb else 'EQUIVALENT_WITHIN_TOLERANCE'
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def upper(k,n,alpha):
    if k==n:return 1.
    lo,hi=0.,1.
    for _ in range(53):
        p=(lo+hi)/2;cdf=sum(comb(n,i)*p**i*(1-p)**(n-i) for i in range(k+1))
        if cdf>alpha:lo=p
        else:hi=p
    return hi
def percentile(v,p):
    offset=p*(len(v)-1);i=int(offset)
    return v[i] if offset==i else v[i]+(offset-i)*(v[i+1]-v[i])
def main():
    files=ROOT/'SHA256SUMS.txt'
    if files.exists():
        for line in files.read_text(encoding='ascii').splitlines():
            h,name=line.split('  ',1);p=ROOT/name
            if hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise ValueError('Integrity mismatch: '+name)
    records=ROOT/'run_records';cases=jsonl(records/'cases.jsonl');refs={r['case_id']:r for r in jsonl(records/'reference.jsonl')};corpus=jsonl(records/'corpus.jsonl');q=read(records/'queue_manifest.json');aggregate=read(ROOT/'repository/results.json')
    cells=defaultdict(list)
    for p in corpus:
        for stage,v in p['stages'].items():
            for level in [(p['family'],p['subgroup']),(p['family'],),()]:
                for k,x in v.items():cells[level,stage,k].append(x)
    med={k:median(v) for k,v in cells.items()};loss={};turns={};attributes=defaultdict(list);valid=Counter();statuses=Counter()
    for c in cases:
        cid=c['case_id'];ref=refs[cid];r=read(records/f'results/{cid}.json');t=c['tolerance'];truth=ref['expected_relation']
        assert hashlib.sha256(canonical(c)).hexdigest()==ref['payload_sha256']==r['payload_sha256']
        assert compare(ref['official_stage_tab_totals']['A'],ref['official_stage_tab_totals']['B'],t)==truth
        for role in ['A10',*q['second_pass_order_by_case'][cid]]:
            row=r['arms'][role];meta=row['transport'];physical=meta['attempted_cli_turns'];statuses[row['status']]+=1
            if physical==1:
                attempt=read(records/f'attempts/{cid}.{role}.json');assert attempt==row;key=cid+'.'+role;turns[key]=meta
                for w in (['A10','A11']+(['CONTROL_2PASS'] if 'CONTROL_2PASS' in r['arms'] else []) if role=='A10' else [role]):attributes[w].append(key)
            else:assert row['status']=='SKIPPED_SHARED_FIRST_PASS' and physical==0
            good=row['status']=='VALID'
            if good:
                a=json.loads(row['raw_response']);assert a['case_id']==cid and a['predicted_relation']==row['relation'];assert compare({k:v['value'] for k,v in a['candidate_impacts']['A'].items()},{k:v['value'] for k,v in a['candidate_impacts']['B'].items()},t)==a['predicted_relation'];valid[role]+=1
            loss[cid,role]=(c['pair_id'],int(not good or row.get('relation')!=truth),c['masked_stages_per_product'])
        totals={}
        for s in ['A','B']:
            ctx=c['context'];levels=[(ctx['family'],ctx['subgroup']),(ctx['family'],),()]
            totals[s]={k:fsum(c['observed_stages'][s][stage]['impacts'][k] if stage in c['observed_stages'][s] else next(med[level,stage,k] for level in levels if (level,stage,k) in med) for stage in corpus[0]['stages']) for k in t}
        loss[cid,'B0']=(c['pair_id'],int(compare(totals['A'],totals['B'],t)!=truth),c['masked_stages_per_product']);valid['B0']+=1
    metrics=[]
    for arm in ['A10','A11','B0','CONTROL_2PASS']:
        rr=[v for (cid,w),v in loss.items() if w==arm];errors=sum(v[1] for v in rr)
        assert len(rr)==aggregate['by_arm'][arm]['scheduled_scenarios'] and errors==aggregate['by_arm'][arm]['errors_including_failures'] and valid[arm]==aggregate['by_arm'][arm]['valid_scenarios']
        metrics.append(dict(workflow=arm,scheduled=len(rr),valid=valid[arm],errors=errors))
    contrasts=[];drawrows=[]
    for a,b in [('A11','A10'),('A10','B0'),('A11','B0'),('A11','CONTROL_2PASS'),('CONTROL_2PASS','A10')]:
        by=defaultdict(list);name=a+'_minus_'+b
        for (cid,w),(p,l,m) in loss.items():
            if w==a and (cid,b) in loss:by[p].append(l-loss[cid,b][1])
        assert all(len(v)==3 for v in by.values());v=[mean(x) for p,x in sorted(by.items())];n=len(v);rng=Random(20261108);draws=[mean(rng.choices(v,k=n)) for _ in range(2000)];ss=sorted(draws);alpha=(1-.95)/2
        ci=[percentile(ss,p) for p in [alpha,1-alpha]];sign=[-upper(sum(x<0 for x in v),n,alpha),upper(sum(x>0 for x in v),n,alpha)];old=aggregate['contrasts'][name]
        assert max(abs(x-y) for x,y in zip(ci,old['cluster_percentile_interval']))<1e-12
        assert max(abs(x-y) for x,y in zip(sign,old['conservative_sign_interval']))<1e-12
        contrasts.append(dict(contrast=name,pairs=n,mean_difference=mean(v),bootstrap=ci,conservative=sign));drawrows.extend(dict(contrast=name,draw_index=i,mean_difference=x) for i,x in enumerate(draws))
    reported=sum(v['reported_input_plus_output_tokens'] for v in turns.values() if v.get('reported_input_plus_output_tokens') is not None);unknown=sum(v.get('reported_input_plus_output_tokens') is None for v in turns.values());attributed={w:sum(turns[k]['reported_input_plus_output_tokens'] for k in ids if turns[k].get('reported_input_plus_output_tokens') is not None) for w,ids in attributes.items()}
    assert len(turns)==274 and reported==3950019 and unknown==5 and sum(valid[w] for w in ['A10','A11','CONTROL_2PASS'])==269
    output=ROOT/'replay_outputs';output.mkdir(exist_ok=True)
    summary=dict(pairs=len({c['pair_id'] for c in cases}),cases=len(cases),physical_turns=len(turns),valid_final_responses=269,status_counts=dict(statuses),physical_reported_tokens=reported,unknown_token_turns=unknown,provisional_tokens=unknown*32768,ledger=reported+unknown*32768,attributed_tokens=attributed,A11_to_A10_ratio=attributed['A11']/attributed['A10'],metrics=metrics,contrasts=contrasts,new_experimental_calls=0,raw_provider_streams_recovered=0,python=sys.version)
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    with (output/'bootstrap_draws.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['contrast','draw_index','mean_difference']);w.writeheader();w.writerows(drawrows)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
