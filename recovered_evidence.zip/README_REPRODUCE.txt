EVIDENCIA RECUPERADA PARA REVISION

Este subconjunto conserva 102 entradas, sus referencias, el corpus de la línea base, 274 intentos físicos y los resultados de 276 asignaciones (incluidos cinco timeouts y dos saltos). Las 269 respuestas finales válidas están dentro de los intentos y resultados originales. normalized/ enlaza caso, rol, turno y fuente; las tablas de la línea base son reconstrucciones deterministas identificadas.

Extraiga este ZIP y ejecute: python reproduce_from_records.py
Requiere Python 3.12 o 3.13 y solo biblioteca estándar. No llama modelos ni usa red. Verifica SHA256SUMS.txt antes de reconstruir resultados. Se conservan todas las filas fallidas.

repository/ conserva los bytes del commit histórico 1898202a81db59ecc2bc8aae442d84cb0bce0c4c. Las referencias AGRIBALYSE 3.2 figuran en source_data_manifest.json, con URL y hash históricos. No se sustituyeron versiones.

Los registros son evidencia retenida, no certificación del proveedor. No se recuperaron streams originales del proveedor ni identificadores de llamada. No hay nuevas llamadas experimentales.

Las historias personales de Codex, credenciales, archivos de oficina con comentarios históricos, rutas del equipo, fuentes ambientales completas y dependencias se excluyen de este subconjunto público. La auditoría completa permanece local. La revisión científica humana sigue pendiente.
