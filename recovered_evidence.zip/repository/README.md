# Comparar alimentos con datos ambientales incompletos

Si faltan datos sobre cómo se produjo o transportó un alimento, puede ser difícil saber si tiene menos impacto ambiental que otro. Estudiamos si pedirle a un modelo de IA que revise su primera respuesta ayuda a comparar dos alimentos cuando la información disponible sigue siendo la misma.

Este repositorio reúne las cifras agregadas del estudio, las instrucciones que recibieron los agentes y el código para verificar las cifras y regenerar las tablas y gráficas sin conexión. [Resultados del estudio](resultados-estudio.md) · [Comando de reproducción](#reproducir-tablas-y-gráficas)

## Qué hicimos

Un **análisis de ciclo de vida (ACV)** estima impactos ambientales a lo largo de las etapas por las que pasa un producto. En este estudio usamos los valores ya publicados por **AGRIBALYSE 3.2**, una base de datos francesa que describe esos impactos por kilogramo de alimento tal como se consume en Francia. Comparamos tres aspectos: el impacto sobre el clima, la privación de agua y el enriquecimiento de aguas dulces con nutrientes, llamado eutrofización. [Qué mide cada indicador y de dónde salen los datos](datos-y-escenarios.md#la-base-de-datos-y-el-acv)

Elegimos **34 pares de alimentos comparables**. Para cada par creamos tres escenarios: uno con todas las etapas visibles, otro con dos etapas ocultas por alimento y otro con cuatro. Así obtuvimos **102 escenarios con los mismos 34 pares**. Usamos los totales completos de AGRIBALYSE para comprobar las respuestas. [Diagramas y ejemplo de los escenarios](datos-y-escenarios.md#de-34-pares-a-102-escenarios) · [Tabla con los recuentos reales](datos-y-escenarios.md#recuentos-por-nivel-de-datos-ocultos)

## Flujo de los agentes

En este estudio, cada **agente** era un paso del programa que daba una tarea al mismo modelo. La primera pasada (**A10**) estimaba los impactos totales y clasificaba el par. La revisión (**A11**) recibía los mismos datos y la respuesta de A10 para comprobar sus estimaciones y su clasificación. En 24 pares, el **control neutro** hacía otra estimación con esos mismos insumos y una instrucción general. También comparamos **B0**, un método que rellenaba los valores que faltaban con medianas y aplicaba una regla fija.

El programa en Python organizaba los turnos mediante CrewAI y llamaba a Codex CLI. Codex utilizaba la sesión de ChatGPT con la que ya se había iniciado sesión, sin clave de API. El evaluador comparaba las respuestas con la referencia de AGRIBALYSE. [Diagrama de los agentes y explicación del código](agentes-y-codigo.md#flujo-de-los-agentes)

## Qué encontramos

[Ver los resultados auditados con gráficas y tablas](resultados-estudio.md) · [Reproducir los resultados](#reproducir-tablas-y-gráficas)

A10 y A11 dieron la misma clasificación en los **99 escenarios con dos respuestas válidas**. En 29 de ellos, ambos discreparon de la referencia. Al incluir los fallos, A10 registró 30 errores de 102 y A11, 32. La diferencia se debió a dos revisiones que agotaron su tiempo de espera.

Al contar la primera pasada dentro de cada flujo, A11 registró **2,04 veces los tokens reportados de A10**. Los tokens son las unidades de texto que el servicio cuenta al procesar la entrada y generar la respuesta. La comparación fue exploratoria. El intervalo conservador para la diferencia de error abarca desde 10,28 puntos porcentuales menos hasta 19,68 más para A11. [Resultados por nivel de datos ocultos](datos-y-escenarios.md#recuentos-por-nivel-de-datos-ocultos)

## Prueba con un ejemplo

Puedes consultar en GitHub las tablas y gráficas de dos ejercicios ficticios.

- [Dos purés con datos incompletos](ejemplo-completo.md#resultados-del-ejercicio-ficticio). A10 y A11 conservan el mismo error.
- [Dos croquetas con una suma corregida](ejemplo-suma.md#cómo-cambia-la-puntuación). A11 repite la suma de A10 y cambia la clasificación.

Con Python 3.12, ejecuta este comando desde la carpeta principal del repositorio para ver el caso completo con dos purés ficticios.

```text
python -X utf8 -B ejemplo.py
```

Para ver el segundo caso, añade `--caso suma` al comando.

```text
python -X utf8 -B ejemplo.py --caso suma
```

La terminal muestra en tablas los datos que recibe A10, su respuesta simulada, las comprobaciones de A11 y la puntuación de ambas respuestas. Las gráficas de barras comparan los valores estimados con los de referencia para cada indicador. El programa lee el JSON del caso y funciona sin instalar paquetes adicionales, iniciar sesión, conectarse a internet ni llamar al modelo. [Caso de los purés](ejemplo-completo.md) · [Caso de las croquetas](ejemplo-suma.md) · [Código del ejemplo](ejemplo.py)

## Reproducir tablas y gráficas

Con **Python 3.12**, ejecuta este comando desde la carpeta principal del repositorio.

```text
python -B reproducir.py
```

El programa comprueba la huella de `results.json` con el manifiesto del repositorio, concilia sus recuentos y regenera los tres archivos de `resultados-reproducidos/`. Funciona con la biblioteca estándar de Python, sin instalar paquetes, conectarse a internet, llamar al modelo ni leer archivos privados.

- [Tablas del estudio](resultados-reproducidos/tablas-estudio.md)
- [Gráfica de errores y tokens](resultados-reproducidos/resultados-comparacion.svg)
- [Gráfica de errores y dominancia por etapas ocultas](resultados-reproducidos/resultados-mascaras.svg)

El repositorio incluye una copia de las tres salidas. Cada ejecución las regenera en esa misma carpeta. [Datos de entrada](results.json) · [Código del comando](reproducir.py) · [Código de las gráficas](graficas.py)

## Auditoría de los resultados guardados

Con **Python 3.12**, ejecuta este comando desde la carpeta del repositorio. Usa únicamente la biblioteca estándar de Python.

```text
python -B verify.py
```

En la salida verás `30/102` para A10, `32/102` para A11 y una diferencia de `+1.96` puntos porcentuales. El verificador comprueba las huellas de los archivos, concilia los recuentos y vuelve a calcular las cinco diferencias entre métodos y sus intervalos conservadores. También reconstruye el intervalo principal obtenido por remuestreo (bootstrap) y las probabilidades resumidas para las compensaciones clasificadas como dominancia. Para reconstruir los cuatro intervalos bootstrap secundarios con la semilla original haría falta el orden de los pares. El JSON conserva sus valores auditados. [Diagnóstico de dominancia](resultados-reproducidos/tablas-estudio.md#compensaciones-clasificadas-como-dominancia)

Los datos de este repositorio son agregados. Cotejar una respuesta individual con su referencia requiere los registros que el equipo conserva por separado. [Cómo leer una cifra del JSON](datos-y-escenarios.md#cómo-leer-los-datos-del-repositorio)

## Archivos del repositorio

| Archivo | Para qué sirve |
| --- | --- |
| [Datos y escenarios](datos-y-escenarios.md) | Entender el ACV, ver qué datos se ocultaron y leer los recuentos de la prueba. |
| [Agentes y código](agentes-y-codigo.md) | Seguir la conexión con ChatGPT y el camino de una respuesta hasta el evaluador. |
| [Ejemplo paso a paso](ejemplo-completo.md) · [Resultados](ejemplo-completo.md#resultados-del-ejercicio-ficticio) · [JSON](ejemplo-completo.json) | Ver la entrada de A10, las respuestas simuladas, la puntuación y las gráficas. |
| [Ejercicio con una suma corregida](ejemplo-suma.md) · [Resultados](ejemplo-suma.md#cómo-cambia-la-puntuación) · [JSON](ejemplo-suma.json) | Seguir la corrección de A11 y ver cómo cambia la puntuación. |
| [Ejemplos en Python](ejemplo.py) | Ver en la terminal las tablas, gráficas y puntuaciones de los dos casos ficticios. |
| [Resultados auditados del estudio](resultados-estudio.md) | Comparar los errores, las etiquetas y los tokens, y ver cómo variaron los resultados según las etapas ocultas. |
| [Reproducción de tablas y gráficas](#reproducir-tablas-y-gráficas) | Regenerar y verificar las salidas a partir de los agregados. |
| [Resultados agregados](results.json) | Consultar el diseño, los recuentos, los intervalos y las referencias de origen. |
| [Instrucciones del modelo](prompts.json) | Leer las tres plantillas de instrucciones usadas para A10, A11 y el control. |
| [Formato de respuesta](agent_output.schema.json) | Ver qué campos tenía que devolver el modelo y cómo se comprobaba su estructura. |
| [Verificador](verify.py) | Comprobar los archivos y recalcular resultados a partir de agregados. |
| [Huellas de integridad](SHA256SUMS.txt) · [Formato de archivos en Git](.gitattributes) | Identificar los bytes publicados y conservar los saltos de línea en distintos sistemas. |
