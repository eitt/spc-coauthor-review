"""Recorre casos ficticios guardados en JSON, sin llamar al modelo."""

import argparse
from decimal import Decimal
import json
from pathlib import Path
from textwrap import fill


IMPACTOS = {
    "climate_change": ("Clima", "kg CO₂ eq", 3),
    "water_use": ("Agua", "m³ de privación", 3),
    "freshwater_eutrophication": ("Eutrofización", "kg P eq", 6),
}
ETAPAS = {
    "agriculture": "Agricultura",
    "processing": "Transformación",
    "packaging": "Envasado",
    "transport": "Transporte",
    "distribution": "Distribución",
    "consumption": "Consumo",
}
RELACIONES = ("A_DOMINATES", "B_DOMINATES", "TRADEOFF", "EQUIVALENT_WITHIN_TOLERANCE")
LADOS = ("A", "B")
CAMPOS_RESPUESTA = {"case_id", "candidate_impacts", "predicted_relation", "relation_probabilities",
                    "evidence", "brief_justification"}
CAMPOS_IMPACTO = {"value", "unit", "estimated", "evidence_ids"}
CAMPOS_EVIDENCIA = {"evidence_id", "source_id", "supported_field"}
CASOS = {
    "faltantes": ("ejemplo-completo.json", "Dos purés de legumbres"),
    "suma": ("ejemplo-suma.json", "Dos croquetas de legumbres"),
}


def cifra(valor, impacto):
    decimales = IMPACTOS[impacto][2]
    return f"{valor:.{decimales}f}".replace(".", ",")


def tabla(columnas, filas):
    filas = [columnas, *filas]
    anchos = [max(map(len, valores)) for valores in zip(*filas, strict=True)]
    for indice, fila in enumerate(filas):
        print(" | ".join(valor.ljust(ancho) for valor, ancho in zip(fila, anchos, strict=True)).rstrip())
        if indice == 0:
            print("-+-".join("-" * ancho for ancho in anchos))


def fila_impactos(titulo, valores):
    return (titulo, *(cifra(valores[k], k) for k in IMPACTOS))


def sumar(etapas):
    return {k: sum(etapa[k] for etapa in etapas) for k in IMPACTOS}


def ventajas(totales, tolerancia):
    # Decimal mantiene exacta la comparación cuando la diferencia alcanza el margen.
    resultado = {}
    for k in IMPACTOS:
        diferencia = totales["A"][k] - totales["B"][k]
        margen = tolerancia[k]
        if diferencia < -margen:
            resultado[k] = "A"
        elif diferencia > margen:
            resultado[k] = "B"
        else:
            resultado[k] = "Empate"
    return resultado


def clasificar(totales, tolerancia):
    mejores = set(ventajas(totales, tolerancia).values()) - {"Empate"}
    if mejores == {"A"}:
        return "A_DOMINATES"
    if mejores == {"B"}:
        return "B_DOMINATES"
    if mejores:
        return "TRADEOFF"
    return "EQUIVALENT_WITHIN_TOLERANCE"


def totales_de(respuesta):
    return {lado: {k: respuesta["candidate_impacts"][lado][k]["value"] for k in IMPACTOS} for lado in LADOS}


def es_numero(valor):
    return type(valor) is int or isinstance(valor, Decimal) and valor.is_finite()


def comprobar_respuesta(respuesta, caso, corpus):
    """Reproduce los controles del ejemplo sobre el JSON y el caso público."""
    impactos = respuesta["candidate_impacts"]
    probabilidades = respuesta["relation_probabilities"]
    pruebas = {
        "Identificador y tres valores numéricos por alimento": (
            respuesta["case_id"] == caso["case_id"]
            and set(impactos) == set(LADOS)
            and all(
                set(impactos[lado]) == set(IMPACTOS)
                and all(es_numero(fila["value"]) for fila in impactos[lado].values())
                for lado in LADOS
            )
        ),
        "Campos de la respuesta": (
            set(respuesta) == CAMPOS_RESPUESTA
            and all(set(fila) == CAMPOS_IMPACTO for lado in impactos.values() for fila in lado.values())
            and isinstance(respuesta["evidence"], list)
            and all(set(fila) == CAMPOS_EVIDENCIA for fila in respuesta["evidence"])
        ),
        "Unidades y marca de estimación": True,
        "Citas permitidas y vinculadas a sus totales": True,
    }
    esperadas = set()
    for lado in LADOS:
        observadas = {fila["evidence_id"] for fila in caso["observed_stages"][lado].values()}
        for k, fila in impactos[lado].items():
            pruebas["Unidades y marca de estimación"] &= (
                fila["unit"] == caso["units"][k] and fila["estimated"] is bool(caso["hidden_stages"][lado])
            )
            ids = set(fila["evidence_ids"])
            pruebas["Citas permitidas y vinculadas a sus totales"] &= (
                1 <= len(ids) == len(fila["evidence_ids"]) <= 2 and ids <= (observadas | corpus.keys())
            )
            esperadas.update(
                (eid, "corpus" if eid in corpus else "observed", f"candidate_impacts.{lado}.{k}")
                for eid in ids
            )
    citas = {(fila["evidence_id"], fila["source_id"], fila["supported_field"]) for fila in respuesta["evidence"]}
    pruebas["Citas permitidas y vinculadas a sus totales"] &= (
        citas == esperadas and len(citas) == len(respuesta["evidence"])
    )
    etiqueta = respuesta["predicted_relation"]
    pruebas["Probabilidades y etiqueta más probable"] = (
        set(probabilidades) == set(RELACIONES)
        and all(es_numero(p) and 0 <= p <= 1 for p in probabilidades.values())
        and abs(sum(probabilidades.values()) - 1) <= Decimal("1e-9")
        and probabilidades.get(etiqueta) == max(probabilidades.values())
    )
    pruebas["Etiqueta coherente con los totales estimados"] = (
        pruebas["Identificador y tres valores numéricos por alimento"]
        and etiqueta == clasificar(totales_de(respuesta), caso["tolerance"])
    )
    pruebas["Justificación breve"] = 0 < len(respuesta["brief_justification"].strip()) <= 1600
    return pruebas


def reconstruir_total(fila, visible, ocultas, corpus, impacto):
    # En este ejercicio cada estimación toma las etapas ocultas de un solo ejemplo citado.
    referencias = [eid for eid in fila["evidence_ids"] if eid in corpus]
    if len(referencias) != 1:
        return None
    ejemplo = corpus[referencias[0]]["stages"]
    return visible + sum(ejemplo[etapa][impacto] for etapa in ocultas)


def graficar(totales_por_fuente):
    print("\nGráficas de barras por indicador. Cada gráfica usa una escala propia desde cero.")
    for k, (nombre, unidad, _) in IMPACTOS.items():
        print(f"\n{nombre} ({unidad} por kg de alimento)")
        series = [
            (f"{lado} · {fuente}", totales[lado][k])
            for lado in LADOS
            for fuente, totales in totales_por_fuente.items()
        ]
        maximo = max(valor for _, valor in series)
        for etiqueta, valor in series:
            longitud = round(30 * valor / maximo) if maximo else 0
            print(f"  {etiqueta:<15} | {'#' * longitud:<30} {cifra(valor, k)}")


def recorrer(datos, titulo="Dos purés de legumbres"):
    caso = datos["entrada_a10"]
    referencia = datos["referencia_evaluador"]
    respuestas = {"A10": datos["respuesta_a10"], "A11": datos["respuesta_a11"]}
    corpus = {fila["evidence_id"]: fila for fila in caso["retrieved_corpus_examples"]}
    visibles = {
        lado: sumar([fila["impacts"] for fila in caso["observed_stages"][lado].values()]) for lado in LADOS
    }
    columnas = tuple(f"{nombre} ({unidad})" for nombre, unidad, _ in IMPACTOS.values())

    print(f"EJEMPLO FICTICIO · {titulo}")
    print("Lee respuestas guardadas en el JSON. No conecta con el modelo.")
    print("\n1. QUÉ RECIBE A10")
    print("La tarea es sumar los valores visibles, estimar los que faltan y clasificar el par.")
    print(f"Caso {caso['case_id']} · " + " · ".join(caso["context"].values()))
    for lado in LADOS:
        ocultas = ", ".join(ETAPAS[etapa] for etapa in caso["hidden_stages"][lado])
        print(f"Etapas ocultas en {lado} · {ocultas}")
    print("Los impactos se expresan por kilogramo de alimento. Menor valor indica menor impacto.")
    filas = []
    for lado in LADOS:
        for etapa, fila in caso["observed_stages"][lado].items():
            filas.append(fila_impactos(f"{lado} · {ETAPAS[etapa]}", fila["impacts"]))
        filas.append(fila_impactos(f"Subtotal visible {lado}", visibles[lado]))
    filas.append(fila_impactos("Tolerancia", caso["tolerance"]))
    tabla(("Etapa visible", *columnas), filas)
    print("\nA10 también recibe las seis etapas de los cuatro ejemplos de consulta.")
    print("Esta tabla destaca las etapas que faltan en el par que debe clasificar.")
    etapas_ocultas = dict.fromkeys(etapa for lado in LADOS for etapa in caso["hidden_stages"][lado])
    tabla(("Ejemplo de consulta", *columnas), [
        fila_impactos(f"{eid} · {ETAPAS[etapa]}", fila["stages"][etapa])
        for eid, fila in corpus.items()
        for etapa in etapas_ocultas
    ])

    print("\n2. QUÉ RESPONDE A10")
    totales = {pasada: totales_de(respuesta) for pasada, respuesta in respuestas.items()}
    tabla(("Alimento", *columnas), [fila_impactos(lado, totales["A10"][lado]) for lado in LADOS])
    print(fill(respuestas["A10"]["brief_justification"], width=88))
    tabla(("Etiqueta", "Probabilidad simulada"), [
        (etiqueta, f"{p:.0%}") for etiqueta, p in respuestas["A10"]["relation_probabilities"].items()
    ])

    print("\n3. QUÉ REVISA A11")
    print("A11 recibe el mismo caso y la respuesta de A10. Revisa sumas, unidades, citas y etiqueta.")
    print("Comprueba cada total sumando el subtotal visible y las etapas del ejemplo citado.")
    revision = respuestas["A11"]
    cambios = []
    for lado in LADOS:
        for k in IMPACTOS:
            coincide = []
            for respuesta in respuestas.values():
                fila = respuesta["candidate_impacts"][lado][k]
                suma = reconstruir_total(fila, visibles[lado][k], caso["hidden_stages"][lado], corpus, k)
                coincide.append("Sí" if suma == fila["value"] else "No")
            cambios.append((
                lado, IMPACTOS[k][0], cifra(totales["A10"][lado][k], k), cifra(totales["A11"][lado][k], k),
                *coincide,
            ))
    tabla(("Alimento", "Indicador", "Total A10", "Total A11", "Cuadra A10", "Cuadra A11"), cambios)
    for lado in LADOS:
        citas = revision["candidate_impacts"][lado]["water_use"]["evidence_ids"]
        print(f"Citas de A11 para la privación de agua de {lado} · {', '.join(citas)}")
    print(fill(revision["brief_justification"], width=88))
    for pasada, respuesta in respuestas.items():
        etiqueta = respuesta["predicted_relation"]
        confianza = respuesta["relation_probabilities"].get(etiqueta)
        print(f"{pasada} eligió {etiqueta} con {confianza:.0%} de probabilidad simulada.")

    print("\n4. CÓMO PUNTÚA EL EVALUADOR")
    print("Comprueba cada respuesta y compara su etiqueta con la referencia de las seis etapas.")
    pruebas = {pasada: comprobar_respuesta(respuesta, caso, corpus) for pasada, respuesta in respuestas.items()}
    tabla(("Comprobación local", *respuestas), [
        (nombre, *("Pasa" if resultado[nombre] else "Falla" for resultado in pruebas.values()))
        for nombre in pruebas["A10"]
    ])
    completos = referencia["totales_completos"]
    tolerancia = caso["tolerance"]
    esperada = clasificar(completos, tolerancia)
    reconstruidos = {
        lado: sumar([visibles[lado], *referencia["etapas_ocultas"][lado].values()]) for lado in LADOS
    }
    if (
        referencia["case_id"] != caso["case_id"]
        or completos != reconstruidos
        or esperada != referencia["expected_relation"]
    ):
        raise ValueError("La referencia guardada no coincide con el caso y la regla de comparación.")
    ganadores = ventajas(completos, tolerancia)
    print("\nReferencia calculada con los totales completos")
    tabla(("Indicador", "A", "B", "Tolerancia", "Menor impacto fuera del margen"), [
        (nombre, cifra(completos["A"][k], k), cifra(completos["B"][k], k), cifra(tolerancia[k], k), ganadores[k])
        for k, (nombre, _, _) in IMPACTOS.items()
    ])
    if esperada == "TRADEOFF":
        print("TRADEOFF indica que cada alimento tiene menor impacto en algún indicador.")
    resultados = {}
    for pasada, respuesta in respuestas.items():
        valida = all(pruebas[pasada].values())
        etiqueta = respuesta["predicted_relation"] if valida else None
        resultados[pasada] = {
            "status": "VALID" if valida else "INVALID_OUTPUT",
            "relation": etiqueta,
            "loss": int(not valida or etiqueta != esperada),
        }
    print("Puntuación · 0 si la respuesta es válida y acierta. 1 si discrepa o falla.")
    tabla(("Pasada", "Estado", "Etiqueta", "Referencia", "Error"), [
        (pasada, fila["status"], fila["relation"] or "—", esperada, str(fila["loss"]))
        for pasada, fila in resultados.items()
    ])
    if resultados != datos["evaluacion"]:
        raise ValueError("La puntuación calculada difiere de la puntuación guardada en el ejemplo.")
    graficar({**totales, "Referencia": completos})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--caso", choices=CASOS, default="faltantes", help="Elige el caso ficticio.")
    archivo, titulo = CASOS[parser.parse_args().caso]
    ruta = Path(__file__).with_name(archivo)
    try:
        recorrer(json.loads(ruta.read_text(encoding="utf-8"), parse_float=Decimal), titulo)
    except (OSError, ValueError, TypeError, KeyError, ArithmeticError) as error:
        raise SystemExit(f"No se pudo reproducir el ejemplo · {error}") from None


if __name__ == "__main__":
    main()
