"""Verify published outcomes from the reviewer archive's aggregate export."""

import argparse
from collections import Counter
from decimal import Decimal, InvalidOperation
from hashlib import sha256
import json
from math import comb, isclose
from pathlib import Path
from random import Random
from statistics import mean, median


MASKS = ("0", "2", "4")
ARMS = ("A10", "A11", "B0", "CONTROL_2PASS")
RELATIONS = {"A_DOMINATES", "B_DOMINATES", "TRADEOFF", "EQUIVALENT_WITHIN_TOLERANCE"}
CONTRAST_ARMS = {
    "A11_minus_A10": ("A11", "A10"),
    "A10_minus_B0": ("A10", "B0"),
    "A11_minus_B0": ("A11", "B0"),
    "A11_minus_CONTROL_2PASS": ("A11", "CONTROL_2PASS"),
    "CONTROL_2PASS_minus_A10": ("CONTROL_2PASS", "A10"),
}
COUNT_FIELDS = (
    "scheduled_scenarios",
    "settled_scenarios",
    "pending_scenarios",
    "valid_scenarios",
    "errors_including_failures",
    "dominance_claims",
    "false_dominance_claims",
)
RELEASE_FILES = {
    ".gitattributes",
    "README.md", "datos-y-escenarios.md", "agentes-y-codigo.md", "ejemplo.py",
    "ejemplo-completo.md", "ejemplo-completo.json", "ejemplo-resultados.png",
    "ejemplo-suma.md", "ejemplo-suma.json", "ejemplo-suma-resultados.png",
    "resultados-estudio.md", "resultados-comparacion.png", "resultados-mascaras.png",
    "reproducir.py", "graficas.py",
    "resultados-reproducidos/tablas-estudio.md",
    "resultados-reproducidos/resultados-comparacion.svg",
    "resultados-reproducidos/resultados-mascaras.svg",
    "verify.py", "results.json",
    "prompts.json", "agent_output.schema.json",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def release_hashes(root):
    rows = [line.split("  ", 1) for line in (root / "SHA256SUMS.txt").read_text(encoding="ascii").splitlines()]
    require(len(rows) == len(RELEASE_FILES) and {name for _, name in rows} == RELEASE_FILES,
            "The integrity manifest has an unexpected file list.")
    return {name: expected for expected, name in rows}


def check_release_hashes(root):
    for name, expected in release_hashes(root).items():
        require(sha256((root / name).read_bytes()).hexdigest() == expected, f"The file changed: {name}.")


def check_arm_totals(report):
    totals = report["by_arm"]
    by_mask = report["by_arm_and_mask"]
    require(set(totals) == set(by_mask) == set(ARMS), "The workflow lists disagree.")
    require(report["scenarios"] == report["pairs"] * len(MASKS), "The case count disagrees with the mask design.")
    control_count = by_mask["CONTROL_2PASS"][MASKS[0]]["scheduled_scenarios"]
    require(0 < control_count <= report["pairs"], "The control cohort size is invalid.")

    for arm in ARMS:
        require(set(by_mask[arm]) == set(MASKS), f"The mask list differs for {arm}.")
        rows = [by_mask[arm][mask] for mask in MASKS]
        expected_size = control_count if arm == "CONTROL_2PASS" else report["pairs"]
        require(all(row["scheduled_scenarios"] == expected_size for row in rows), f"The mask denominators differ for {arm}.")
        for field in COUNT_FIELDS:
            require(sum(row[field] for row in rows) == totals[arm][field], f"The masks do not reconcile for {arm} {field}.")
        statuses = Counter()
        for row in rows:
            statuses.update(row["status_counts"])
        require(dict(statuses) == totals[arm]["status_counts"], f"The mask statuses do not reconcile for {arm}.")
        for row in [*rows, totals[arm]]:
            status = row["status_counts"]
            scheduled = row["scheduled_scenarios"]
            errors = row["errors_including_failures"]
            valid = row["valid_scenarios"]
            require(
                scheduled > 0
                and scheduled == sum(status.values()) == row["settled_scenarios"]
                and row["pending_scenarios"] == 0
                and valid == status.get("VALID", 0)
                and 0 <= scheduled - valid <= errors <= scheduled
                and 0 <= row["false_dominance_claims"] <= row["dominance_claims"] <= valid,
                f"The case counts are inconsistent for {arm}.",
            )
            require(isclose(errors / scheduled, row["error_rate_among_settled"], abs_tol=1e-12),
                    f"The error rate is inconsistent for {arm}.")


def check_agreement(report):
    agreement = report["agreement"]
    first = report["by_arm"]["A10"]
    second = report["by_arm"]["A11"]
    require(
        agreement["jointly_valid"] == second["valid_scenarios"] <= first["valid_scenarios"]
        and agreement["label_changes"] == 0,
        "The archived label agreement is inconsistent with the shared first pass.",
    )
    incorrect = [row["errors_including_failures"] - row["scheduled_scenarios"] + row["valid_scenarios"]
                 for row in (first, second)]
    require(all(value == agreement["shared_errors"] for value in incorrect),
            "The number of shared errors disagrees with the workflow counts.")


def upper_binomial(successes, trials, alpha):
    """Compute the one-sided exact binomial upper bound by CDF inversion."""
    if successes == trials:
        return 1.0
    lo, hi = 0.0, 1.0
    coefficients = [comb(trials, k) for k in range(successes + 1)]
    for _ in range(53):
        p = (lo + hi) / 2
        cdf = sum(coefficient * p**k * (1 - p)**(trials - k)
                  for k, coefficient in enumerate(coefficients))
        if cdf > alpha:
            lo = p
        else:
            hi = p
    return hi


def percentile(sorted_values, probability):
    offset = probability * (len(sorted_values) - 1)
    index = int(offset)
    if index == offset:
        return sorted_values[index]
    return sorted_values[index] + (offset - index) * (sorted_values[index + 1] - sorted_values[index])


def check_contrast(report, name):
    contrast = report["contrasts"][name]
    bins = sorted((int(value), count) for value, count in report["pair_loss_sum_histograms"][name].items())
    masks = len(MASKS)
    require(all(-masks <= value <= masks and isinstance(count, int) and count > 0 for value, count in bins),
            f"The pair loss histogram contains an invalid bin for {name}.")
    left, right = CONTRAST_ARMS[name]
    expected_pairs = min(report["by_arm"][arm]["scheduled_scenarios"] for arm in (left, right)) // masks
    n = sum(count for _, count in bins)
    require(n == expected_pairs == contrast["complete_pairs"] == contrast["scheduled_pairs"]
            and contrast["jointly_pending_scenarios"] == 0,
            f"The pair totals disagree for {name}.")
    if n == report["pairs"]:
        losses = report["by_arm"][left]["errors_including_failures"] - report["by_arm"][right]["errors_including_failures"]
        require(sum(value * count for value, count in bins) == losses,
                f"The histogram and workflow loss totals disagree for {name}.")
    differences = [value / masks for value, count in bins for _ in range(count)]
    point = mean(differences)
    require(isclose(point, contrast["mean_paired_loss_difference"], abs_tol=1e-12),
            f"The point estimate differs from the archived result for {name}.")
    alpha = (1 - report["primary_bootstrap"]["confidence"]) / 2
    sign = [
        -upper_binomial(sum(value < 0 for value in differences), n, alpha),
        upper_binomial(sum(value > 0 for value in differences), n, alpha),
    ]
    require(
        all(isclose(a, b, abs_tol=1e-12) for a, b in zip(sign, contrast["conservative_sign_interval"], strict=True)),
        f"The conservative sign interval differs from the archived endpoints for {name}.",
    )
    lower, upper = contrast["cluster_percentile_interval"]
    require(-1 <= lower <= upper <= 1, f"The archived bootstrap endpoints are invalid for {name}.")
    return point, sign, differences


def check_primary_bootstrap(report, differences):
    bootstrap_settings = report["primary_bootstrap"]
    alpha = (1 - bootstrap_settings["confidence"]) / 2
    rng = Random(bootstrap_settings["seed"])
    # Rebuild a sorted sample from the histogram. The archive hides pair identities.
    samples = sorted(mean(rng.choices(differences, k=len(differences))) for _ in range(bootstrap_settings["resamples"]))
    bootstrap = [percentile(samples, p) for p in (alpha, 1 - alpha)]
    archived = report["contrasts"][report["primary_contrast"]]["cluster_percentile_interval"]
    require(all(isclose(a, b, abs_tol=1e-12) for a, b in zip(bootstrap, archived, strict=True)),
            "The primary bootstrap interval differs from the archived endpoints.")
    return bootstrap


def check_token_accounting(report):
    arm_totals = report["by_arm"]
    attributed = report["attributed_resources"]
    physical = report["physical_resources"]
    execution = report["execution_totals"]
    launched = {}
    for arm in ("A10", "A11", "CONTROL_2PASS"):
        statuses = arm_totals[arm]["status_counts"]
        launched[arm] = arm_totals[arm]["scheduled_scenarios"] - statuses.get("SKIPPED_SHARED_FIRST_PASS", 0)
    require(sum(arm_totals[arm]["scheduled_scenarios"] for arm in launched) == execution["planned_turns"],
            "The planned physical turns disagree with workflow assignments.")
    require(sum(launched.values()) == physical["known_turns"], "The launched physical turns disagree with the workflow statuses.")
    require(
        attributed["A10"]["known_turns"] == launched["A10"]
        and attributed["A11"]["known_turns"] == launched["A11"] + launched["A10"]
        and attributed["CONTROL_2PASS"]["known_turns"] == launched["CONTROL_2PASS"] + arm_totals["CONTROL_2PASS"]["scheduled_scenarios"]
        and attributed["B0"]["known_turns"] == attributed["B0"]["reported_tokens"] == 0,
        "Attributed turns do not match the shared-first-pass design.",
    )
    first_tokens = attributed["A10"]["reported_tokens"]
    a11_tokens = attributed["A11"]["reported_tokens"]
    neutral_tokens = attributed["CONTROL_2PASS"]["reported_tokens"]
    neutral_only_tokens = physical["reported_tokens"] - a11_tokens
    require(0 < first_tokens <= a11_tokens and 0 <= neutral_only_tokens <= neutral_tokens
            and neutral_tokens - neutral_only_tokens <= first_tokens,
            "Measured tokens do not reconcile with shared first-pass attribution.")
    provisioned = physical["turns_without_token_telemetry"] * execution["token_provision_per_missing_turn"]
    require(physical["reported_tokens"] + provisioned == execution["accounted_tokens"],
            "The token provision does not reconcile with the accounted total.")
    return a11_tokens / first_tokens


def check_posthoc(report):
    diagnostics = report["posthoc_diagnostics"]
    changes = diagnostics["response_changes"]
    agreement = report["agreement"]
    jointly_valid = agreement["jointly_valid"]
    require(
        changes["jointly_valid"] == jointly_valid and changes["label_changes"] == agreement["label_changes"],
        "The post hoc comparison disagrees with the audited label counts.",
    )
    for field in ("impact_total_vector_changes", "probability_vector_changes", "evidence_changes",
                  "justification_changes"):
        require(type(changes[field]) is int and 0 <= changes[field] <= jointly_valid,
                f"The post hoc response count is inconsistent for {field}.")
    by_mask = changes["impact_total_vector_changes_by_mask"]
    require(
        set(by_mask) == set(MASKS) and sum(by_mask.values()) == changes["impact_total_vector_changes"]
        and all(type(n) is int and 0 <= n <= min(report["by_arm_and_mask"][arm][mask]["valid_scenarios"]
                                                for arm in ("A10", "A11")) for mask, n in by_mask.items()),
        "The post hoc total changes do not reconcile across masks.",
    )
    confusion = diagnostics["shared_error_confusion"]
    require(
        set(confusion) <= RELATIONS
        and all(set(row) <= RELATIONS - {actual} and all(type(n) is int and n > 0 for n in row.values())
                for actual, row in confusion.items())
        and sum(n for row in confusion.values() for n in row.values()) == agreement["shared_errors"],
        "The post hoc confusion table does not reconcile with the audited shared errors.",
    )

    matched = diagnostics["matched_neutral_subset"]
    subset = ("A10", "A11", "CONTROL_2PASS")
    scenarios = report["by_arm"]["CONTROL_2PASS"]["scheduled_scenarios"]
    errors = matched["errors_including_failures"]
    resources = matched["attributed_resources"]
    require(
        matched["scenarios"] == scenarios == matched["pairs"] * len(MASKS)
        and set(resources) == set(errors) == set(subset)
        and errors["CONTROL_2PASS"] == report["by_arm"]["CONTROL_2PASS"]["errors_including_failures"]
        and all(type(errors[arm]) is int and 0 <= errors[arm] <=
                min(scenarios, report["by_arm"][arm]["errors_including_failures"]) for arm in subset),
        "The post hoc subset counts disagree with the control cohort.",
    )
    for name in ("A11_minus_CONTROL_2PASS", "CONTROL_2PASS_minus_A10"):
        left, right = CONTRAST_ARMS[name]
        histogram = report["pair_loss_sum_histograms"][name]
        require(errors[left] - errors[right] == sum(int(loss) * n for loss, n in histogram.items()),
                f"The post hoc subset losses disagree with the audited {name} histogram.")
    overall = report["attributed_resources"]
    require(resources["CONTROL_2PASS"] == overall["CONTROL_2PASS"],
            "The matched and full neutral token records disagree.")
    for field in ("reported_tokens", "turns_without_token_telemetry", "known_turns"):
        neutral_second = report["physical_resources"][field] - overall["A11"][field]
        first = resources["A10"][field]
        second = resources["A11"][field]
        require(
            0 <= first == resources["CONTROL_2PASS"][field] - neutral_second <= overall["A10"][field]
            and first <= second <= overall["A11"][field],
            f"The matched resource counts are inconsistent for {field}.",
        )


def confidence_histogram(row, maximum):
    counts = Counter()
    for probability, count in row["probability_histogram"].items():
        probability = Decimal(probability)
        require(probability.is_finite() and 0 <= probability <= 1 and type(count) is int and 0 < count <= maximum,
                "An archived confidence bin is invalid.")
        counts[probability] += count
    n = row["classified_as_dominance"]
    require(type(n) is int and 0 <= n <= maximum and n == sum(counts.values()),
            "The confidence histogram does not reconcile with the false-dominance count.")
    # Bins have no case order or cross-arm identifiers, but preserve the exact median.
    values = list(counts.elements())
    expected = {name: float(fn(values)) if values else None
                for name, fn in (("min", min), ("median", median), ("max", max))}
    require(row["predicted_label_probability"] == expected, "An archived confidence summary differs from its histogram.")
    return counts


def check_tradeoff_dominance(report):
    posthoc = report["posthoc_diagnostics"]
    diagnostic = posthoc["tradeoff_dominance_by_mask"]
    by_mask, pooled = diagnostic["by_hidden_stages_per_product"], diagnostic["pooled"]
    pairs = diagnostic["reference_tradeoff_pairs"]
    require(type(pairs) is int and 0 <= pairs <= report["pairs"] and set(by_mask) == set(MASKS),
            "The tradeoff diagnostic has an invalid mask or pair count.")
    totals = {arm: Counter() for arm in ("A10", "A11")}
    same_probabilities = posthoc["response_changes"]["probability_vector_changes"] == 0
    joint_total = 0
    for mask in MASKS:
        row = by_mask[mask]
        n = row["jointly_valid_reference_tradeoffs"]
        validity = report["by_arm_and_mask"]["A11"][mask]["valid_scenarios"]
        require(row["scheduled_reference_tradeoffs"] == pairs and type(n) is int
                and max(0, pairs - report["pairs"] + validity) <= n <= min(pairs, validity)
                and set(row["by_arm"]) == set(totals), "The tradeoff diagnostic has an invalid mask denominator.")
        joint_total += n
        mask_counts = {}
        for arm, counts in totals.items():
            maximum = min(n, report["by_arm_and_mask"][arm][mask]["false_dominance_claims"])
            mask_counts[arm] = confidence_histogram(row["by_arm"][arm], maximum)
            counts.update(mask_counts[arm])
        first, second = mask_counts["A10"], mask_counts["A11"]
        require(sum(first.values()) == sum(second.values()),
                f"False-dominance counts disagree despite shared labels at mask {mask}.")
        if same_probabilities:
            require(first == second,
                    f"Confidence bins disagree despite shared probabilities at mask {mask}.")

    require(pooled["scheduled_reference_tradeoffs"] == pairs * len(MASKS)
            and pooled["jointly_valid_reference_tradeoffs"] == joint_total
            and set(pooled["by_arm"]) == set(totals), "The pooled tradeoff counts do not match the masks.")
    shared = posthoc["shared_error_confusion"].get("TRADEOFF", {})
    shared_dominance = sum(shared.get(label, 0) for label in ("A_DOMINATES", "B_DOMINATES"))
    for arm, counts in totals.items():
        require(confidence_histogram(pooled["by_arm"][arm], joint_total) == counts
                and sum(counts.values()) == shared_dominance,
                "The pooled confidence bins disagree with the masks or the shared false-dominance counts.")


def verify(report):
    """Verify aggregate consistency and rederive the primary paired contrast."""
    require(report["status"] == "OFFLINE_EVALUATION_COMPLETE" and report["exploratory"] is True,
            "This archive requires the completed exploratory evaluation.")
    require(report["primary_contrast"] == "A11_minus_A10", "The primary contrast differs from the protocol.")
    frozen = report["frozen_design"]
    precision = frozen["precision"]
    settings = report["primary_bootstrap"]
    require(
        tuple(map(str, frozen["design"]["missing_stages_per_product"])) == MASKS
        and 0 < settings["confidence"] < 1
        and type(settings["resamples"]) is int and settings["resamples"] > 0
        and settings == {
            "confidence": precision["confidence"], "seed": precision["bootstrap_seed"],
            "resamples": precision["cluster_percentile_bootstrap_resamples"],
        },
        "The frozen masks or resampling settings disagree with the analysis.",
    )
    check_arm_totals(report)
    check_agreement(report)
    require(set(report["contrasts"]) == set(report["pair_loss_sum_histograms"]) == set(CONTRAST_ARMS),
            "The contrast and histogram lists disagree.")
    contrasts = {name: check_contrast(report, name) for name in CONTRAST_ARMS}
    point, sign, differences = contrasts[report["primary_contrast"]]
    bootstrap = check_primary_bootstrap(report, differences)
    token_ratio = check_token_accounting(report)
    check_posthoc(report)
    check_tradeoff_dominance(report)
    counts = report["workflow_counts"]
    require(counts["pair_count"] == report["pairs"] and counts["case_count"] == report["scenarios"]
            and counts["planned_turns"] == report["execution_totals"]["planned_turns"]
            and len(MASKS) * counts["neutral_control_pair_count"] == report["by_arm"]["CONTROL_2PASS"]["scheduled_scenarios"],
            "The frozen workflow counts disagree with the results.")
    return point, bootstrap, sign, token_ratio


def main():
    root = Path(__file__).resolve().parent
    default = root / "results.json"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report", nargs="?", type=Path, default=default, help="Path to the aggregate JSON export.")
    args = parser.parse_args()
    try:
        if args.report.resolve() == default:
            check_release_hashes(root)
        report = json.loads(args.report.read_text(encoding="utf-8"))
        point, bootstrap, sign, token_ratio = verify(report)
    except (InvalidOperation, OSError, KeyError, TypeError, ValueError) as error:
        raise SystemExit(f"Aggregate verification failed. {error}") from error

    for arm in ARMS:
        row = report["by_arm"][arm]
        print(f"{arm} recorded {row['errors_including_failures']}/{row['scheduled_scenarios']} errors "
              f"including failures ({row['error_rate_among_settled']:.1%}).")
    print(f"A11 minus A10 was {point * 100:+.2f} percentage points.")
    print(f"The reconstructed 95% percentile bootstrap interval was [{bootstrap[0] * 100:.2f}, {bootstrap[1] * 100:.2f}] "
          "percentage points and matched the archived endpoints.")
    print(f"The conservative 95% sign interval was [{sign[0] * 100:.2f}, {sign[1] * 100:.2f}] percentage points.")
    print(f"A11 used {token_ratio:.2f} times the reported attributed tokens of A10.")
    print("All paired point estimates and conservative sign intervals matched the archived results. "
          "The primary resampling uses a sorted histogram without pair identities. "
          "The secondary bootstrap endpoints are preserved as audited results.")
    if "posthoc_diagnostics" in report:
        diagnostics = report["posthoc_diagnostics"]
        changes = diagnostics["response_changes"]
        print(f"In {changes['jointly_valid']} jointly valid scenarios, "
              f"{changes['impact_total_vector_changes']} total vectors, "
              f"{changes['probability_vector_changes']} probability vectors, "
              f"{changes['evidence_changes']} evidence lists, and "
              f"{changes['justification_changes']} justification strings changed.")
        matched = diagnostics["matched_neutral_subset"]
        for arm, row in matched["attributed_resources"].items():
            print(f"{arm} had {row['reported_tokens']:,} reported tokens in {matched['scenarios']} matched scenarios "
                  f"with {row['known_turns']} known turns and {row['turns_without_token_telemetry']} unmetered turns.")
        diagnostic = diagnostics["tradeoff_dominance_by_mask"]
        for mask, tradeoffs in (*diagnostic["by_hidden_stages_per_product"].items(), ("pooled", diagnostic["pooled"])):
            n = tradeoffs["jointly_valid_reference_tradeoffs"]
            for arm, row in tradeoffs["by_arm"].items():
                print(f"False dominance ({mask}, {arm}): {row['classified_as_dominance']}/{n}; "
                      f"median reported confidence {row['predicted_label_probability']['median']}.")


if __name__ == "__main__":
    main()
