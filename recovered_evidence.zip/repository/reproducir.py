"""Regenera las tablas y gráficas del estudio a partir de results.json."""

from decimal import InvalidOperation
from hashlib import sha256
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from graficas import escribir_graficas
from verify import CONTRAST_ARMS, MASKS, release_hashes, verify


METODOS = {
    "A10": "A10",
    "A11": "A11",
    "B0": "B0 · Mediana",
    "CONTROL_2PASS": "Control neutro",
}
PRINCIPALES = ("A10", "A11", "B0")


def entero(valor):
    return f"{valor:,}".replace(",", " ")


def porcentaje(proporcion, decimales=1):
    return f"{100 * proporcion:.{decimales}f}".replace(".", ",") + " %"


def puntos(proporcion):
    return f"{100 * proporcion:+.2f}".replace(".", ",").replace("-", "−")


def cuenta(errores, escenarios):
    return f"{errores}/{escenarios} ({porcentaje(errores / escenarios)})"


def tabla(encabezados, filas):
    def fila(valores):
        return "| " + " | ".join(map(str, valores)) + " |"

    return "\n".join([fila(encabezados), fila(("---",) * len(encabezados)), *(fila(row) for row in filas)])


def comparacion_general(datos):
    filas = []
    for metodo in PRINCIPALES:
        resultados = datos["by_arm"][metodo]
        escenarios = resultados["scheduled_scenarios"]
        fallos = escenarios - resultados["valid_scenarios"]
        errores = resultados["errors_including_failures"]
        recursos = datos["attributed_resources"][metodo]
        filas.append((
            METODOS[metodo], errores - fallos, fallos, cuenta(errores, escenarios),
            entero(recursos["reported_tokens"]), recursos["turns_without_token_telemetry"],
        ))
    return tabla(
        ("Método", "Etiquetas válidas incorrectas", "Fallos u omisiones", "Errores totales",
         "Tokens reportados", "Turnos sin recuento de tokens"),
        filas,
    )


def errores_por_etapa(datos):
    por_metodo = datos["by_arm_and_mask"]
    return tabla(
        ("Etapas ocultas por alimento", *(METODOS[metodo] for metodo in PRINCIPALES)),
        (
            (mascara, *(cuenta(por_metodo[metodo][mascara]["errors_including_failures"],
                              por_metodo[metodo][mascara]["scheduled_scenarios"]) for metodo in PRINCIPALES))
            for mascara in MASKS
        ),
    )


def diagnostico_compensaciones(diagnostico):
    filas = []
    for mascara in (*MASKS, "pooled"):
        resumen = diagnostico["pooled"] if mascara == "pooled" else diagnostico["by_hidden_stages_per_product"][mascara]
        por_metodo = resumen["by_arm"]
        if por_metodo["A10"] != por_metodo["A11"]:
            raise ValueError("El diagnóstico compartido requiere los mismos recuentos y probabilidades de A10 y A11.")
        resultados = por_metodo["A10"]
        probabilidades = resultados["predicted_label_probability"]
        if probabilidades["median"] is None:
            confianza = "—"
        else:
            mediana = porcentaje(probabilidades["median"], 0)
            minimo = f"{100 * probabilidades['min']:.0f}"
            maximo = porcentaje(probabilidades["max"], 0)
            confianza = f"{mediana} ({minimo}–{maximo})"
        total = resumen["jointly_valid_reference_tradeoffs"]
        filas.append(("Total" if mascara == "pooled" else mascara,
                      f"{resultados['classified_as_dominance']}/{total}", confianza))
    return tabla(("Etapas ocultas por alimento", "Compensaciones clasificadas como dominancia por cada flujo",
                  "Probabilidad declarada para esas etiquetas, mediana (rango)"), filas)


def control_compartido(matched):
    return tabla(
        ("Método", "Errores, incluidos los fallos", "Tokens reportados"),
        (
            (METODOS[metodo], cuenta(matched["errors_including_failures"][metodo], matched["scenarios"]),
             entero(matched["attributed_resources"][metodo]["reported_tokens"]))
            for metodo in ("A10", "A11", "CONTROL_2PASS")
        ),
    )


def diferencias_pareadas(datos):
    filas = []
    for contraste, (primero, segundo) in CONTRAST_ARMS.items():
        fila = datos["contrasts"][contraste]
        inferior, superior = fila["conservative_sign_interval"]
        filas.append((
            f"{METODOS[primero]} menos {METODOS[segundo]}", fila["complete_pairs"],
            puntos(fila["mean_paired_loss_difference"]), f"{puntos(inferior)} a {puntos(superior)}",
        ))
    return tabla(("Comparación", "Pares", "Diferencia en puntos porcentuales",
                  "Intervalo conservador del 95 % en puntos porcentuales"), filas)


def escribir_tablas(datos, salida, bootstrap):
    controles = datos["posthoc_diagnostics"]["matched_neutral_subset"]
    diagnostico = datos["posthoc_diagnostics"]["tradeoff_dominance_by_mask"]
    parrafos = [
        "# Tablas reproducidas del estudio",
        "Generadas con `python -B reproducir.py` a partir de los agregados auditados. "
        "[Datos JSON](../results.json) · [Lectura de los resultados](../resultados-estudio.md) · "
        "[Cómo reproducir](../README.md#reproducir-tablas-y-gráficas)",
        "## Comparación general",
        f"Los mismos {datos['pairs']} pares se evaluaron en {datos['scenarios']} escenarios por método. "
        "El recuento de A11 incluye la primera pasada compartida. [Gráfica de errores y tokens](resultados-comparacion.svg)",
        comparacion_general(datos),
        "## Errores por etapas ocultas",
        "Los recuentos incluyen etiquetas incorrectas y fallos. [Gráfica por etapas ocultas](resultados-mascaras.svg)",
        errores_por_etapa(datos),
        "## Compensaciones clasificadas como dominancia",
        "El denominador cuenta los escenarios cuya referencia indicaba una compensación y que tienen dos respuestas válidas. "
        f"En total se incluyen distintas versiones de {diagnostico['reference_tradeoff_pairs']} pares.",
        diagnostico_compensaciones(diagnostico),
        "## Control en escenarios compartidos",
        f"Los tres flujos se comparan en los mismos {controles['scenarios']} escenarios de {controles['pairs']} pares. "
        "A11 y el control incluyen los tokens de la primera pasada.",
        control_compartido(controles),
        "## Diferencias pareadas",
        "Una diferencia positiva indica más errores para el primer método. "
        "El intervalo bootstrap del 95 % para A11 menos A10, reconstruido a partir del histograma por pares, "
        f"va de {puntos(bootstrap[0])} a {puntos(bootstrap[1])} puntos porcentuales.",
        diferencias_pareadas(datos),
    ]
    (salida / "tablas-estudio.md").write_text("\n\n".join(parrafos) + "\n", encoding="utf-8", newline="\n")


def main():
    raiz = Path(__file__).resolve().parent
    salida = raiz / "resultados-reproducidos"
    try:
        fuente = (raiz / "results.json").read_bytes()
        if (raiz / "SHA256SUMS.txt").exists():
            if sha256(fuente).hexdigest() != release_hashes(raiz)["results.json"]:
                raise ValueError("results.json no coincide con la huella publicada.")
        datos = json.loads(fuente.decode("utf-8"))
        _, bootstrap, _, _ = verify(datos)
        with TemporaryDirectory(dir=raiz) as temporal:
            area = Path(temporal)
            escribir_tablas(datos, area, bootstrap)
            escribir_graficas(datos, area)
            salida.mkdir(exist_ok=True)
            for archivo in sorted(area.iterdir()):
                archivo.replace(salida / archivo.name)
    except (InvalidOperation, OSError, KeyError, TypeError, ValueError) as error:
        raise SystemExit(f"No se pudieron reproducir los resultados. {error}") from error
    print("Tablas verificadas y dos graficas generadas en resultados-reproducidos/.")


if __name__ == "__main__":
    main()
