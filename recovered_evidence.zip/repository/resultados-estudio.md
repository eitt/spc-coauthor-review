# Resultados auditados del estudio con AGRIBALYSE

El estudio exploratorio comparó **34 pares de alimentos** usando datos publicados de AGRIBALYSE 3.2. Cada par se evaluó con cero, dos y cuatro etapas ocultas por alimento, lo que dio **102 escenarios**. Se comparó la etiqueta de cada respuesta con la obtenida de los totales publicados para cambio climático, privación de agua y eutrofización de agua dulce. [Datos y diseño de los escenarios](datos-y-escenarios.md) · [Cifras auditadas en JSON](results.json)

[Tablas reproducidas](resultados-reproducidos/tablas-estudio.md) · [Comando para regenerar las tablas y gráficas](README.md#reproducir-tablas-y-gráficas)

## Qué cambió con la revisión

A11 devolvió **la misma etiqueta que A10 en los 99 escenarios con dos respuestas válidas**, aunque cambió al menos un total estimado en 6 de ellos. En 29 de esos escenarios, la etiqueta de ambos discrepó de la referencia. Un tiempo de espera agotado de A10 impidió la revisión de ese escenario. A11 agotó su tiempo de espera en otros dos.

![En 102 escenarios, A10 tuvo 29 errores de etiqueta y 1 fallo, y A11 tuvo 29 errores de etiqueta y 3 fallos. Los flujos registraron 1 432 535 y 2 915 761 tokens, respectivamente.](resultados-reproducidos/resultados-comparacion.svg)

[Tabla de recuentos y tokens](resultados-reproducidos/tablas-estudio.md#comparación-general) · [Gráfica en PNG](resultados-comparacion.png)

La diferencia de error de **A11 menos A10 fue de +1,96 puntos porcentuales**. El intervalo conservador del 95 % va de **−10,28 a +19,68 puntos porcentuales**. El cálculo agrupa las tres versiones de cada par y supone que los pares son independientes y proceden de una población común. Bajo ese supuesto, los datos son compatibles tanto con una reducción como con un aumento del error. Con 34 pares, el estudio quedó por debajo de la precisión prevista. [Diferencias pareadas e intervalos](resultados-reproducidos/tablas-estudio.md#diferencias-pareadas)

El flujo con revisión registró **2,04 veces** los tokens reportados por el flujo de una sola pasada. Los tokens son las unidades de texto que cuenta el servicio al procesar la entrada y generar la respuesta. El recuento de A11 incluye la primera pasada compartida. Hubo un turno atribuido a A10 y tres a A11 cuyo registro carecía de datos de tokens. El apartado `physical_resources` del JSON contabiliza cada turno ejecutado una sola vez. [Datos de ejecución en el JSON](results.json)

## Qué ocurrió al ocultar etapas

Los escenarios con más etapas ocultas registraron más errores. Los ejemplos de consulta podían variar entre escenarios de un mismo par. En cada escenario, A10 y A11 recibieron los mismos datos ambientales y ejemplos. El panel superior cuenta las etiquetas incorrectas y los fallos. El inferior se centra en los escenarios en que la referencia indicaba una compensación entre impactos y ambos agentes devolvieron respuestas válidas.

![Con cero, dos y cuatro etapas ocultas, A10 registra 1, 10 y 19 errores de 34, y A11 registra 1, 11 y 20 de 34. En los casos de compensación con dos respuestas válidas, ambos declaran dominancia en 0 de 15, 5 de 14 y 9 de 15 escenarios.](resultados-reproducidos/resultados-mascaras.svg)

[Tabla de errores por etapas ocultas](resultados-reproducidos/tablas-estudio.md#errores-por-etapas-ocultas) · [Gráfica en PNG](resultados-mascaras.png)

Una compensación significa que un alimento tiene menor impacto en algún indicador y el otro tiene menor impacto en otro, con diferencias que superan las tolerancias. El diagnóstico posterior muestra cuántas veces cada flujo etiquetó como dominancia un escenario de ese tipo y qué probabilidad declaró para la etiqueta errónea.

| Etapas ocultas por alimento | Compensaciones clasificadas como dominancia por cada flujo | Probabilidad declarada para esas etiquetas, mediana (rango) |
| ---: | ---: | ---: |
| 0 | 0/15 | — |
| 2 | 5/14 | 75 % (65–98 %) |
| 4 | 9/15 | 65 % (45–95 %) |
| **Total** | **14/44** | **65 % (45–98 %)** |

El denominador de la tabla reúne los escenarios con referencia de compensación y dos respuestas válidas. El total agrupa versiones de los mismos 15 pares. La probabilidad es la que cada respuesta asignó a su propia etiqueta, y el rango resume los valores observados entre los errores. [Tabla reproducida](resultados-reproducidos/tablas-estudio.md#compensaciones-clasificadas-como-dominancia)

## Cómo se comparan la mediana y el control

**B0**, el método que completa las etapas ocultas con medianas y aplica una regla fija, tuvo **35 errores de 102 (34,3 %)**. Completó los 102 escenarios sin llamadas al modelo.

El **control neutro** volvió a estimar el par con los mismos datos y la respuesta de A10, mediante una instrucción general. Se aplicó a 24 pares, es decir, 72 escenarios. La tabla usa esos mismos escenarios para los tres métodos.

| Método en los mismos 72 escenarios | Errores, incluidos los fallos | Tokens reportados |
| --- | ---: | ---: |
| A10 · Primera respuesta | 26/72 (36,1 %) | 1 008 621 |
| A11 · Revisión dirigida | 28/72 (38,9 %) | 2 043 888 |
| Control neutro · Segunda estimación | 27/72 (37,5 %) | 2 042 879 |

Los recuentos del control y de A11 incluyen los tokens de la primera pasada. [Tabla reproducida](resultados-reproducidos/tablas-estudio.md#control-en-escenarios-compartidos) · [Instrucciones de ambos flujos](prompts.json)

## Cómo verificar las cifras

En el JSON, `by_arm` contiene los recuentos por método, `attributed_resources` contiene los tokens reportados y `contrasts` conserva los intervalos. La gráfica por etapas divide los errores de `by_arm_and_mask` por los 34 escenarios de cada nivel. La gráfica de dominancia divide cada recuento de `tradeoff_dominance_by_mask` por los escenarios de referencia de ese nivel con dos respuestas válidas. [Cifras auditadas en JSON](results.json) · [Código de reproducción](reproducir.py) · [Comando de verificación](README.md#auditoría-de-los-resultados-guardados)
