# Ejemplo ilustrativo con datos ficticios

Imaginemos dos purés de legumbres listos para consumir. A10 debe compararlos aunque falten los datos de envasado y transporte. A11 recibe la primera respuesta y comprueba si puede mejorarla con la misma información. Las cifras y las dos respuestas son ficticias. Puedes seguir los cuatro pasos en esta página o consultar los campos exactos en el [ejemplo completo en JSON](ejemplo-completo.json).

## Cómo ejecutar el ejemplo

Con Python 3.12, abre una terminal en la carpeta principal del repositorio y ejecuta el siguiente comando.

```text
python -X utf8 -B ejemplo.py
```

El programa lee los datos y las respuestas guardadas en el JSON ficticio. En la terminal verás las etapas visibles, la respuesta de A10 y qué comprobaciones puede hacer A11 con los mismos datos. Las gráficas de barras comparan las estimaciones y los totales completos por indicador, y la tabla final muestra cómo se puntúa cada respuesta. Puedes recorrer el caso sin instalar paquetes adicionales, iniciar sesión o conectarte a internet. La ejecución no llama al modelo ni genera archivos de salida. [Código del ejemplo](ejemplo.py)

```mermaid
flowchart LR
    caso["Etapas visibles y cuatro ejemplos"] --> a10["A10 estima y clasifica"]
    caso --> a11["A11 revisa y clasifica"]
    a10 -->|"Primera respuesta"| a11
    a10 --> evaluador["El evaluador comprueba ambas respuestas"]
    a11 --> evaluador
    referencia["Totales completos del par"] --> evaluador
```

## 1. Qué recibe A10

A10 recibe una instrucción para estimar y clasificar el par, seguida por el identificador del caso, el contexto de los alimentos, las unidades, las tolerancias y las etapas visibles de cada puré. Hay cuatro etapas visibles y dos ocultas por alimento. La tolerancia es el margen dentro del cual la regla considera que dos valores son equivalentes para un indicador. En cada indicador, un valor menor representa un impacto menor.

| Alimento y etapa visible | Cambio climático (kg CO₂ eq) | Privación de agua (m³) | Eutrofización de agua dulce (kg P eq) |
| --- | ---: | ---: | ---: |
| A · Agricultura | 0,180 | 0,005 | 0,000060 |
| A · Transformación | 0,060 | 0,005 | 0,000030 |
| A · Distribución | 0,010 | 0,001 | 0,000006 |
| A · Consumo | 0,030 | 0,002 | 0,000016 |
| **Subtotal visible de A** | **0,280** | **0,013** | **0,000112** |
| B · Agricultura | 0,220 | 0,008 | 0,000070 |
| B · Transformación | 0,100 | 0,010 | 0,000035 |
| B · Distribución | 0,020 | 0,002 | 0,000008 |
| B · Consumo | 0,035 | 0,003 | 0,000018 |
| **Subtotal visible de B** | **0,375** | **0,023** | **0,000131** |
| Tolerancia ficticia | 0,010 | 0,002 | 0,000020 |

Las cifras se expresan por kilogramo de alimento. Los subtotales de la tabla se calculan aquí para seguir el ejemplo. En `entrada_a10` puedes ver las cuatro etapas tal como llegan a A10 y los cuatro alimentos ficticios del corpus de consulta. Esos alimentos vienen con sus seis etapas y sirven para orientar las estimaciones. Los datos completos del par que se está comparando siguen otro camino y llegan solo al evaluador. [Cómo se prepararon los escenarios](datos-y-escenarios.md#de-34-pares-a-102-escenarios)

## 2. Qué responde A10

En la respuesta simulada, A10 toma del ejemplo `R-1` los valores de envasado y transporte para estimar las dos etapas ocultas de A. Para B usa `R-2`. Esta forma de estimar sirve para seguir la aritmética del ejemplo. La instrucción del estudio pedía usar la evidencia disponible y marcar los totales como estimados.

| Cifra | Cambio climático (kg CO₂ eq) | Privación de agua (m³) | Eutrofización de agua dulce (kg P eq) |
| --- | ---: | ---: | ---: |
| Etapas ocultas estimadas para A | 0,050 | 0,005 | 0,000038 |
| **Total estimado de A** | **0,330** | **0,018** | **0,000150** |
| Etapas ocultas estimadas para B | 0,050 | 0,006 | 0,000027 |
| **Total estimado de B** | **0,425** | **0,029** | **0,000158** |

Para obtener el total de privación de agua de A, por ejemplo, A10 suma `0,013 + 0,003 + 0,002 = 0,018`. Cita `OBS-A-agriculture` como evidencia visible y `R-1` para la estimación. En `respuesta_a10`, cada total tiene su unidad, la marca `estimated` y sus citas. La respuesta incluye una justificación breve y las probabilidades asignadas a las cuatro etiquetas.

A10 elige `A_DOMINATES` y le asigna una probabilidad simulada de `0,80`. Con estos totales, A parece mejor que B en cambio climático y privación de agua. En eutrofización la diferencia de `0,000008` queda dentro de la tolerancia de `0,000020`. La regla clasifica el par como dominancia de A porque A tiene una ventaja fuera del margen en al menos un indicador y B carece de una ventaja fuera del margen en los otros. [Instrucción y formato de respuesta](prompts.json) · [Esquema JSON](agent_output.schema.json)

## 3. Qué revisa A11

A11 recibe la instrucción de revisar, seguida de `entrada_a10` y `respuesta_a10`. Con esos dos elementos comprueba que las estimaciones usen las unidades del caso, respeten los datos visibles y citen evidencia disponible. También contrasta la etiqueta con los totales y comprueba que las cuatro probabilidades sumen uno.

En `respuesta_a11`, la revisión conserva las cifras, las probabilidades y la etiqueta de A10. La estimación de privación de agua de A sigue siendo `0,018 m³`, coherente con el cálculo anterior. La revisión puede comprobar de dónde sale esa cifra, pero los valores de envasado y transporte de A siguen ocultos.

## 4. Cómo comprueba el resultado el evaluador

El programa comprueba primero que cada respuesta tenga los campos requeridos, unidades correctas, citas permitidas y una etiqueta coherente con sus propios totales. En este ejemplo las dos pasan esa comprobación. Para determinar si acertaron, el evaluador usa `referencia_evaluador`, que contiene los totales completos de las seis etapas del par ficticio. Por ejemplo, con las cifras de referencia del envasado y el transporte, el total de privación de agua de A es `0,013 + 0,020 + 0,026 = 0,059 m³`.

### Resultados del ejercicio ficticio

Las dos respuestas simuladas pasan la validación, pero cada una recibe un error al compararse con la referencia. El evaluador asigna `0` cuando una respuesta válida coincide con la referencia y `1` cuando discrepa o falla.

| Pasada | Validación | Etiqueta devuelta | Etiqueta de referencia | Error |
| --- | --- | --- | --- | ---: |
| A10 | `VALID` | `A_DOMINATES` | `TRADEOFF` | 1 |
| A11 | `VALID` | `A_DOMINATES` | `TRADEOFF` | 1 |

![Tres gráficas comparan los impactos por kilogramo que estiman A10 y A11 con los totales de referencia de los dos purés ficticios. Para A, la referencia supera las estimaciones de agua y eutrofización.](ejemplo-resultados.png)

Al incluir las etapas ocultas, A conserva la ventaja en cambio climático y B resulta mejor en los otros dos indicadores. La referencia es `TRADEOFF` porque cada alimento tiene un impacto menor en algún indicador y las diferencias superan sus tolerancias.

| Indicador por kg de alimento | Total completo de A | Total completo de B | Menor impacto fuera de la tolerancia |
| --- | ---: | ---: | --- |
| Cambio climático (kg CO₂ eq) | 0,330 | 0,425 | A |
| Privación de agua (m³) | 0,059 | 0,029 | B |
| Eutrofización de agua dulce (kg P eq) | 0,000212 | 0,000158 | B |

[Datos y respuestas del ejercicio](ejemplo-completo.json) · [Recuentos del estudio](datos-y-escenarios.md#recuentos-por-nivel-de-datos-ocultos)

En el [ejercicio de las croquetas](ejemplo-suma.md), A11 vuelve a sumar los valores citados por A10 y corrige la clasificación.
