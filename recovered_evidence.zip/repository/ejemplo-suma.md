# Ejercicio ficticio con una suma corregida

Dos tipos de croquetas de legumbres se comparan por kilogramo de alimento. En este ejercicio las respuestas de A10 y A11 fueron escritas para mostrar qué ocurre cuando una suma incorrecta cambia la clasificación del par. [Datos y respuestas simuladas en JSON](ejemplo-suma.json)

## Qué recibe A10

A10 ve los valores de agricultura, transformación, distribución y consumo. Para estimar los aportes de envasado y transporte, que están ocultos en cada croqueta, recibe cuatro ejemplos de consulta. La respuesta de A10 usa `R-1` para A y `R-2` para B. La tabla muestra las cifras de privación de agua que usa esa respuesta.

| Aporte por kg de alimento | Croqueta A (m³) | Croqueta B (m³) |
| --- | ---: | ---: |
| Subtotal de las cuatro etapas visibles | 0,018 | 0,027 |
| Envasado tomado del ejemplo citado | 0,003 | 0,004 |
| Transporte tomado del ejemplo citado | 0,002 | 0,002 |
| **Suma de los tres aportes** | **0,023** | **0,033** |

## Qué cambia cuando A11 repite la suma

A10 da **0,043 m³** para A al sumar los tres aportes. Con ese valor, A parece tener un menor impacto climático y B, una menor privación de agua. A10 devuelve `TRADEOFF`, la etiqueta que corresponde cuando cada alimento lleva ventaja en un indicador.

A11 recibe los mismos datos y la primera respuesta. Repite la suma de A, **0,018 + 0,003 + 0,002 = 0,023 m³**, y actualiza la etiqueta a `A_DOMINATES`. Con la cifra corregida, A tiene menor impacto climático y menor privación de agua. La diferencia de eutrofización queda dentro de la tolerancia de 0,000020 kg P eq por kilogramo de alimento.

| Indicador por kg de alimento | A según A10 | A según A11 | Referencia de A | B en las dos respuestas y la referencia |
| --- | ---: | ---: | ---: | ---: |
| Cambio climático (kg CO₂ eq) | 0,350 | 0,350 | 0,350 | 0,440 |
| Privación de agua (m³) | 0,043 | **0,023** | 0,023 | 0,033 |
| Eutrofización de agua dulce (kg P eq) | 0,000175 | 0,000175 | 0,000175 | 0,000182 |

## Cómo cambia la puntuación

Las dos respuestas pasan la validación porque cumplen el formato y sus etiquetas son coherentes con los totales que declaran. Con dos etapas ocultas, la validación de la respuesta admite totales estimados. Para puntuar el acierto, el evaluador compara las etiquetas con `A_DOMINATES`, la referencia obtenida al aplicar las tolerancias a los totales completos.

| Pasada | Validación | Etiqueta devuelta | Referencia | Error |
| --- | --- | --- | --- | ---: |
| A10 | `VALID` | `TRADEOFF` | `A_DOMINATES` | 1 |
| A11 | `VALID` | `A_DOMINATES` | `A_DOMINATES` | 0 |

![La corrección baja la privación de agua estimada para A de 0,043 a 0,023 m³ por kg. B sigue en 0,033. A10 recibe un error y A11 acierta.](ejemplo-suma-resultados.png)

En el [ejercicio de los purés](ejemplo-completo.md#resultados-del-ejercicio-ficticio), las dos respuestas conservaron el mismo error porque los aportes de las etapas ocultas eran distintos de los que habían estimado.

## Cómo ejecutarlo

Desde la carpeta del repositorio, ejecuta el comando con Python 3.12. El programa lee el JSON ficticio, comprueba las sumas y vuelve a calcular la puntuación sin llamar al modelo.

```text
python -X utf8 -B ejemplo.py --caso suma
```
