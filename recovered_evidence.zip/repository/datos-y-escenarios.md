# Datos y escenarios de AGRIBALYSE

## La base de datos y el ACV

Un análisis de ciclo de vida (ACV) estima los impactos ambientales de un producto a lo largo de etapas como la obtención de materias primas, la fabricación y el uso. En este estudio usamos los impactos que AGRIBALYSE 3.2 ya publicó para un kilogramo de alimento tal como se consume en Francia. El experimento consistió en ocultar parte de esa información y evaluar cómo se comparaban los alimentos con los datos disponibles.

| Indicador | Qué mide | Unidad por kilogramo de alimento |
| --- | --- | --- |
| Cambio climático | La contribución de las emisiones al calentamiento. | kg de CO₂ equivalente |
| Privación de agua | La reducción de agua disponible para otros usos, considerando la escasez del lugar. | m³ de privación de agua |
| Eutrofización de agua dulce | El potencial de enriquecer ríos y lagos con nutrientes, lo que puede favorecer el crecimiento excesivo de algas. | kg de fósforo equivalente |

## De 34 pares a 102 escenarios

Antes del experimento, el equipo reservó un conjunto de alimentos de AGRIBALYSE para la evaluación final. Para formar los pares, revisamos su familia, subgrupo, preparación y forma de consumo. Buscamos alimentos que pudieran desempeñar un papel parecido en una comida. Por ejemplo, dos legumbres cocidas se pueden comparar como guarnición, aunque tengan sabores diferentes. Los 34 pares procedían de 68 grupos distintos de productos. Cada par dio lugar a tres escenarios con distintos niveles de información disponible.

```mermaid
flowchart TD
    Base["AGRIBALYSE 3.2 · Impactos por alimento y etapa"] --> Pares["34 pares de alimentos comparables"]
    Pares --> Completo["0 etapas ocultas por alimento · 34 escenarios"]
    Pares --> Dos["2 etapas ocultas por alimento · 34 escenarios"]
    Pares --> Cuatro["4 etapas ocultas por alimento · 34 escenarios"]
    Completo --> Total["102 escenarios con los mismos 34 pares"]
    Dos --> Total
    Cuatro --> Total
```

### Ejemplo de lo que veía el modelo

Cada alimento tenía seis etapas. El programa fijó un orden de ocultación para cada alimento, que podía diferir entre los dos del par. En la versión con cuatro etapas ocultas, quedaron ocultas las mismas dos de la versión intermedia y dos más. Al ocultar una etapa, se retiraban juntos los tres valores de impacto de esa etapa.

Este ejemplo muestra un orden ficticio para **uno de los dos alimentos** de un par.

| Etapa | Versión con 0 ocultas | Versión con 2 ocultas | Versión con 4 ocultas |
| --- | --- | --- | --- |
| Agricultura | Visible | Visible | Oculta |
| Transformación | Visible | Visible | Visible |
| Envasado | Visible | Oculta | Oculta |
| Transporte | Visible | Oculta | Oculta |
| Distribución | Visible | Visible | Oculta |
| Consumo | Visible | Visible | Visible |

### Cómo se comprobó cada respuesta

Para cada par usamos los totales publicados en la columna `Total` de la hoja `Detail etape`. Aplicamos una tolerancia fija a cada indicador para tratar diferencias pequeñas como empates. Un impacto menor es preferible. De esa comparación salen cuatro etiquetas posibles.

- **A domina a B** si A tiene una ventaja que supera la tolerancia en al menos un indicador y cualquier desventaja queda dentro de la tolerancia de su indicador.
- **B domina a A** si se cumple la misma regla a favor de B.
- **Hay una compensación** si A es mejor en un indicador y B es mejor en otro, con ambas diferencias por encima de sus tolerancias. Por ejemplo, A podría tener un impacto climático menor y una privación de agua mayor que B.
- **Hay equivalencia dentro de la tolerancia** si las tres diferencias quedan dentro de sus márgenes.

El evaluador usó la misma etiqueta de referencia para las tres versiones del par. Así pudo comparar las respuestas con el mismo criterio aunque el modelo viera menos datos. El libro de referencia corresponde al archivo 641911 del conjunto AGRIBALYSE 3.2 (DOI `10.57745/XTENSJ`, Licencia Abierta 2.0). El apartado `provenance` del JSON registra su enlace y su huella SHA-256. [Ficha de AGRIBALYSE 3.2](https://entrepot.recherche.data.gouv.fr/dataset.xhtml?persistentId=doi%3A10.57745%2FXTENSJ) · [Guía oficial de acceso a los datos](https://doc.agribalyse.fr/documentation-en/agribalyse-data/data-access) · [Procedencia en el JSON](results.json)

```mermaid
flowchart LR
    Visibles["Datos visibles en una de las tres versiones"] --> Agentes["A10 responde · A11 revisa con los mismos datos"]
    Agentes --> Evaluador["El evaluador compara cada respuesta con la referencia"]
    Completos["Totales de ambos alimentos con todas las etapas"] --> Referencia["Una etiqueta de referencia por par"]
    Referencia --> Evaluador
```

## Recuentos por nivel de datos ocultos

| Etapas ocultas por alimento | Escenarios programados | A10 respuestas válidas | A10 errores | A11 respuestas válidas | A11 errores |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 34 | 33 | 1 | 33 | 1 |
| 2 | 34 | 34 | 10 | 33 | 11 |
| 4 | 34 | 34 | 19 | 33 | 20 |
| **Total** | **102** | **101** | **30** | **99** | **32** |

La columna de errores cuenta las respuestas incorrectas y los fallos, como un tiempo de espera agotado o una revisión omitida porque falló la primera respuesta. Una respuesta válida puede ser incorrecta si su clasificación difiere de la referencia.

[Ver las gráficas de errores y de compensaciones clasificadas como dominancia](resultados-estudio.md#qué-ocurrió-al-ocultar-etapas) · [Reproducir las tablas y gráficas](README.md#reproducir-tablas-y-gráficas)

## Cómo leer los datos del repositorio

Para comprobar una fila en el JSON, busca `by_arm_and_mask` y sigue las secciones `A10` y `"2"`. Allí aparecen 34 escenarios programados (`scheduled_scenarios`), 34 respuestas válidas (`valid_scenarios`) y 10 errores (`errors_including_failures`). Es la fila de A10 con dos etapas ocultas por alimento. [Datos agregados en JSON](results.json)

Puedes recorrer un caso ficticio con `python -X utf8 -B ejemplo.py` o seguir cómo se arma la entrada y se revisa la salida de cada agente. [Ejemplo en Python](ejemplo.py) · [Agentes y código](agentes-y-codigo.md) · [Cómo verificar las cifras](README.md#auditoría-de-los-resultados-guardados)
