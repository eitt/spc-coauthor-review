"""Gráficas SVG del estudio a partir de los resultados agregados."""

from html import escape
from math import ceil
from pathlib import Path


MODELOS = ("A10", "A11")
AZUL = "#22678a"
MARINO = "#173550"
OCRE = "#a25014"
TEXTO = "#152c40"
SECUNDARIO = "#435970"
CUADRICULA = "#d7e1ea"
ANCHO = 940
ESTILOS = {
    "": (16, 400, TEXTO),
    "titulo": (34, 700, TEXTO),
    "panel": (23, 700, TEXTO),
    "etiqueta": (16, 700, TEXTO),
    "nota": (15, 400, SECUNDARIO),
    "eje": (14, 400, SECUNDARIO),
    "interior": (14, 700, "#ffffff"),
}


def _texto(x, y, texto, *, clase="", ancla="start"):
    tamano, peso, color = ESTILOS[clase]
    return (
        f'<text x="{x:g}" y="{y:g}" font-family="Arial, sans-serif" font-size="{tamano}" '
        f'font-weight="{peso}" fill="{color}" text-anchor="{ancla}">'
        f"{escape(str(texto))}</text>"
    )


def _rectangulo(x, y, ancho, alto, color):
    return f'<rect x="{x:g}" y="{y:g}" width="{ancho:g}" height="{alto:g}" fill="{color}"/>'


def _linea(x1, y1, x2, y2):
    return f'<line x1="{x1:g}" y1="{y1:g}" x2="{x2:g}" y2="{y2:g}" stroke="{CUADRICULA}"/>'


def _svg(titulo, descripcion, alto, elementos):
    return "\n".join([
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {ANCHO} {alto}" '
        f'width="{ANCHO}" height="{alto}" role="img" aria-labelledby="titulo descripcion" xml:lang="es">',
        f'<title id="titulo">{escape(titulo)}</title>',
        f'<desc id="descripcion">{escape(descripcion)}</desc>',
        _rectangulo(0, 0, ANCHO, alto, "#ffffff"),
        *elementos,
        "</svg>",
        "",
    ])


def _encabezado(titulo, datos):
    return [
        _texto(42, 56, titulo, clase="titulo"),
        _texto(
            42, 86,
            f"Estudio exploratorio · {datos['pairs']} pares de alimentos · {datos['scenarios']} escenarios",
            clase="nota",
        ),
    ]


def _leyenda(x, y, color, etiqueta):
    return [_rectangulo(x, y - 12, 15, 15, color), _texto(x + 23, y, etiqueta, clase="nota")]


def _eje_horizontal(x, ancho, arriba, abajo, marcas, etiquetas):
    elementos = [_linea(x, abajo, x + ancho, abajo)]
    for valor, etiqueta in zip(marcas, etiquetas):
        pos = x + ancho * valor / marcas[-1]
        elementos.append(_linea(pos, arriba, pos, abajo))
        elementos.append(_texto(pos, abajo + 23, etiqueta, clase="eje", ancla="middle"))
    return elementos


def _numero(valor):
    return f"{valor:,}".replace(",", " ")


def _comparacion(datos):
    brazos = datos["by_arm"]
    recursos = datos["attributed_resources"]
    errores = {m: brazos[m]["errors_including_failures"] for m in MODELOS}
    total = {m: brazos[m]["scheduled_scenarios"] for m in MODELOS}
    fallos = {m: total[m] - brazos[m]["valid_scenarios"] for m in MODELOS}
    tokens = {m: recursos[m]["reported_tokens"] for m in MODELOS}
    sin_registro = {m: recursos[m]["turns_without_token_telemetry"] for m in MODELOS}

    titulo = "Errores y tokens de A10 y A11"
    descripcion = ". ".join(
        f"{m} tuvo {errores[m]} errores de {total[m]} escenarios, entre ellos "
        f"{fallos[m]} fallos u omisiones. El flujo registró {_numero(tokens[m])} tokens "
        f"y {sin_registro[m]} turnos quedaron sin registro de tokens"
        for m in MODELOS
    ) + ". A11 incluye la primera pasada compartida."
    partes = [
        *_encabezado(titulo, datos),
        _texto(42, 140, "Errores en todos los escenarios", clase="panel"),
        *_leyenda(42, 172, AZUL, "Clasificación incorrecta"),
        *_leyenda(260, 172, OCRE, "Fallo técnico u omisión"),
        _texto(42, 384, "Tokens reportados", clase="panel"),
        _texto(42, 412, "A11 incluye los tokens de la primera pasada.", clase="nota"),
    ]

    x, ancho = 124, 650
    paso = 5 * max(1, ceil(max(errores.values()) / 25))
    maximo = paso * max(1, ceil(max(errores.values()) / paso))
    marcas = range(0, maximo + 1, paso)
    partes.extend(_eje_horizontal(x, ancho, 195, 309, marcas, marcas))
    for metodo, y in zip(MODELOS, (210, 261)):
        partes.append(_texto(x - 16, y + 21, metodo, clase="etiqueta", ancla="end"))
        base = x
        for n, color in ((errores[metodo] - fallos[metodo], AZUL), (fallos[metodo], OCRE)):
            tramo = n * ancho / maximo
            if n:
                partes.append(_rectangulo(base, y, tramo, 30, color))
                if tramo >= 14:
                    partes.append(_texto(base + tramo / 2, y + 20, n, clase="interior", ancla="middle"))
            base += tramo
        partes.append(_texto(base + 11, y + 21, f"{errores[metodo]}/{total[metodo]}", clase="etiqueta"))

    paso = 500_000 * max(1, ceil(max(tokens.values()) / 3_000_000))
    maximo = paso * max(1, ceil(max(tokens.values()) / paso))
    marcas = range(0, maximo + 1, paso)
    partes.extend(_eje_horizontal(
        x, ancho, 435, 549, marcas, [f"{n / 1_000_000:g}".replace(".", ",") for n in marcas],
    ))
    for metodo, y, color in zip(MODELOS, (450, 501), (AZUL, MARINO)):
        tramo = tokens[metodo] * ancho / maximo
        partes.extend([
            _texto(x - 16, y + 21, metodo, clase="etiqueta", ancla="end"),
            _rectangulo(x, y, tramo, 30, color),
            _texto(x + tramo + 11, y + 21, _numero(tokens[metodo]), clase="etiqueta"),
        ])
    partes.append(_texto(x, 595, "Millones de tokens", clase="eje"))
    if tokens["A10"]:
        razon = f"{tokens['A11'] / tokens['A10']:.2f}".replace(".", ",")
        partes.append(_texto(ANCHO - 42, 595, f"A11 registró {razon} veces los tokens de A10.", clase="nota", ancla="end"))
    notas = " · ".join(f"{m} {sin_registro[m]}" for m in MODELOS)
    partes.append(_texto(42, 636, f"Turnos sin registro de tokens · {notas}", clase="nota"))
    return _svg(titulo, descripcion, 661, partes)


def _eje_porcentual(y, alto):
    elementos = []
    for porcentaje in (0, 20, 40, 60, 80, 100):
        pos = y - alto * porcentaje / 100
        elementos.append(_linea(100, pos, ANCHO - 42, pos))
        elementos.append(_texto(89, pos + 5, f"{porcentaje} %", clase="eje", ancla="end"))
    return elementos


def _barra_porcentual(x, y, alto, ancho, n, total, color):
    tramo = alto * n / total if total else 0
    elementos = [_rectangulo(x - ancho / 2, y - tramo, ancho, tramo, color)] if tramo else []
    etiqueta = f"{n}/{total}" if total else "Sin casos"
    elementos.append(_texto(x, y - tramo - 8, etiqueta, clase="etiqueta", ancla="middle"))
    return elementos


def _mascaras(datos):
    brazos = datos["by_arm_and_mask"]
    diagnostico = datos["posthoc_diagnostics"]["tradeoff_dominance_by_mask"]["by_hidden_stages_per_product"]
    niveles = sorted(brazos["A10"], key=int)
    if not niveles or set(niveles) != set(brazos["A11"]) or set(niveles) != set(diagnostico):
        raise ValueError("Los niveles de etapas ocultas difieren entre los resultados y el diagnóstico.")
    titulo = "Errores por etapas ocultas"
    partes = [
        *_encabezado(titulo, datos),
        _texto(42, 140, "Errores totales, incluidos los fallos", clase="panel"),
        *_leyenda(42, 171, AZUL, "A10"),
        *_leyenda(125, 171, MARINO, "A11"),
        _texto(42, 425, "Compensaciones clasificadas como dominancia", clase="panel"),
        _texto(42, 452, "Escenarios con etiqueta de referencia de compensación y dos respuestas válidas.", clase="nota"),
        *_leyenda(42, 478, OCRE, "Recuento igual para A10 y A11"),
    ]
    descripcion = []
    alto = 153
    partes.extend(_eje_porcentual(354, alto))
    partes.extend(_eje_porcentual(659, alto))
    separacion = (ANCHO - 142) / len(niveles)
    for indice, nivel in enumerate(niveles):
        x = 100 + (indice + 0.5) * separacion
        resumen = []
        for metodo, color, desplazamiento in zip(MODELOS, (AZUL, MARINO), (-0.16, 0.16)):
            valores = brazos[metodo][nivel]
            errores = valores["errors_including_failures"]
            total = valores["scheduled_scenarios"]
            partes.extend(_barra_porcentual(
                x + desplazamiento * separacion, 354, alto, 0.27 * separacion, errores, total, color,
            ))
            resumen.append(f"{metodo} tuvo {errores} errores de {total}")
        caso = diagnostico[nivel]
        n = caso["by_arm"]["A10"]["classified_as_dominance"]
        if n != caso["by_arm"]["A11"]["classified_as_dominance"]:
            raise ValueError(f"El diagnóstico de dominancia difiere entre A10 y A11 en el nivel {nivel}.")
        total = caso["jointly_valid_reference_tradeoffs"]
        partes.extend(_barra_porcentual(x, 659, alto, 0.47 * separacion, n, total, OCRE))
        for y in (380, 685):
            partes.append(_texto(x, y, nivel, clase="eje", ancla="middle"))
        descripcion.append(
            f"Con {nivel} etapas ocultas por alimento, {resumen[0]} y {resumen[1]}. "
            f"Cada flujo clasificó como dominancia {n} de {total} compensaciones con dos respuestas válidas."
        )
    partes.append(_texto(499, 715, "Etapas ocultas por alimento", clase="etiqueta", ancla="middle"))
    partes.append(_texto(42, 747, "Los escenarios corresponden a distintas versiones de los mismos pares.", clase="nota"))
    return _svg(titulo, " ".join(descripcion), 772, partes)


def escribir_graficas(datos: dict, salida: Path) -> None:
    """Genera las dos gráficas vectoriales con los datos del JSON auditado."""
    graficas = {
        "resultados-comparacion.svg": _comparacion(datos),
        "resultados-mascaras.svg": _mascaras(datos),
    }
    salida.mkdir(parents=True, exist_ok=True)
    for nombre, svg in graficas.items():
        (salida / nombre).write_text(svg, encoding="utf-8", newline="\n")
