# Tablas reproducidas del estudio

Generadas con `python -B reproducir.py` a partir de los agregados auditados. [Datos JSON](../results.json) · [Lectura de los resultados](../resultados-estudio.md) · [Cómo reproducir](../README.md#reproducir-tablas-y-gráficas)

## Comparación general

Los mismos 34 pares se evaluaron en 102 escenarios por método. El recuento de A11 incluye la primera pasada compartida. [Gráfica de errores y tokens](resultados-comparacion.svg)

| Método | Etiquetas válidas incorrectas | Fallos u omisiones | Errores totales | Tokens reportados | Turnos sin recuento de tokens |
| --- | --- | --- | --- | --- | --- |
| A10 | 29 | 1 | 30/102 (29,4 %) | 1 432 535 | 1 |
| A11 | 29 | 3 | 32/102 (31,4 %) | 2 915 761 | 3 |
| B0 · Mediana | 35 | 0 | 35/102 (34,3 %) | 0 | 0 |

## Errores por etapas ocultas

Los recuentos incluyen etiquetas incorrectas y fallos. [Gráfica por etapas ocultas](resultados-mascaras.svg)

| Etapas ocultas por alimento | A10 | A11 | B0 · Mediana |
| --- | --- | --- | --- |
| 0 | 1/34 (2,9 %) | 1/34 (2,9 %) | 0/34 (0,0 %) |
| 2 | 10/34 (29,4 %) | 11/34 (32,4 %) | 13/34 (38,2 %) |
| 4 | 19/34 (55,9 %) | 20/34 (58,8 %) | 22/34 (64,7 %) |

## Compensaciones clasificadas como dominancia

El denominador cuenta los escenarios cuya referencia indicaba una compensación y que tienen dos respuestas válidas. En total se incluyen distintas versiones de 15 pares.

| Etapas ocultas por alimento | Compensaciones clasificadas como dominancia por cada flujo | Probabilidad declarada para esas etiquetas, mediana (rango) |
| --- | --- | --- |
| 0 | 0/15 | — |
| 2 | 5/14 | 75 % (65–98 %) |
| 4 | 9/15 | 65 % (45–95 %) |
| Total | 14/44 | 65 % (45–98 %) |

## Control en escenarios compartidos

Los tres flujos se comparan en los mismos 72 escenarios de 24 pares. A11 y el control incluyen los tokens de la primera pasada.

| Método | Errores, incluidos los fallos | Tokens reportados |
| --- | --- | --- |
| A10 | 26/72 (36,1 %) | 1 008 621 |
| A11 | 28/72 (38,9 %) | 2 043 888 |
| Control neutro | 27/72 (37,5 %) | 2 042 879 |

## Diferencias pareadas

Una diferencia positiva indica más errores para el primer método. El intervalo bootstrap del 95 % para A11 menos A10, reconstruido a partir del histograma por pares, va de +0,00 a +4,90 puntos porcentuales.

| Comparación | Pares | Diferencia en puntos porcentuales | Intervalo conservador del 95 % en puntos porcentuales |
| --- | --- | --- | --- |
| A11 menos A10 | 34 | +1,96 | −10,28 a +19,68 |
| A10 menos B0 · Mediana | 34 | −4,90 | −37,90 a +27,45 |
| A11 menos B0 · Mediana | 34 | −2,94 | −37,90 a +34,53 |
| A11 menos Control neutro | 24 | +1,39 | −21,12 a +27,00 |
| Control neutro menos A10 | 24 | +1,39 | −14,25 a +21,12 |
