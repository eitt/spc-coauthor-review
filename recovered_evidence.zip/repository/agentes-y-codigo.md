# Agentes, código y conexión con ChatGPT

El estudio compara qué pasa cuando a una primera estimación de los impactos de dos alimentos se le añade una revisión. **Python** prepara cada caso y comprueba las respuestas. **CrewAI** organiza en qué orden se hacen las llamadas. **Codex CLI** envía cada petición al modelo de OpenAI y devuelve su respuesta al programa. [Datos y escenarios de AGRIBALYSE](datos-y-escenarios.md)

- **Agente de IA.** En este estudio es un paso del programa que asigna una tarea al modelo. A10 y A11 usan el mismo modelo con instrucciones distintas.
- **Prompt.** Es el texto que recibe el modelo. Combina las instrucciones, los datos del caso y, cuando corresponde, la respuesta de la primera pasada.
- **JSON.** Es un formato de texto con campos y valores. El modelo lo usa para devolver los impactos, la etiqueta de comparación y la evidencia que cita. Un esquema especifica qué campos se esperan y qué tipos de valores aceptan.
- **Token.** Es una unidad de texto que el modelo procesa. Una palabra puede ocupar varios tokens. El programa guarda los recuentos de entrada y salida que reporta Codex para cada llamada.

## Flujo de los agentes

```mermaid
flowchart TD
    base["AGRIBALYSE 3.2"] --> caso["Par de alimentos con 0, 2 o 4 etapas ocultas por alimento"]
    base --> corpus["Corpus separado para ejemplos y medianas"]
    base --> referencia["Totales completos y etiqueta de referencia"]
    caso --> entrada["Etapas visibles y cuatro ejemplos del corpus"]
    corpus --> entrada
    entrada --> a10["A10 · Primera estimación y clasificación"]
    a10 --> primera["Validar y guardar la primera respuesta"]
    primera -->|"Si la llamada devuelve una respuesta"| segunda["Mismo caso y respuesta de A10"]
    primera -->|"Si falla la llamada"| fallo["Registrar el fallo y las segundas pasadas omitidas"]
    entrada --> segunda
    segunda --> a11["A11 · Verificar cálculos, evidencia y clasificación"]
    segunda --> neutro["Control neutro · Estimar de nuevo en 24 pares"]
    a11 --> registro["Validar y guardar las segundas respuestas"]
    neutro --> registro
    caso --> b0["B0 · Completar con medianas y aplicar la regla de comparación"]
    corpus --> b0
    primera --> evaluador["Evaluador local · Compara etiquetas y contabiliza errores"]
    fallo --> evaluador
    registro --> evaluador
    b0 --> evaluador
    referencia --> evaluador
```

**A10** estima los impactos totales a partir de las etapas visibles y de cuatro ejemplos de un conjunto separado de alimentos, llamado *corpus*. **A11** recibe el mismo caso y la respuesta de A10. Su instrucción le pide revisar unidades, sumas, evidencia y coherencia de la etiqueta, y corregir los errores que pueda justificar. El **control neutro** recibe esos mismos insumos y hace una segunda estimación siguiendo una instrucción general. Sirve para distinguir el efecto de pedir una revisión del efecto de dar una segunda oportunidad de respuesta. [Caso ficticio con A10, A11 y el evaluador](ejemplo-completo.md) · [Plantillas exactas del estudio](prompts.json)

**B0** completa cada etapa oculta con la mediana del corpus para ese impacto. La mediana es el valor central de los datos ordenados. Busca primero en la familia y subgrupo del alimento, luego en la familia y finalmente en todo el corpus. Conserva los valores visibles, suma las etapas de cada impacto por separado y aplica la regla de comparación, sin llamadas al modelo. [Ejemplo de etapas ocultas](datos-y-escenarios.md#ejemplo-de-lo-que-veía-el-modelo) · [Demostración de la regla con alimentos ficticios](ejemplo.py)

## Cómo se programó

El Flow de **CrewAI 1.15.37**, escrito en **Python 3.12**, hacía primero la llamada A10 y después las segundas pasadas previstas, de una en una. Python lanzaba `codex exec` como subproceso mediante `subprocess.run` y le enviaba el prompt por la entrada estándar. La opción `--output-schema` solicitaba una respuesta con campos definidos. Con `--json`, el CLI emitía una secuencia de eventos JSON por líneas y el programa extraía el mensaje final. [Modo no interactivo de Codex](https://learn.chatgpt.com/docs/non-interactive-mode)

Si abres las plantillas, verás `{{CASE_JSON}}`, donde Python ponía los datos del caso, y `{{PRELIMINARY_JSON}}`, donde ponía la respuesta de A10 cuando había una segunda pasada. La respuesta incluía los totales estimados de A y B (`candidate_impacts`), la clasificación elegida (`predicted_relation`) y las probabilidades que el modelo asignaba a las clasificaciones posibles (`relation_probabilities`). [Plantillas](prompts.json) · [Campos de la respuesta](agent_output.schema.json)

Este pseudocódigo muestra el orden de las operaciones. Las funciones resumen pasos del programa original.

```text
para cada caso de la cola:
    primera = ejecutar_y_guardar(A10, caso)
    si la llamada de A10 devolvió una respuesta:
        para cada segunda pasada prevista:
            ejecutar_y_guardar(rol, caso, respuesta_original_de_A10)
    si falló la llamada de A10:
        registrar el fallo y las segundas pasadas omitidas

con la cola completa:
    calcular B0 con las etapas visibles y las medianas del corpus
    comparar las etiquetas de todos los métodos con la referencia
```

Antes de cada turno nuevo, `ejecutar_y_guardar` comprobaba la cuota y el presupuesto. Si podía avanzar, lanzaba Codex. Antes de guardar el intento, el programa validaba el JSON recibido y comprobaba las unidades, las citas de evidencia, las probabilidades y la coherencia entre los impactos reportados y la etiqueta. Una respuesta puede superar esas comprobaciones y aun así discrepar de la etiqueta de referencia. El evaluador local mide el acierto con los totales completos de AGRIBALYSE, que se guardaron por separado. [Esquema canónico](agent_output.schema.json) · [Recuentos de la evaluación](datos-y-escenarios.md#recuentos-por-nivel-de-datos-ocultos)

## Cómo se conectó a ChatGPT

**Codex CLI reutilizó la sesión de ChatGPT iniciada por quien ejecutó el estudio.** La versión registrada del cliente fue `0.167.0-alpha.3.2`. Se solicitó el alias `gpt-6.1-sol` con esfuerzo de razonamiento `low`. El modelo se ejecutó en los servidores de OpenAI usando la cuota incluida de la cuenta, sin clave de API ni cargos adicionales para la corrida. El programa podía pausar la cola si faltaba cuota y reanudarla desde los intentos guardados. [Autenticación de Codex CLI](https://learn.chatgpt.com/docs/auth#codex-cli)

Cada llamada se ejecutó en un entorno aislado de Windows mediante MXC. El modelo recibió el prompt y el esquema, con las herramientas y la búsqueda desactivadas. El repositorio de revisión permite verificar las cifras agregadas con Python y sin una cuenta. Una nueva ejecución en el servicio hospedado puede producir respuestas distintas. El registro identifica el alias solicitado y la revisión interna del proveedor queda sin identificar. [Cómo verificar las cifras guardadas](README.md#auditoría-de-los-resultados-guardados)

Los agregados guardados permiten regenerar las tablas y gráficas del estudio con Python. [Resultados auditados](resultados-estudio.md) · [Comando de reproducción](README.md#reproducir-tablas-y-gráficas)
